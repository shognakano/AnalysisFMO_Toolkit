#!/usr/bin/python


# Copyright Notice
# ================
# 
# The PyMOL Plugin source code in this file is copyrighted, but you can
# freely use and copy it as long as you don't change or remove any of
# the copyright notices.
# 
# ----------------------------------------------------------------------
# This PyMOL Plugin is Copyright (C) 2018 by Shogo Nakano <snakano@u-shizuoka-ken.ac.jp>
# 
#                        All Rights Reserved
# 
# Permission to use, copy, modify, distribute, and distribute modified
# versions of this software and its documentation for any purpose and
# without fee is hereby granted, provided that the above copyright
# notice appear in all copies and that both the copyright notice and
# this permission notice appear in supporting documentation, and that
# the name(s) of the author(s) not be used in advertising or publicity
# pertaining to distribution of the software without specific, written
# prior permission.
# 
# THE AUTHOR(S) DISCLAIM ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
# INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS.  IN
# NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY SPECIAL, INDIRECT OR
# CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF
# USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
# OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
# PERFORMANCE OF THIS SOFTWARE.
# ----------------------------------------------------------------------



#####################################################################
#Graphical User Interface
#####################################################################	


import os,sys,re
from pymol import cmd
from tkinter import *
import numpy as np
import Pmw
import tkFileDialog
import tkinter

CSVlocation = ""
PDBlocation = ""
Label_CSV = "CSV file which has 2D interaction energy:"
Label_PDB = "PDB file which used in GAMESS calculation:"
Label_RES = "Input Residue number of which you want to represent interaction:"
Label_NEG = "Do you want to represent stable interaction (red stick)? Yes or No."
Label_POS = "Do you want to represent repulsive interaction (blue stick)? Yes or No."
Label_COL = "Do you want to color each residues with difference of the energies? Yes or No."
Label_COS = "Input contour value. From 0.0 to 1.0. Lower value represents high contrast."
Label_CHAIN = "Input chain name (some alphabet, like A, B, C, ...):"
originalR = "1"
original_chain = "A"
neg_flag_let = "Yes"
pos_flag_let = "No"
color_flag_let = "No"
#directory = "./output_int"
represent_num = 4

defaults = {"program_apply":'Apply',"exit_com":'Exit'}

def __init__(self):
	self.menuBar.addmenuitem('Plugin','command','PyGAMESS_ver1',label='PyGAMESS_ver1',command = lambda s=self:PyGAMESSInteract(s))

#In PyGAMESSInteract, the GUI code to analyze GAMESS output file is written.

class PyGAMESSInteract:
	def __init__(self,app):
		self.root = app.root
		self.top = Pmw.MegaWidget(self.root)
		self.parent1 = self.top.interior()
		self.originalR = 1
		self.neg_flag = int(1)
		self.pos_flag = int(0)
		self.col_flag = int(0)
		self.col_cons = float(1.0)
		self.col_cons2 = float(1.0)
		self.ligand_flag = int(0)
		self.protein_flag = int(1)

		self.E_es_flag = int(1)
		self.E_ex_flag = int(0)
		self.E_ctmin_flag = int(0)
		self.E_disp_flag = int(0)
		self.G_sol_flag = int(0)
		self.E_total_flag = int(0)
		self.Eij_Ei_Ej_flag = int(0)
		self.TrdDij_flag = int(0)
		

		self.dialog = Pmw.Dialog(self.parent1,buttons=(defaults["program_apply"],defaults["exit_com"]),title='PyGAMESS',command=self.execute)
		w = Label(self.dialog.interior(),text = "PyGAMESS:Viewer of GAMESS result",background = 'orange',foreground = 'white')
		w.pack(expand = 1,fill = 'both',padx = 4, pady = 4)

		self.csvfilegroup = Pmw.Group(self.dialog.interior(),tag_text=Label_CSV)
		self.DEFCONF = "No entry"
		self.csvlocation = tkinter.Label(self.csvfilegroup.interior(),text = self.DEFCONF)
		self.csvlocation.pack(anchor='n',side=LEFT,fill='x',padx=4,pady=1)
		self.csvfileload = tkinter.Button(self.csvfilegroup.interior(),text = 'Load csv file (2D)', command = self.csvfilein)
		self.csvfileload.pack(anchor='n',side=RIGHT,fill='x',padx=4,pady=1)
		self.csvfilegroup.pack(expand="yes", fill="x")
		
		#self.csvlocation = Pmw.EntryField(self.dialog.interior(),labelpos='w',value=CSVlocation,label_text=Label_CSV)
		#self.csvlocation.pack(fill='x',padx=4,pady=1)

		self.pdbfilegroup = Pmw.Group(self.dialog.interior(),tag_text=Label_PDB)
		self.pdblocation = tkinter.Label(self.pdbfilegroup.interior(),text = self.DEFCONF)
		self.pdblocation.pack(anchor='n',side=LEFT,fill='x',padx=4,pady=1)
		self.pdbfileload = tkinter.Button(self.pdbfilegroup.interior(),text = 'Load pdb file', command = self.pdbfilein)
		self.pdbfileload.pack(anchor='n',side=RIGHT,fill='x',padx=4,pady=1)
		self.pdbfilegroup.pack(expand="yes", fill="x")

		#self.pdblocation = Pmw.EntryField(self.dialog.interior(),labelpos='w',value=PDBlocation,label_text=Label_PDB)
		#self.pdblocation.pack(fill='x',padx=4,pady=1)

		self.selector = Pmw.RadioSelect(self.dialog.interior(),labelpos='w',command=self.modeselection,label_text='Select the Mode',frame_borderwidth=2,frame_relief='ridge')
		self.selector.pack(fill='x',padx=10,pady=10)
		for text in ('All Interaction','Ligand & protein (PIEDA)'):self.selector.add(text)
		self.selector.invoke('All Interaction')

		#############################################################
		#All interaction mode
		#############################################################		
		
		######Start######

		self.proteingroup = Pmw.Group(self.dialog.interior(),tag_text='All interaction mode')
		self.proteingroup.pack(fill='both',expand=1,padx=10,pady=10)

		self.pickedchain = Pmw.Counter(self.proteingroup.interior(),labelpos='w',entryfield_value=original_chain,label_text=Label_CHAIN)
		self.pickedchain.pack(fill='x',padx=4,pady=1) 

		self.pickedresidue = Pmw.Counter(self.proteingroup.interior(),labelpos='w',entryfield_value=originalR,label_text=Label_RES)
		self.pickedresidue.pack(fill='x',padx=4,pady=1) 

		self.neginteraction = Pmw.OptionMenu(self.proteingroup.interior(),labelpos='w',label_text=Label_NEG,items=('Yes','No'),menubutton_width=7)
		self.neginteraction.pack(fill='x',padx=4,pady=1)

		self.posinteraction = Pmw.OptionMenu(self.proteingroup.interior(),labelpos='w',label_text=Label_POS,items=('No','Yes'),menubutton_width=7)
		self.posinteraction.pack(fill='x',padx=4,pady=1)

		self.residuecolor = Pmw.OptionMenu(self.proteingroup.interior(),labelpos='w',label_text=Label_COL,items=('No','Yes'),menubutton_width=7)
		self.residuecolor.pack(fill='x',padx=4,pady=1)

		self.colorcons = Pmw.Counter(self.proteingroup.interior(),labelpos='w',label_text=Label_COS,entryfield_value='1',\
						entryfield_validate={'validator':'real','min':'0.0','max':'1.0'})
		self.colorcons.pack(fill='x',padx=4,pady=1)
		
		######END######	

		#############################################################
		#protein and ligand mode (PIEDA)
		#############################################################		
		
		######Start######	
		
		self.proligandgroup = Pmw.Group(self.dialog.interior(),tag_text='Ligand & Protein (PIEDA)')
		self.proligandgroup.pack(fill='both',expand=1,padx=10,pady=10)

		self.energyflags = Pmw.RadioSelect(self.proligandgroup.interior(),labelpos='w',command=self.energyflag,label_text='Select Energy type',frame_borderwidth=2,frame_relief='ridge')
		self.energyflags.pack(fill='x',padx=10,pady=10)
		for text2 in ('Ees','Eex','Ect+min','Edisp','Etotal','Eij-Ei-Ej', 'Tr(dDij*Vij)'):self.energyflags.add(text2)
		self.energyflags.invoke('Ees')

		self.liganddist = Pmw.Counter(self.proligandgroup.interior(),labelpos='w',entryfield_value="3",label_text='Input distance (0.0~).')
		self.liganddist.pack(fill='x',padx=4,pady=1) 

		self.colorcons2 = Pmw.Counter(self.proligandgroup.interior(),labelpos='w',label_text=Label_COS,entryfield_value='1',\
						entryfield_validate={'validator':'real','min':'0.0','max':'1.0'})
		self.colorcons2.pack(fill='x',padx=4,pady=1)

		self.hideresidue = Pmw.OptionMenu(self.proligandgroup.interior(),labelpos='w',label_text="Will you show only selected residues?",items=('Yes','No'),menubutton_width=7)
		self.hideresidue.pack(fill='x',padx=4,pady=1)

		######END######
	def csvfilein(self):
		indi = os.path.dirname("./")
		filepath = tkFileDialog.askopenfilename(title="Open csv file", initialdir=indi, filetypes=[("csv file","*.csv"),("text file","*.txt"),("all files","*.*")])
		if not filepath: return
		self.csvlocation.config(text=filepath)
		#print self.csvlocation.cget("text")

	def pdbfilein(self):
		indi = os.path.dirname("./")
		filepath = tkFileDialog.askopenfilename(title="Open pdb file", initialdir=indi, filetypes=[("pdb file","*.pdb"), ("all files","*.*")])
		if not filepath: return
		self.pdblocation.config(text=filepath)
		

	def modeselection(self,tag):
		if re.search(r'''Only.*''',tag):
			self.protein_flag = 1
			self.ligand_flag = 0

		elif re.search(r'''Ligand.*''',tag):
			self.protein_flag = 0
			self.ligand_flag = 1
		#print self.protein_flag
		#print self.ligand_flag

	def energyflag(self,tag):
		if re.search(r'''Ees''',tag):
			self.E_es_flag = int(1)
			self.E_ex_flag = int(0)
			self.E_ctmin_flag = int(0)
			self.E_disp_flag = int(0)
			self.G_sol_flag = int(0)
			self.E_total_flag = int(0)
			self.Eij_Ei_Ej_flag = int(0)
			self.TrdDij_flag = int(0)
		elif re.search(r'''Eex''',tag):
			self.E_es_flag = int(0)
			self.E_ex_flag = int(1)
			self.E_ctmin_flag = int(0)
			self.E_disp_flag = int(0)
			self.G_sol_flag = int(0)
			self.E_total_flag = int(0)
			self.Eij_Ei_Ej_flag = int(0)
			self.TrdDij_flag = int(0)
		elif re.search(r'''Ect+min''',tag):
			self.E_es_flag = int(0)
			self.E_ex_flag = int(0)
			self.E_ctmin_flag = int(1)
			self.E_disp_flag = int(0)
			self.G_sol_flag = int(0)
			self.E_total_flag = int(0)
			self.Eij_Ei_Ej_flag = int(0)
			self.TrdDij_flag = int(0)
		elif re.search(r'''Edisp''',tag):
			self.E_es_flag = int(0)
			self.E_ex_flag = int(0)
			self.E_ctmin_flag = int(0)
			self.E_disp_flag = int(1)
			self.G_sol_flag = int(0)
			self.E_total_flag = int(0)
			self.Eij_Ei_Ej_flag = int(0)
			self.TrdDij_flag = int(0)
		elif re.search(r'''Gsol''',tag):
			self.E_es_flag = int(0)
			self.E_ex_flag = int(0)
			self.E_ctmin_flag = int(0)
			self.E_disp_flag = int(0)
			self.G_sol_flag = int(1)
			self.E_total_flag = int(0)
			self.Eij_Ei_Ej_flag = int(0)
			self.TrdDij_flag = int(0)
		elif re.search(r'''Etotal''',tag):
			self.E_es_flag = int(0)
			self.E_ex_flag = int(0)
			self.E_ctmin_flag = int(0)
			self.E_disp_flag = int(0)
			self.G_sol_flag = int(0)
			self.E_total_flag = int(1)
			self.Eij_Ei_Ej_flag = int(0)
			self.TrdDij_flag = int(0)
		elif re.search(r'''Eij-Ei-Ej''',tag):
			self.E_es_flag = int(0)
			self.E_ex_flag = int(0)
			self.E_ctmin_flag = int(0)
			self.E_disp_flag = int(0)
			self.G_sol_flag = int(0)
			self.E_total_flag = int(0)
			self.Eij_Ei_Ej_flag = int(1)
			self.TrdDij_flag = int(0)
		elif re.search(r'''Tr(dDij*Vij)''',tag):
			self.E_es_flag = int(0)
			self.E_ex_flag = int(0)
			self.E_ctmin_flag = int(0)
			self.E_disp_flag = int(0)
			self.G_sol_flag = int(0)
			self.E_total_flag = int(0)
			self.Eij_Ei_Ej_flag = int(0)
			self.TrdDij_flag = int(1)


	def execute(self,result):
		if result == defaults["program_apply"]:
	
			#The following procedure will be executed in case of selecting "All interaction mmode".					
			if self.protein_flag==int(1):			
				if self.neginteraction.getvalue()=="No":
					self.neg_flag = int(0)
				if self.neginteraction.getvalue()=="Yes":
					self.neg_flag = int(1)
				if self.posinteraction.getvalue()=="No":
					self.pos_flag = int(0)
				if self.posinteraction.getvalue()=="Yes":
					self.pos_flag = int(1)
				if self.residuecolor.getvalue()=="Yes":
					self.col_flag = int(1)
				if self.residuecolor.getvalue()=="No":
					self.col_flag = int(0)
				
				csv_file = self.csvlocation.cget("text")
				pdb_file = self.pdblocation.cget("text")
				#csv_file = self.csvlocation.getvalue()
				#pdb_file = self.pdblocation.getvalue()
				#input_dist = float(3.0)
				self.col_cons = self.colorcons.getvalue()
				self.stick_flag = int(1)	


				if os.path.isfile(csv_file):
					if os.path.isfile(pdb_file):
						self.MainCSV(self.csvlocation.cget("text"),self.pickedresidue.getvalue(),self.neg_flag,self.pos_flag,self.stick_flag,self.col_flag,self.col_cons,self.pickedchain.getvalue())
						#self.MainCSV(self.csvlocation.getvalue(),self.pickedresidue.getvalue(),self.neg_flag,self.pos_flag,self.stick_flag,self.col_flag,self.col_cons)
						#GAMESS_INT_NUM(directory,represent_num,self.neg_flag,self.pos_flag)
						#if self.col_flag == 1:
						#	GAMESS_COLOR(directory,represent_num,self.col_cons)
					else:
						error_dialog = Pmw.MessageDialog(self.parent, title='Error', message_text = "ERROR: there is no pdb file that you defined!!",)
						return 0
				else:
					error_dialog = Pmw.MessageDialog(self.parent, title='Error', message_text = "ERROR: there is no csv file that you defined!!",)
					return 0

			#The following protocol will be executed in case of selecting "Ligand mode".
			elif self.ligand_flag == int(1):
				
				csv_file = self.csvlocation.cget("text")
				pdb_file = self.pdblocation.cget("text")
				#self.csv_file = self.csvlocation
				#self.pdb_file = self.pdblocation

				input_dist = self.liganddist.getvalue()
				self.colcons2 = float(self.colorcons2.getvalue())
				
				
				if self.hideresidue.getvalue() == "Yes":
					self.hideflag = int(1)
				elif self.hideresidue.getvalue() == "No":
					self.hideflag = int(0)
				
				if os.path.isfile(csv_file):
					#if os.path.isfile(pdb_file):
					#	check = [];check1 = []
					#	check = (file(csv_file).read()).split('\n')
					#	check1 = check[-1]
#
#						if re.search(".*Binding.*",check1):



					self.LIGPROEN(csv_file,input_dist,self.E_es_flag, self.E_ex_flag, self.E_ctmin_flag, self.E_disp_flag, self.G_sol_flag, self.E_total_flag, self.Eij_Ei_Ej_flag, self.TrdDij_flag, self.colcons2,self.hideflag)
						#else:
						#	error_csv = Pmw.MessageDialog(self.parent1, title='Error', message_text = "ERROR: This file could not be utilized to the Ligand binding mode. Please enter collect file name.")
						#	return 0
				#	else:
				#		error_dialog = Pmw.MessageDialog(self.parent1, title='Error', message_text = "ERROR: there is no pdb file that you defined!!",)
				#		return 0
				else:
					error_dialog = Pmw.MessageDialog(self.parent1, title='Error', message_text = "ERROR: there is no csv file that you defined!!",)
					return 0
				
					
		else:
			self.parent1.destroy()

	def NULLELIM(self,cvs):
		aft_data = []
		for i in range(len(cvs)):
			temp = []
			temp = cvs[i]
			if re.search('.*\w+.*',temp):
				aft_data.append(temp)
			else:
				continue
		return aft_data
	
	def NUMRES(self,data):
		all_res = [];all_res2 = []
		all_res = re.split(',',data)
		all_res2 = self.NULLELIM(all_res)
		return all_res2
	
	def ENERGY(self,en_array,cvs):
		res_array = []
		for i in range(len(cvs)):
			temp = [];temp_res = []
			temp = cvs[i]
			temp2 = self.NUMRES(temp)
			temp_res = temp2[0:4]
			res_array.append(','.join(temp_res))
			del temp2[0:4]
			#if i == 250:
			#	print temp_res
	
			for j in range(len(temp2)):
				value = float(0)
				value = float(temp2[j])
				en_array[i,j] = value
		return en_array,res_array
		
	def PICKENE(self,en_array,res_1,res_long,pick_en):
		for i in range(res_long):
			x = int(0);y = int(0);value = float(0)
			x = res_1
			y = i
			if x-y < 0:
				value = en_array[y,x]
			else:
				value = en_array[x,y]
			pick_en[i] = value
		return pick_en
			
	def PICKENEMOD(self,pick_en):
		for i in range(len(pick_en)):
			data = float(0)
			data = pick_en[i]
			if data**2 > 100000:
				pick_en[i] = float(0)
		return pick_en
	
	def NORMENE(self,pick_en2):
		average = float(0);std = float(0)
		average = np.average(pick_en2)
		std = np.std(pick_en2)
		pick_en3 = (pick_en2-average)/std
		return pick_en3
		
	def OUTPUTA(self,outputfile,ene_array):
		for i in range(len(ene_array)):
			value = float(0)
			value = ene_array[i]
			outputfile.write("%(value)10.8f\n"%vars())
	
	def OUTPUTB(self,outputfile,array):
		for i in range(len(array)):
			value = []
			value = array[i]
			outputfile.write("%(value)s\n"%vars())
	
	def ARRAYPREP(self,val_array,res_array,cvs_data2):
		val_data = [];num = int(0);res_types = [];chain_name = []
		#print cvs_data2
		for i in range(len(cvs_data2)):
			temp1 = [];temp2 = [];temp_res = [];temp_typ = [];temp_chain = []
			temp1 = cvs_data2[i]
			temp2 = re.split(',',temp1)[7:]
			temp_res = re.split(',',temp1)[6]
			temp_typ = re.split(',',temp1)[3]
			temp_chain = re.split(',',temp1)[4]
			#temp_chain = self.NULLELIM3(temp_chain)
			#print temp_chain
			#temp_res = temp_res+temp_chain
			if re.search('\d+.*',temp_res):
				temp_res = temp_res
			else:
				temp_vala = int(0)
				temp_res = "%(temp_vala)i"%vars()
				#num = num + 1
			res_array.append(temp_res)
			res_types.append(temp_typ)
			chain_name.append(temp_chain)
			for j in range(len(temp2)):
				temp_val = float(0)
				temp_val = float(temp2[j])	
				val_array[i,j] = temp_val
	
	
		for k in range(len(val_array)):
			temp_ar1 = val_array[k]
			for j in range(len(temp_ar1)):
				x = int(0);y = int(0)
				x = k	
				y = j
				if x-y <= 0:
					val_array[x,y] = val_array[y,x]
				else:
					continue
		#print "val_array"
		#print val_array

		#print"\n\nchain_name\n"
		#print chain_name


		return val_array,res_array,res_types,chain_name
		
	def PICKENEMOD(self,pick_en):
		for i in range(len(pick_en)):
			data = float(0)
			data = pick_en[i]
			if data**2 > 100000:
				pick_en[i] = float(0)
		return pick_en
	
	def NORMENE(self,pick_en2):
		average = float(0);std = float(0)
		average = np.average(pick_en2)
		std = np.std(pick_en2)
		pick_en3 = (pick_en2-average)/std
		return pick_en3
	
	def MainCSV(self,inp_file,res_num,neg_flag,pos_flag,stick_flag,color_flag,col_cons,select_chain):
	
		cvs_data = []
		cvs_data = (open(inp_file,'r').read()).split("\n")
		
		#print cvs_data[0:2]
		
		#null code will be removed.
		cvs_data2 = []
		cvs_data2 = self.NULLELIM(cvs_data)
		
		del cvs_data2[0]
		
		val_array = np.zeros([len(cvs_data2),len(cvs_data2)],float)
		res_array = [];res_types = [];chain_array = []
		
		val_array,res_array,res_types,chain_array = self.ARRAYPREP(val_array,res_array,cvs_data2)

		#print chain_array
		
		#print res_array.index(residue_num)
		#print res_array.index(res_num)
		
		#print res_array
		#print val_array
		#print  res_type
		#print res_num

		#print select_chain

		#print chain_array
		#select_chain = []
		#select_chain = 'B'
		#chain_ind = []
		#for num_ch in range(len(chain_array)):
		#	tmp_num = [];tmp_chain = []
		#	tmp_chain = chain_array[num_ch]
		#	if re.search(tmp_chain,select_chain):
		#		tmp = []
		#		tmp = str(num_ch+1)				
		#		chain_ind.append(tmp)
		#	chain_ind = chain_array.index(select_chain)
		#print chain_ind
		#res_num = res_num+select_chain

		#print res_num

		#int_res_0 = [];int_res = int(0)
		#int_res_0 = res_array.index(res_num)
		#print int_res_0
	
		for x in range(len(res_array)):
			tmp_r = int(0);tmp_cha = str()
			tmp_cha = str(chain_array[x])
			tmp_r = int(res_array[x])
			#if x == 0:
				#print "test\n"
				#print tmp_r
				#print tmp_cha
			if select_chain in tmp_cha:
				#print x
				if int(res_num) == int(tmp_r):
					print(x)
					int_res_0 = []
					int_res_0 = x
					break
			


		#if re.search(r'''.*LIG.*''',res_num):
		#	int_res = int(0)
		#else:
		int_res = int(int_res_0)
		
			
		#print int_res
	
		picked_energy = val_array[int_res]
		
		#print pick_ene
		
		pick_ene2 = self.PICKENEMOD(picked_energy)
		#print pick_ene2
		norm_ene = self.NORMENE(pick_ene2)
		#print pick_ene2	
	
		if os.path.isdir("output_int_%(res_num)s"%vars()):
			os.system("rm -rf output_int_%(res_num)s"%vars())
		
		os.mkdir("./output_int_%(res_num)s"%vars())
		os.chdir("output_int_%(res_num)s"%vars())
		
		outputfile_log = open("param.log",'w')
		outputfile_log.write("Your selected residues number:%(res_num)s\n"%vars())
		outputfile_log.write("Your inputted csv file is: %(inp_file)s\n"%vars())
		outputfile_log.write("energies which were not normalized one: energies_non_norm.out\n"%vars())
		outputfile_log.write("energies which were normalized one: energies_norm.out\n"%vars())
		
		outputfile_resi_label = open("residue_label.out",'w')
		self.OUTPUTB(outputfile_resi_label,res_array)
		
		outputfile_ene = open("energies_non_norm.out",'w')
		self.OUTPUTA(outputfile_ene,picked_energy)
			
		outputfile_norm = open("energies_norm.out",'w')
		self.OUTPUTA(outputfile_norm,norm_ene)
	
		os.chdir("../")
		
		pick_num = int(5)
	
		cmd.hide("all")
		cmd.show("cartoon","all")
		cmd.set("cartoon_transparency","0.6","all")
		#cmd.set("stick_radius","0.15","all")

		#norm_ene2 = norm_ene
		if color_flag == 1:	
			self.GAMESS_COLOR(norm_ene,int_res,col_cons,res_array,chain_array)
		if stick_flag == 1:
			if int_res != 0: 
		 		self.GAMESS_INT_NUM(norm_ene,int_res,pick_num,res_types,neg_flag,pos_flag,res_array,pick_ene2,chain_array,select_chain)

		outputfile_ene.close()
		outputfile_resi_label.close()
		outputfile_norm.close()
		outputfile_log.close()	
	
	
	def GAMESS_INT_NUM(self,norm_ene,int_res,pick_num,res_types,neg_flag,pos_flag,res_array,pick_ene2,chain_array,select_chain): 
		#norm_energy = NULLELIM2((file(directory+"/energies_norm.out").read()).split('\n'))
		picked_resi = int_res
		en_array_norm = norm_ene
		#en_array_norm = NPARRAY2(norm_ene,en_array_norm)
		
		#initialization.
		#cmd.delete("pos*")
		#cmd.delete("neg*")
	
		if neg_flag == 1:
			self.RESIPICK_NEG_NUM(en_array_norm,picked_resi,pick_num,res_array,pick_ene2,chain_array,select_chain)
		if pos_flag == 1:
			self.RESIPICK_POS_NUM(en_array_norm,picked_resi,pick_num,res_array,pick_ene2,chain_array,select_chain)
	
	def RESIPICK_NEG_NUM(self,en_array_norm,picked_resi,pick_num,res_array,en_array,chain_array,select_chain):
		stick_radius=0.05;
		pick_res1 = int(0);en_param = np.zeros(pick_num,float);res_num_ar = [];chain_code = []
		pick_res1 = int(picked_resi)
		label_font = float(30.0)
		for i in range(pick_num):
			picked_resi = []
			res_name = [];res_num = [];atom1 = [];atom2 = [];resi1 = [];resi2 = [];res_val = int(0);picked_resi2 = [];chain_name = []		
			picked_resi = str(res_array[pick_res1])
			
			chain_name = str(chain_array[pick_res1])
	
			value = float(0);radius = float(0);real_val = float(0)
			value = np.min(en_array_norm)
			real_val = np.min(en_array)
			res_val = np.argmin(en_array_norm)
			res_val = int(res_val)
			#in_pymol = res_array.index(res_val)
			in_pymol = str(res_array[res_val])
			in_chain = str(chain_array[res_val])

			radius = value*stick_radius		
			label_size = label_font*value	

			print(in_chain)
			print(chain_name)	

			cmd.create("neg_%(picked_resi)s-%(in_pymol)s"%vars(),"((resi %(picked_resi)s) & (name CA) & (chain %(chain_name)s))|((resi %(in_pymol)s) & (name CA) & (chain %(in_chain)s))"%vars())
			cmd.bond("((resi %(picked_resi)s) & (name CA) & (chain %(chain_name)s)) & (neg_%(picked_resi)s-%(in_pymol)s)"%vars() \
			,"((resi %(in_pymol)s) & (name CA) & (chain %(in_chain)s)) & (neg_%(picked_resi)s-%(in_pymol)s)"%vars())
			cmd.show_as("stick","neg_%(picked_resi)s-%(in_pymol)s"%vars())
			cmd.hide("lines","neg_%(picked_resi)s-%(in_pymol)s"%vars())
			cmd.set("stick_color","red","neg_%(picked_resi)s-%(in_pymol)s"%vars())
			cmd.set("stick_radius","%(radius)f"%vars(),"neg_%(picked_resi)s-%(in_pymol)s"%vars())
			cmd.set("stick_transparency","0.2","neg_%(picked_resi)s-%(in_pymol)s"%vars())
			cmd.label("(neg_%(picked_resi)s-%(in_pymol)s) & ((resi %(in_pymol)s) & (name CA))"%vars(),"%(in_pymol)s"%vars())
			cmd.set("label_size","30","(neg_%(picked_resi)s-%(in_pymol)s) & ((resi %(in_pymol)s) & (name CA))"%vars())
			
			en_param[i] = real_val
			res_num_ar.append(in_pymol)
			chain_code.append(in_chain)
	
			#output_neg_int = open('./output_int/negative_interaction.log','w')
			#output_neg_int.write("%(in_pymol)s %(value)f\n"%vars())
	
			en_array_norm[np.argmin(en_array_norm)] = 0.0
			en_array[np.argmin(en_array)] = 0.0
			
		#print en_param,res_num_ar
		output_neg_int = open('./output_int_%(picked_resi)s/negative_interaction.log'%vars(),'w')
		
		#for num in range(len(en_param)):
		#	res = [];res_param = float(0);chain_ID = []
		#	res = res_num_ar[num]
		#	res_param = en_param[num]
		#	chain_ID = chain_array[num]		
		#	output_neg_int.write("%(res)s %(chain_ID)s %(res_param)f\n"%vars())
		

		temp_resA = []
		for k in range(len(res_num_ar)):
			tempA = [];tmp_chA = []
			tempA = res_num_ar[k]
			tmp_chA = chain_code[k]
			cmd.show("stick","(resi %(tempA)s)&(chain %(tmp_chA)s)"%vars())
			
		for num in range(len(en_param)):
			res = [];res_param = float(0);chain_ID = []
			res = res_num_ar[num]
			res_param = en_param[num]
			chain_ID = chain_code[num]		
			output_neg_int.write("%(res)s %(chain_ID)s %(res_param)f\n"%vars())	

		output_neg_int.close()
	
	
	
	def RESIPICK_POS_NUM(self,en_array_norm,picked_resi,pick_num,res_array,en_array,chain_array,select_chain):
		stick_radius=0.05;pick_res1 = int(0);en_param = np.zeros(pick_num,float);res_num_ar = [];chain_code = []
		pick_res1 = int(picked_resi)
		label_font = float(30.0)
		for i in range(pick_num):
			res_name = [];res_num = [];atom1 = [];atom2 = [];resi1 = [];resi2 = [];res_val = int(0);picked_resi2 = [];chain_name = []
			#print picked_resi
			picked_resi = str(res_array[pick_res1])
			chain_name = str(chain_array[pick_res1])
	
			value = float(0);radius = float(0)
			value = np.max(en_array_norm)
			real_val = np.max(en_array)
			res_val = np.argmax(en_array_norm)
			res_val = int(res_val)
			in_pymol = str(res_array[res_val])
			in_chain = str(chain_array[res_val])

			radius = value*stick_radius	
			label_size = label_font*value
	
			cmd.create("pos_%(picked_resi)s-%(in_pymol)s"%vars(),"((resi %(picked_resi)s) & (name CA) & (chain %(chain_name)s))|((resi %(in_pymol)s) & (name CA) & (chain %(in_chain)s))"%vars())
			cmd.bond("((resi %(picked_resi)s) & (name CA) & (chain %(chain_name)s)) & (pos_%(picked_resi)s-%(in_pymol)s)"%vars() \
			,"((resi %(in_pymol)s) & (name CA) & (chain %(in_chain)s)) & (pos_%(picked_resi)s-%(in_pymol)s)"%vars())
			cmd.show_as("stick","pos_%(picked_resi)s-%(in_pymol)s"%vars())
			cmd.hide("lines","pos_%(picked_resi)s-%(in_pymol)s"%vars())
			cmd.set("stick_color","blue","pos_%(picked_resi)s-%(in_pymol)s"%vars())
			cmd.set("stick_radius","%(radius)f"%vars(),"pos_%(picked_resi)s-%(in_pymol)s"%vars())
			cmd.set("stick_transparency","0.2","pos_%(picked_resi)s-%(in_pymol)s"%vars())
			cmd.label("(pos_%(picked_resi)s-%(in_pymol)s) & ((resi %(in_pymol)s) & (name CA))"%vars(),"%(in_pymol)s"%vars())
			cmd.set("label_size","30","(pos_%(picked_resi)s-%(in_pymol)s) & ((resi %(in_pymol)s) & (name CA))"%vars())

			#cmd.create("pos_%(picked_resi)s-%(in_pymol)s"%vars(),"((resi %(picked_resi)s) & (name CA) & (chain %(chain_name)s))|((resi %(in_pymol)s) & (name CA) & (chain %(in_chain)s))"%vars())
			#cmd.bond("((resi %(picked_resi)s) & (name CA) & (chain %(chain_name)s)) & (pos_%(picked_resi)s-%(in_pymol)s))"%vars() \
			#,"((resi %(in_pymol)s) & (name CA) & (chain %(in_chain)s)) & (pos_%(picked_resi)s-%(in_pymol)s)"%vars())
			#cmd.show_as("stick","pos_%(picked_resi)s-%(in_pymol)s)"%vars())
			#cmd.hide("lines","pos_%(picked_resi)s-%(in_pymol)s"%vars())
			#cmd.set("stick_color","blue","pos_%(picked_resi)s-%(in_pymol)s"%vars())
			#cmd.set("stick_radius","%(radius)f"%vars(),"pos_%(picked_resi)s-%(in_pymol)s"%vars())
			#cmd.set("stick_transparency","0.2","pos_%(picked_resi)s-%(in_pymol)s"%vars())
			#cmd.label("(pos_%(picked_resi)s-%(in_pymol)s) & ((resi %(in_pymol)s) & (name CA))"%vars(),"%(in_pymol)s"%vars())
			#cmd.set("label_size","30","(pos_%(picked_resi)s-%(in_pymol)s) & ((resi %(in_pymol)s) & (name CA))"%vars())
	
			en_param[i] = real_val
			res_num_ar.append(in_pymol)
			chain_code.append(in_chain)
	
			en_array_norm[np.argmax(en_array_norm)] = 0.0
			en_array[np.argmax(en_array)] = 0.0

	
		output_neg_int = open('./output_int_%(picked_resi)s/positive_interaction.log'%vars(),'w')
		#for num in range(len(en_param)):
		#	res = [];res_param = float(0);chain_ID = []
		#	res = res_num_ar[num]
		#	res_param = en_param[num]
		#	chain_ID = chain_array[num]		
		#	output_neg_int.write("%(res)s %(chain_ID)s %(res_param)f\n"%vars())

		temp_resA = []
		for k in range(len(res_num_ar)):
			tempA = [];tmp_chA = []
			tempA = res_num_ar[k]
			tmp_chA = chain_code[k]
			cmd.show("stick","(resi %(tempA)s)&(chain %(tmp_chA)s)"%vars())

		for num in range(len(en_param)):
			res = [];res_param = float(0);chain_ID = []
			res = res_num_ar[num]
			res_param = en_param[num]
			chain_ID = chain_code[num]
			output_neg_int.write("%(res)s %(chain_ID)s %(res_param)f\n"%vars())

		output_neg_int.close()

	
	
	
	def GAMESS_COLOR(self,en_array_norm,picked_resi,col_cons,res_array,chain_array):
		pick_in_py = picked_resi
		Emax = float(0);Emin = float(0)
		Emax = ((np.max(en_array_norm))**2.0)**(0.50)
		Emin = ((np.min(en_array_norm))**2.0)**(0.50)
		
		col_cont = float(0)
		col_cont = float(col_cons)
	
		cmd.set_color("all",[1.0,1.0,1.0])
		cmd.color("all","all")
	
		for i in range(len(en_array_norm)):
			r_color = float(0);g_color = float(0);b_color = float(0)
			Ei = float(0);in_pymol = [];in_chain = []
			in_pymol = str(res_array[i])
			in_chain = str(chain_array[i])
			Ei = en_array_norm[i]
			
			if Ei < float(0):
				#b_color = 1.00
				#g_color = 1.00-(((-Ei)**col_cont)/(2.0*(Emin**col_cont)))
				#r_color = 1.00-(((-Ei)**col_cont)/(2.0*(Emin**col_cont)))
	
				r_color = 1.00
				g_color = 1.00-(((-Ei)**col_cont)/(2.0*(Emin**col_cont)))
				b_color = 1.00-(((-Ei)**col_cont)/(2.0*(Emin**col_cont)))
	
				cmd.set_color("temp_%(i)i"%vars(),[r_color,g_color,b_color])
				cmd.color("temp_%(i)i"%vars(),"(resi %(in_pymol)s)&(!(resn HOH))&(chain %(in_chain)s)"%vars())
			elif Ei == float(0):
				cmd.set_color("temp_%(i)i"%vars(),[1.0,1.0,1.0])
				cmd.color("temp_%(i)i"%vars(),"(resi %(in_pymol)s)&(!(resn HOH))&(chain %(in_chain)s)"%vars())
			elif Ei > float(0):
				r_color = 1.00-((Ei**col_cont)/(2.0*(Emax**col_cont)))
				g_color = 1.00-((Ei**col_cont)/(2.0*(Emax**col_cont)))
				b_color = 1.00
	
				cmd.set_color("temp_%(i)i"%vars(),[r_color,g_color,b_color])
				cmd.color("temp_%(i)i"%vars(),"(resi %(in_pymol)s)&(!(resn HOH))&(chain %(in_chain)s)"%vars())
	
	##############################################################################################################
	#SubRoutine for protein_ligand mode (Ees,Eex,Ect+min, Edisp, Gsol, Etotal, Eij-Ei-Ej, Tr(dDij*Vij) (kcal/mol))
	##############################################################################################################
	def NULLELIM3(self,cvs):
		aft_data = [];aft_data2 = []
		for i in range(len(cvs)):
			temp = []
			temp = cvs[i]
			if re.search('.*\w+.*',temp):
				aft_data.append(temp)
			else:
				continue
	
		for j in range(len(aft_data)):
			temp2 = []
			temp2 = aft_data[j]
			if re.search('^,,\d+.*',temp2):
				aft_data2.append(temp2)
			else:
				continue
		return aft_data2
	
	def PICKRESI(self,cvs2):
		resi_num = [];resn_array = [];chain_info2 = []
		for i in range(len(cvs2)):
			temp = [];resnum = []
			temp = cvs2[i]
			resn = re.split(',',temp)[5]
			chain_info = re.split(',',temp)[6]
			#chain_info = self.NULLELIM3(chain_info)
			#print chain_info
			resnum = re.split(',',temp)[7]
			resi_num.append(resnum)
			resn_array.append(resn)
			chain_info2.append(chain_info)
		return resi_num,resn_array,chain_info2
	
	def ALLENERGY(self,en_array,cvs2,resi):	
		#To add other energy parameters, new column must be defined in this loop.
		for i in range(len(cvs2)):
			temp = []
			temp = cvs2[i]
			distance = float(0);E_es = float(0);E_ex = float(0);E_ctmin = float(0);E_disp = float(0);G_sol=float(0);E_total=float(0);Eij_Ei_Ej=float(0);Tr_dDij=float(0)
			distance = float(re.split(',',temp)[9])
			E_es = float(re.split(',',temp)[10])
			E_ex = float(re.split(',',temp)[11])
			E_ctmin = float(re.split(',',temp)[12])
			E_disp = float(re.split(',',temp)[13])
			G_sol = float(re.split(',',temp)[14])
			E_total = float(re.split(',',temp)[15])
			Eij_Ei_Ej = float(re.split(',',temp)[16])
			Tr_dDij = float(re.split(',',temp)[17])
			en_array[0,i] = distance;en_array[1,i] = E_es;en_array[2,i] = E_ex;en_array[3,i] = E_ctmin;en_array[4,i] = E_disp;en_array[5,i] = G_sol;en_array[6,i] = E_total; en_array[7,i] = Eij_Ei_Ej;en_array[8,i] = Tr_dDij
		return en_array
	
	def RESIANDENERGY(self,inp_file):
		cvs_data = [];resi = [];resn = [];chain_inf=[];resi_len = int(0)
		cvs_data = (open(inp_file,'r').read()).split("\n")
		
		#null code will be removed.
		cvs_data2 = []
		cvs_data2 = self.NULLELIM3(cvs_data)
		
		#print cvs_data2
		
		resi,resn,chain_inf = self.PICKRESI(cvs_data2)
		#print chain_inf

		resi_len = len(resi)
		resi_array = np.zeros(resi_len,int)
		for i in range(len(resi)):
			resi_num = int(0)
			resi_num = int(resi[i])
			resi_array[i] = resi_num
		
		all_en_array = np.zeros([9,resi_len],float)
		
		#distance, energy for Ees, Eex, Ect+min, Edisp, Gsol, Etotal, Eij-Ei-Ej, Tr(dDij*Vij) were contained in all_en_array.
		#all_en_array[0,i] -> distance
		#all_en_array[1,i] -> Ees
		#all_en_array[2,i] -> Eex
		#all_en_array[3,i] -> Ect+mix
		#all_en_array[4,i] -> Edisp
		#all_en_array[5,i] -> Gsol
		#all_en_array[6,i] -> Etotal
		#all_en_array[7,i] -> Eij-Ei-Ej
		#all_en_array[8,i] -> Tr(dDij*Vij)
		all_en_array = self.ALLENERGY(all_en_array,cvs_data2,resi)	
		return resi_array,all_en_array,chain_inf
	
	def PICKDIST(self,energy,input_dist2):
		pick_array = []
		for i in range(len(energy[0])):
			temp_dist = float(0)
			temp_dist = float(energy[0,i])
			if temp_dist - input_dist2 < 0:
				pick_array.append(str(i))
		return pick_array
		
	def PICKEN(self,within_dist,energy,picked_energy,resi,picked_resi,chain_inf,picked_chain):
		#print chain_inf
		for i in range(len(within_dist)):
			label = int(0);resi_num = int(0)
			label = int(within_dist[i])
			
			resi_num = int(resi[label])
			picked_resi[i] = resi_num
			chain_name = []

			chain_name = chain_inf[label]
			picked_chain.append(chain_name)
	
			distance = float(0);E_es = float(0);E_ex = float(0);E_ctmin = float(0);E_disp = float(0)
			G_sol = float(0);E_total = float(0);Eij_Ei_Ej = float(0);Tr_dDij = float(0)
			distance = float(energy[0,label]);E_es = float(energy[1,label]);E_ex = float(energy[2,label])	
			E_ctmin= float(energy[3,label]);E_disp = float(energy[4,label])
			G_sol = float(energy[5,label]); E_total = float(energy[6,label]); Eij_Ei_Ej = float(energy[7,label]); Tr_dDij = float(energy[8,label])
	
			picked_energy[0,i] = distance;picked_energy[1,i] = E_es;picked_energy[2,i] = E_ex
			picked_energy[3,i] = E_ctmin;picked_energy[4,i] = E_disp; picked_energy[5,i] = G_sol
			picked_energy[6,i] = E_total;picked_energy[7,i] = Eij_Ei_Ej;picked_energy[8,i] = Tr_dDij
	
		return picked_energy,picked_resi,picked_chain
		
	def OUTPUT(self,outputfile,pick_res,pick_en):
		for i in range(len(pick_res)):
			dist = float(0);E_es = float(0);E_ex = float(0);E_ctmin = float(0);E_disp = float(0);G_sol = float(0);E_total = float(0);Eij_Ei_Ej = float(0);Tr_dDij = float(0);resi_num = int(0)
			resi_num = int(pick_res[i])
			dist = pick_en[0,i];E_es = pick_en[1,i];E_ex = pick_en[2,i]
			E_ctmin = pick_en[3,i];E_disp = pick_en[4,i];G_sol = pick_en[5,i]
			E_total = pick_en[6,i];Eij_Ei_Ej = pick_en[7,i];Tr_dDij = pick_en[8,i]
			outputfile.write("%(resi_num)i %(dist)f %(E_es)f %(E_ex)f %(E_ctmin)f %(E_disp)f %(G_sol)f %(E_total)f %(Eij_Ei_Ej)f %(Tr_dDij)f\n"%vars())

	# Additional code written on 29th August, 2014.
	# Purpose: To normalize the array value to maximum:1 and minimum:0
	# Usage: arrays should be defined by "np.zeros" function.
	# Start:

	def NORMMAX(self,arrays1):
		num_column = int(0)
		num_column = len(arrays1)
		max_value = float(0)
		min_value = float(0)
		#print arrays1

		if num_column == 0:
			norm_array = np.zeros(1,float)
		elif num_column == 1:
			norm_array = np.zeros(1,float)
			norm_array[0] = float(1.0)
		else:
			norm_array = np.zeros(num_column,float)
			max_value = float(np.max(arrays1))
			min_value = float(np.min(arrays1))
			norm_array = (arrays1-min_value)/(max_value-min_value)
	
		#print norm_array
	
		return norm_array

	def NORMMIN(self,arrays1):
		num_column = int(0)
		num_column = len(arrays1)
		max_value = float(0)
		min_value = float(0)
		arrays1 = -arrays1

		print(arrays1)

		if num_column == 0:
			norm_array = np.zeros(1,float)
		elif num_column == 1:
			norm_array = np.zeros(1,float)
			norm_array[0] = float(1.0)
		else:
			norm_array = np.zeros(num_column,float)
			max_value = float(np.max(arrays1))
			min_value = float(np.min(arrays1))
			norm_array = (arrays1-min_value)/(max_value-min_value)
	
		norm_array = -norm_array
		#print norm_array
	
		return norm_array

	# End (29th August, 2014).
	
	def NORMEN(self,en_array,ret_array):
		for i in range(len(en_array)):
			value = float(0)
			value = float(en_array[i])
			ret_array[i] = value

		# Additional code on 29th August, 2014.
		# Purpose: To distinguish positive or negative energy value and normalize to 
		# color the energy.
		# Start:
		
		neg_energ = [];neg_index = []
		pos_energ = [];pos_index = []


		for j in range(len(ret_array)):
			tmp_val = float(0);tmp_data = ""
			tmp_val = ret_array[j]
			if tmp_val >= 0:
				tmp_data = str(tmp_val)
				pos_energ.append(tmp_data)
				pos_index.append(str(j))
			else:
				tmp_data = str(tmp_val)
				neg_energ.append(tmp_data)
				neg_index.append(str(j))
		
		pos_energ2 = np.zeros(len(pos_energ),float)
		neg_energ2 = np.zeros(len(neg_energ),float)
		pos_energ_norm = np.zeros(len(pos_energ),float)
		neg_energ_norm = np.zeros(len(neg_energ),float)

		for k in range(len(pos_energ)):
			pos_tmp = float(0)
			pos_tmp = float(pos_energ[k])
			pos_energ2[k] = pos_tmp
		
		for l in range(len(neg_energ)):
			neg_tmp = float(0)
			neg_tmp = float(neg_energ[l])
			neg_energ2[l] = neg_tmp

		print(neg_energ2)

		pos_energ_norm = self.NORMMAX(pos_energ2)
		neg_energ_norm = self.NORMMIN(neg_energ2)

		ret_array2 = np.zeros(len(ret_array),float)

		for m in range(len(pos_index)):
			tmp_pos_ind = int(0)
			tmp_pos_ind = int(pos_index[m])
			ret_array2[tmp_pos_ind] = pos_energ_norm[m]

		for n in range(len(neg_index)):
			tmp_neg_ind = int(0)
			tmp_neg_ind = int(neg_index[n])
			ret_array2[tmp_neg_ind] = neg_energ_norm[n]
		# End.

		#average = float(0);std = float(0)
		#average = np.average(ret_array)
		#std = np.std(ret_array)
		#ret_array2 = (ret_array-average)/std
		#print ret_array
		return ret_array,ret_array2
		
	def GAMESS_COLOR2(self,en_array_norm,picked_resi,color_cons2,hideflag,picked_chain):
		#pick_in_py = int(picked_resi)-1
		#en_array_norm = np.zeros(len(norm_energy),float)
		#en_array_norm = NPARRAY2(norm_energy,en_array_norm)
		print(picked_resi)
		print(en_array_norm)

		Emax = float(0);Emin = float(0)
		Emax = ((np.max(en_array_norm))**2.0)**(0.50)
		Emin = ((np.min(en_array_norm))**2.0)**(0.50)
		hide_flag = int(0)
		
		hide_flag = hideflag
	
		col_cont = float(0)
		col_cont = float(color_cons2)
		
		cmd.color("white","all")
	
		res_selector = [];res_selector2 = []
	
		for res in range(len(picked_resi)):
			temp_res = [];temp_chain = []
			temp_res = str(picked_resi[res])
			temp_chain = str(picked_chain[res])
			res_selector.append("(resi ")
			res_selector.append(temp_res)
			res_selector.append(" & ")
			res_selector.append("chain ")
			res_selector.append(temp_chain)
			res_selector.append(")")
			if res==len(picked_resi)-1:
				continue
			res_selector.append("|")
		res_selector2 = ''.join(res_selector)
		#print res_selector2
	

		if hide_flag == int(1):
			cmd.hide("all")
			#cmd.select("selected_resi","((resi %(res_selector2)s)&!(resn HOH))"%vars())
			cmd.select("selected_resi","(%(res_selector2)s)&!(resn HOH)"%vars())
			cmd.show_as("cartoon","all")
			cmd.show_as("stick","selected_resi")
			cmd.set("cartoon_transparency","0.6","all")
			#cmd.set("stick_radius","0.15","all")
		
		elif hide_flag == int(0):
			cmd.hide("all")
			cmd.show_as("line","all")	
	
		#print Emin
	
		for i in range(len(en_array_norm)):
			r_color = float(0);g_color = float(0);b_color = float(0)
			Ei = float(0);in_pymol = int(0);in_chain = []
			in_pymol = int(picked_resi[i])
			in_chain = str(picked_chain[i])
			
			Ei = en_array_norm[i]
			if Ei < float(0):
				#b_color = 1.00
				#g_color = 1.00-(((-Ei)**col_cont)/(2.0*(Emin**col_cont)))
				#r_color = 1.00-(((-Ei)**col_cont)/(2.0*(Emin**col_cont)))
	
				r_color = 1.00
				g_color = 1.00-(((-Ei)**col_cont)/(2.0*(Emin**col_cont)))
				b_color = 1.00-(((-Ei)**col_cont)/(2.0*(Emin**col_cont)))
	
				cmd.set_color("temp_%(i)i"%vars(),[r_color,g_color,b_color])
				cmd.color("temp_%(i)i"%vars(),"(resi %(in_pymol)i & chain %(in_chain)s)&(!(resn HOH))"%vars())
			elif Ei == float(0):
				cmd.set_color("temp_%(i)i"%vars(),[1.0,1.0,1.0])
				cmd.color("temp_%(i)i"%vars(),"(resi %(in_pymol)i & chain %(in_chain)s)&(!(resn HOH))"%vars())
			elif Ei > float(0):
				#b_color = 1.00-((Ei**col_cont)/(2.0*(Emax**col_cont)))
				#g_color = 1.00-((Ei**col_cont)/(2.0*(Emax**col_cont)))
				#r_color = 1.00
	
				r_color = 1.00-((Ei**col_cont)/(2.0*(Emax**col_cont)))
				g_color = 1.00-((Ei**col_cont)/(2.0*(Emax**col_cont)))
				b_color = 1.00
	
				cmd.set_color("temp_%(i)i"%vars(),[r_color,g_color,b_color])
				cmd.color("temp_%(i)i"%vars(),"(resi %(in_pymol)i & chain %(in_chain)s)&(!(resn HOH))"%vars())
	
	
	def LIGPROEN(self,inp_file,input_dist,E_es_flag, E_ex_flag, E_ctmin_flag, E_disp_flag, G_sol_flag, E_total_flag, Eij_Ei_Ej_flag, TrdDij_flag,color_cons2,hideflag):
	
		input_dist2 = float(input_dist);chain_inf = []
		#150617
		resi,energy,chain_inf = self.RESIANDENERGY(inp_file)
	
		#print chain_inf
	
		within_dist = self.PICKDIST(energy,input_dist2)
		
		picked_energy = np.zeros([9,len(within_dist)],float)
		picked_resi = np.zeros(len(within_dist),int)
		picked_chain = []
		print(picked_energy)

		picked_energy,picked_resi,picked_chain = self.PICKEN(within_dist,energy,picked_energy,resi,picked_resi,chain_inf,picked_chain)
		
		#Select which of energy parameters will be used to color the strcuture.
		
		if E_es_flag == 1:
			energy_es = np.zeros(len(picked_energy[1]),float)
			en_es,norm_en_es = self.NORMEN(picked_energy[1],energy_es)
			self.GAMESS_COLOR2(norm_en_es,picked_resi,color_cons2,hideflag,picked_chain)
		elif E_ex_flag == 1:
			energy_ex = np.zeros(len(picked_energy[2]),float)
			en_ex,norm_en_ex = self.NORMEN(picked_energy[2],energy_ex)
			self.GAMESS_COLOR2(norm_en_ex,picked_resi,color_cons2,hideflag,picked_chain)
		elif  E_ctmin_flag == 1:
			energy_ctmin = np.zeros(len(picked_energy[3]),float)
			en_ctmin,norm_en_ctmin = self.NORMEN(picked_energy[3],energy_ctmin)
			self.GAMESS_COLOR2(norm_en_ctmin,picked_resi,color_cons2,hideflag,picked_chain)
		elif E_disp_flag == 1:
			energy_disp = np.zeros(len(picked_energy[4]),float)
			en_disp,norm_en_disp = self.NORMEN(picked_energy[4],energy_disp)
			self.GAMESS_COLOR2(norm_en_disp,picked_resi,color_cons2,hideflag,picked_chain)
		elif G_sol_flag == 1:
			energy_sol = np.zeros(len(picked_energy[5]),float)
			en_sol,norm_en_sol = self.NORMEN(picked_energy[5],energy_sol)
			self.GAMESS_COLOR2(norm_en_sol,picked_resi,color_cons2,hideflag,picked_chain)
		elif E_total_flag == 1:
			energy_total = np.zeros(len(picked_energy[6]),float)
			en_total,norm_en_total = self.NORMEN(picked_energy[6],energy_total)
			self.GAMESS_COLOR2(norm_en_total,picked_resi,color_cons2,hideflag,picked_chain)
		elif Eij_Ei_Ej_flag == 1:
			energy_eij = np.zeros(len(picked_energy[7]),float)
			en_eij,norm_en_eij = self.NORMEN(picked_energy[7],energy_eij)
			self.GAMESS_COLOR2(norm_en_eij,picked_resi,color_cons2,hideflag,picked_chain)
		elif TrdDij_flag == 1:
			energy_trd = np.zeros(len(picked_energy[8]),float)
			en_trd,norm_en_trd = self.NORMEN(picked_energy[8],energy_trd)
			self.GAMESS_COLOR2(norm_en_trd,picked_resi,color_cons2,hideflag,picked_chain)
	
		################################################
		#Output file creation
		################################################
		if os.path.isdir("output_int_lig"):
			os.system("rm -rf output_int_lig")
		
		os.mkdir("./output_int_lig")
		os.chdir("output_int_lig")
		
		outputfile_log = open("param.log",'w')
		#outputfile_log.write("Your selected residues number:%(residue_num)s\n"%vars())
		outputfile_log.write("Your inputted csv file is: %(inp_file)s\n"%vars())
		outputfile_log.write("energies which were normalized one: energies_norm.out\n"%vars())
		outputfile_log.write("energies which were not normalized one: energies_non_norm.out\n"%vars())
		outputfile_log.write("energies which were normalized one: energies_norm.out\n"%vars())
		
		outputfile_data = open("res_en_non_norm.out",'w')
		outputfile_data.write("res_num, dist, E_es, E_ex, E_ctmin, E_disp, G_sol, E_total, Eij-Ei-Ej, Tr(dDij*Vij)\n")
		self.OUTPUT(outputfile_data,picked_resi,picked_energy)
		outputfile_log.close()
		outputfile_data.close()
		
		os.chdir("../")



