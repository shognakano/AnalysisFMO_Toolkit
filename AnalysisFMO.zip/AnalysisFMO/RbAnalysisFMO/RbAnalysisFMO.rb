###########################################################################
#                                                                         #
#                                                                         #
#                          -*- coding: utf-8 -*-                          #
#                                                                         #
#                            < RbAnalysisFMO >                            #
#                                                                         #
#  Programing by T. Tokiwa (Ph.D. (Science), Tohoku University in 2019)   #
#  Date    :  2022/02/20                                                  #
#  Version :  3.02                                                        #
#                                                                         #
#  (References):                                                          #
#  1.                                                                     #
#   Takaki Tokiwa, Shogo Nakano, Yuta Yamamoto, Takeshi Ishikawa,         #
#   Sohei Ito, Vladimir Sladek, Kaori Fukuzawa, Yuji Mochizuki,           #
#   Hiroaki Tokiwa, Fuminori Misaizu, and Yasuteru Shigeta,               #
#   J. Chem. Inf. Model., 59, 25–30 (2019).                               #
#                                                                         #
#   - doi:10.1021/acs.jcim.8b00649                                        #
#                                                                         #
#  2.                                                                     #
#   Takaki Tokiwa , Shogo Nakano, Hiroaki Tokiwa, Yasuteru Shigeta,       #
#   "AnalysisFMO Toolkit: A PyMOL Plugin for 3D-Visualization of          #
#   Interaction Energies in Proteins (3D-VIEP) Calculated                 #
#   by the FMO Method.",                                                  #
#   Recent Advances of the Fragment Molecular Orbital Method,             #
#   Yuji Mochizuki, Shigenori Tanaka, Kaori Fukuzawa (eds.),              #
#   Springer Singapore, (2021).                                           #
#                                                                         #
#   - doi: 10.1007/978-981-15-9235-5_18                                   #
#   - Print ISBM:   978-981-15-9234-8                                     #
#   - Online ISBM:  978-981-15-9235-5                                     #
#                                                                         #
###########################################################################


#################
#*** Require ***#
#################

require 'pp'
require 'open3'      ### Be able to use "Open3" from Ruby ver. 1.9.3
require 'fileutils'  ### Be able to use "FileUtiles" from Ruby ver. 1.8.7
require 'logger'     ### Be able to use "logger" from Ruby ver. 1.8.7
require 'optparse'   ### Option parse
require 'bigdecimal' ### Provides arbitrary-precision floating point decimal arithmetic.
require 'kconv'      ### Encording (Kanji Converter for Ruby)
require 'time'       ### Time is an abstraction of dates and times
begin
  require 'nokogiri' ### To use xml module (Nokogiri), please "gem install nokogiri" on your system
                     ### But, nokogiri requires Ruby version >= 2.1.0
  xml_flag = true
rescue LoadError => e
#  puts "class=[#{e.class}] message=[#{e.message}]"
  xml_flag = false
end


###########################
#*** External encoding ***#
###########################

Encoding.default_external = 'UTF-8'


########################
#*** Global values ***#
########################

### Symbol (Chemistry): From H (1) to Og (118)
###  (Notice): $symbol[0] => H, $symbol[1] => He, $symbol[2] => Li, ...
$symbol = [
  "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne",
  "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca",
  "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
  "Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr",
  "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn",
  "Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd",
  "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb",
  "Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg",
  "Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th", 
  "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", 
  "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds", 
  "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og"
]

### Unit conversion
$h2kcalmol = 627.50948 ### 1 Hartree = 627.50948 kcal/mol
$h2kjmol = 2625.4997   ### 1 Hartree = 2625.4997 kJ/mol
$h2ev = 27.211386      ### 1 Hartree = 27.211386 eV

### Verion and update of this program
$last_update = "2021/12/30"
$version = "3.01"

### References of this program 
$references = " (References)\n  1.\n"
$references = $references + "   Takaki Tokiwa, Shogo Nakano, Yuta Yamamoto, Takeshi Ishikawa,\n"
$references = $references + "   Sohei Ito, Vladimir Sladek, Kaori Fukuzawa, Yuji Mochizuki,\n"
$references = $references + "   Hiroaki Tokiwa, Fuminori Misaizu, and Yasuteru Shigeta,\n"
$references = $references + "   J. Chem. Inf. Model., 59, 25–30 (2019).\n\n"
$references = $references + "   - doi:10.1021/acs.jcim.8b00649\n\n"
$references = $references + "  2.\n"
$references = $references + "   Takaki Tokiwa , Shogo Nakano, Hiroaki Tokiwa, Yasuteru Shigeta,\n"
$references = $references + "   \"AnalysisFMO Toolkit: A PyMOL Plugin for 3D-Visualization of\n"
$references = $references + "   Interaction Energies in Proteins (3D-VIEP) Calculated\n"
$references = $references + "   by the FMO Method.\",\n"
$references = $references + "   Recent Advances of the Fragment Molecular Orbital Method,\n"
$references = $references + "   Yuji Mochizuki, Shigenori Tanaka, Kaori Fukuzawa (eds.),\n"
$references = $references + "   Springer Singapore, (2021).\n\n"
$references = $references + "   - doi: 10.1007/978-981-15-9235-5_18\n"
$references = $references + "   - Print ISBM:   978-981-15-9234-8\n"
$references = $references + "   - Online ISBM:  978-981-15-9235-5\n\n"



###############
#*** Class ***#
###############

#************************************#
#***    Measure execution time    ***#
#************************************#
class Work_Time
  def initialize
    @start_time = Time.now
  end
  
  ### Calculate execution time (h/m/s)
  def done(text_flag, log)
    end_time = Time.now
    work_time = (end_time - @start_time).to_i
    hour = work_time / 3600
    min = (work_time % 3600) / 60
    sec = (work_time % 3600) % 60
             
    log.info "\n", "******************", "", text_flag
    log.info "",   "* Execution time *", "", text_flag
    log.info "",   "******************", "", text_flag
    log.info "", "<Start time>:     #{@start_time.strftime("%Y/%m/%d %H:%M:%S")}", \
             "", text_flag
    log.info "", "<End time>:       #{end_time.strftime("%Y/%m/%d %H:%M:%S") }", \
             "", text_flag
    log.info "", "<Execution time>: #{hour}h #{min}m #{sec}s", "\n", text_flag
  end
end


#******************************************************************#
#***    Class for logger and STDOUT of logger simultaneously    ***#
#******************************************************************#
class PLogger
  def initialize(*args)
    @stdout = Logger.new STDOUT
    @log = Logger.new *args
    
    ### Set LOGGER level, output INFO level or more
    ### DEBUG < INFO < WARN < ERROR < FATAL < UNKNOWN
    @log.level = Logger::INFO
    ### Declare logger format for log
    @log.formatter = PLogger::Log_Formatter.new
    
    ### Set LOGGER level, output INFO level or more
    ### DEBUG < INFO < WARN < ERROR < FATAL < UNKNOWN
    @stdout.level = Logger::INFO
    ### Declare logger format for STDOUT
    @stdout.formatter = PLogger::STD_Formatter.new
  end

  def close
    @log.close
  end
  
  %w(debug info warn error fatal).each do |level|
    define_method(level) do |*args|
      ### ARGV index
      ### [0]  ==>  "" or "\n", before first word
      ### [1]  ==>  text for display and write
      ### [2]  ==>  "" or "\n", after final word
      ### [3]  ==>  true or false (Flag for display text)
      @log.send level, args[1]
      if args[3] then
        @stdout.send level, args[0] + args[1] + args[2]
      end
    end
  end
  
  ### Logger format
  class Log_Formatter < ::Logger::Formatter
    def call(severity, time, progname, msg)
      ### [20YY-MM-DD HH:MM:SS:msec #processID]
      format = "[%s #%d] %5s -- %s: %s\n"
      format % ["#{time.strftime('%Y-%m-%d %H:%M:%S')}.#{'%06d' % time.usec.to_s}",
                $$, severity, progname, msg2str(msg)]
    end
  end
  
  ### STDOUT format in logger
  class STD_Formatter < ::Logger::Formatter
    def call(severity, time, progname, msg)
      format = "%s\n"
      format % [msg2str(msg)]
    end
  end
end


#*****************************************************#
#***         Class for Options and ARGV            ***#
# (Ref.):                                             #
#  http://qiita.com/sonots/items/1b44ed3a770ef790a63d #
#*****************************************************#
class Opt
  def initialize(opts = {}, flags = {})
    @@opts = opts
    @@flags = flags
  end
  
  class CLI < Opt ### Command Line Interface
    def parse_options(input_array = ARGV)
      ### Init
      numeric_count = 0
      opt_count = 0

      op = OptionParser.new
      
      self.class.module_eval do
        define_method(:Usage) do |msg = nil|
          argv_log.error "\n", "#{op.to_s}", "",  @@opts[:text]
          argv_log.error "", "Error: #{msg}", "", @@opts[:text] if msg
          exit(1);
        end
      end
      
      ### Directory for log file of ARGV error
      ### Return absolute "relative" path to the this file from current execution directory
      current_exe_dir = File.expand_path(File.dirname(__FILE__))

      ### log file name for ARGV error
      error_log_file = File.join(current_exe_dir, "options-error_RbAnalysisFMO.log")

      ### Remove old log file
      FileUtils.rm_rf(error_log_file)
      ### Create new log file
      argv_log ||= PLogger.new error_log_file

      op.program_name = File.basename($0)

      op.banner = "\nUsage: ruby #{op.program_name} [options]  or  ruby #{op.program_name}"

      op.separator ''
      op.separator 'Examples:'
      op.separator ' - Option mode'
      op.separator "    $ ruby #{op.program_name} -opt1 -opt2 ..."
      op.separator ''
      op.separator ' - Terminal mode (without options)'
      op.separator "    $ ruby #{op.program_name}"
      op.separator "      * If you execute this program without options,"
      op.separator "        you input character string instead of options on your terminal."

      op.separator ''
      op.separator 'Specific options:'

      op.on('-t', '--text', "Don\'t show text on terminal with \"-t\" (No option: show text)") {|v|
        @@opts[:text] = !v
      }
      op.separator ''

      op.on('-f', '--fmo VALUE', Integer, "Calculation program name of the FMO method") { |v|
        if !(/^[1-3]$/ =~ v.to_s)
          argv_log.error "\nError: ", "-f option", "",  @@opts[:text]
          argv_log.error "Error: ", "Input argment value of FMO option is not 1 or 2, 3!!", "\n", @@opts[:text]
        else
          @@opts[:fmo] = v
          @@flags[:fmo] = true
          opt_count += 1
        end
      }
      op.separator '                                       [1]: PAICS, [2]: GAMESS, [3]: ABINIT-MP or ABINIT-MP Open'
      op.separator ''

      op.on('-r', '--out VALUE', "Calculated FMO Out file name (/path/.../*.out or /path/.../*.log, and so on)") { |v|
        @@opts[:out] = v.tr("'", "")

        @@flags[:out] = true
        opt_count += 1
      }
      op.separator '                                     Specify the (full) path of the FMO out file'
      op.separator ''

      op.on('-b', '--pdb VALUE', "PDB file name (/path/.../*.pdb)") { |v|
        @@opts[:pdb] = v.tr("'", "")

        @@flags[:pdb] = true
        opt_count += 1
      }
      op.separator '                                     Specify the (full) path of the PDB file'
      op.separator ''

      op.on('-o', '--output VALUE', "Output file name (/path/.../*.[extansion])") { |v|
        @@opts[:output] = v.tr("'", "")

        @@flags[:output] = true
        opt_count += 1
      }
      op.separator '                                     Specify the (full) path of an output file name to write analysis data'
      op.separator '                                     * Format of ouptut file is "TEXT format only", '
      op.separator '                                       you specify any extension for yourelf.'
      op.separator ''

      op.on('-c', '--ac VALUE', Integer, "Select to output a new PDB file adding chain identifier: \"A\" (dafults: #{@@opts[:add_chain]})") { |v|
        if !(/^[1-2]$/ =~ v.to_s) then
          argv_log.error "\nError: ", "-c option", "",  @@opts[:text]
          argv_log.error "Error: ", "Input argment value of new chain identifier option is not 1 or 2!!", "\n", @@opts[:text]
        else
          @@opts[:add_chain] = v
          @@flags[:add_chain] = true
          opt_count += 1
        end
      }
      op.separator '                                       [1]: To continue normally (this process is nothing)'
      op.separator '                                       [2]: Output a new PDB file replacing raw identifier to "A"'
      op.separator '                                          If chain identifier is a white space in the original PDB file'
      op.separator '                                        * Warning is issued when there is chain identifier in the original PDB file.'
      op.separator ''

      op.on('-g', '--gp', "Plot energies as fragments-ligand (target) interactions in the bar graph using Gnuplot") { |v|
        @@opts[:gnuplot] = !v
      }
      op.separator '                                       a). Without "-gp" option'
      op.separator '                                           Make PDF files usign ps2pdf after ploting energies as PS file using Gnuplot'
      op.separator '                                       b). With "-gp" option'
      op.separator '                                           Do not plot data in a bar graph'
      op.separator ''

      op.separator '   * Ignore -d and -a options if "with -gp option" !!'
      op.on('-d', '--distance one,two', Array, "Distance in plot (dafults: #{@@opts[:distance]} [A] or [%])") { |v|
        if !(v.size == 2) then
          argv_log.error "\n\nError: ", "-d option", "",  @@opts[:text]
          argv_log.error "Error: ", "Input argment value of distance option is not two numerical values!!", "\n", @@opts[:text]
        else
          for i in 0..1
#            if (/^[0-9]*[\.]?[0-9]+$/ =~ v[i]) then  ### Data is numerical?
            if (/^[+]?[0-9]+(\.?[0-9]*)$/ =~ v[i].to_s) then  ### Data is numerical?
              numeric_count += 1
            end
          end
          if (numeric_count != 2) then
            argv_log.error "\nError: ", "-d option", "",  @@opts[:text]
            argv_log.error "Error: ", "Input argment value of distance option is not two numerical values!!", "\n", @@opts[:text]
          elsif (v[0].to_f > v[1].to_f) then
            argv_log.error "\nError: ", "-d option", "",  @@opts[:text]
            argv_log.error "Error: ", "Your values are (min value) > (max value)!!", "\n", @@opts[:text]
            argv_log.error "Error: ", "You must need to specify (min value) < (max value)!!", "\n", @@opts[:text]
          else
            @@opts[:distance] = v.map!{|x| x.to_f}
            @@flags[:distance] = true
            opt_count += 1 unless @@opts[:gnuplot]
          end
        end
      }
      op.separator '                                << PAICS >> and << ABINIT-MP >>'
      op.separator '                                 -d [ (int or float) Minimum distance (R1) [Angstrom] ] [ (int or float) Maximum distance (R2) [Angstrom] ]'
      op.separator '                                     Specify data range [Angstrom] (distance between fragments) to extract data'
      op.separator '                                     (ex). Extract data within distance between R1=0 [Angstrom] and R2=5 [Angstrom]'
      op.separator '                                          -d 0,5    or    -d 0.0,5.0'
      op.separator '                                << GAMESS >>'
      op.separator '                                 -d [ (int or float) Minimum distance (R1) ] [ (int or float) Maximum distance (R2) ]'
      op.separator '                                     Specify data range (distance (R) between fragments) to extract data'
      op.separator '                                       (Ref.): R is written in "RESPAP" on http://myweb.liu.edu/~nmatsuna/gamess/input/FMO.html'
      op.separator '                                               the distance is relative to van der Waals radii; '
      op.separator '                                               e.g. two atoms A and B separated by R are defined to have the distance equal to R/(RA+RB), '
      op.separator '                                               where RA and RB are van der Waals radii of A and B).'
      op.separator '                                               * R has no units.'
      op.separator '                                     (ex). Extract data within distance between R1=0.5 and R2=2.0'
      op.separator '                                          -d 0.5,2.0    or    -d 0.5,2'
      op.separator '                                   <Test data>: System of test including ca. 280 fragments'
      op.separator '                                     - 0 <= R <= 1.0: => Output and plot ca. 15 / 280 fragments'
      op.separator '                                     - 0 <= R <= 1.5: => Output and plot ca. 35 / 280 fragments'
      op.separator '                                     - 0 <= R <= 2.0: => Output and plot ca. 50 / 280 fragments'
      op.separator '                                  * Notice: (condition: R1 >= 0, R2 > R1)'
      op.separator ''

      op.on('-a', '--aaletter VALUE', Integer, "Amino acid letter code in plot (dafults: #{@@opts[:aaletter]})") { |v|
        if !(/^[1-2]$/ =~ v.to_s) then
          argv_log.error "\nError: ", "-a option", "",  @@opts[:text]
          argv_log.error "Error: ", "Input argment value of Amino aicd letter code option is not 1 or 2!!", "\n", @@opts[:text]
        else
          @@opts[:aaletter] = v
          @@flags[:aaletter] = true
          opt_count += 1 unless @@opts[:gnuplot]
        end
      }
      op.separator '                                     Select the animo acid name type (1 letter code or 3 letter code)'
      op.separator '                                       [1]: Amino Acid 1 letter code'
      op.separator '                                            (ex. Glycine name is "G")'
      op.separator '                                       [2]: Amino Aicd 3 letter code'
      op.separator '                                            (ex. Glycine name is "GLY")'
      op.separator ''

      op.on('-p', '--PAICS VALUE', Integer, "PAICS program version (dafults: [#{@@opts[:paics]}] = \"2012/05/13 version or later\")") { |v|
        if !(/^[1-2]$/ =~ v.to_s) then
          argv_log.error "\nError: ", "-p option", "",  @@opts[:text]
          argv_log.error "Error: ", "Input argment value of PAICS Version option is not 1 or 2!!", "\n", @@opts[:text]
        else
          @@opts[:paics] = v
          @@flags[:paics] = true
          opt_count += 1
        end
      }
      op.separator '                                       [1]: Older versions than PAICS 2012/01/17 version'
      op.separator '                                       [2]: PAICS 2012/05/13 version or later'
      op.separator '                                         * This option is PAICS only!!'
      op.separator ''

=begin
      op.on('-e', '--inp VALUE', Integer, "Select a software (or script, plugin) for creating PAICS input file (*.inp) (dafults: #{opts[:inp]})") { |v|
        if !(/^[1-2]$/ =~ v.to_s) then
          argv_log.error "\nError: ", "-e option", "",  @@opts[:text]
          argv_log.error "Error: ", "Input argment value of PAICS input option is not 1 or 2!!", "\n", @@opts[:text]
        else
          @@opts[:inp] = v
          @@flags[:inp] = true
          opt_count += 1
        end
      }
      op.separator '                                       [1]: PaicsView (PV) programing by T. Ishikawa'
      op.separator '                                       [2]: PaicsPy_input on PyMOL programing by S. Nakano'
      op.separator '                                         * This option is PAICS only!!'
      op.separator ''
=end

      op.on('-i', '--interaction VALUE', Integer, "Select IFIE or PIEDA interaction type (Selected-pairs or All-pairs)") { |v|
        if !(/^[1-2]$/ =~ v.to_s) then
          argv_log.error "\nError: ", "-i option", "",  @@opts[:text]
          argv_log.error "Error: ", "Input argment value of interaction option is not 1 or 2!!", "\n", @@opts[:text]
        else
          @@opts[:interaction] = v
          @@flags[:interaction] = true
          opt_count += 1
        end
      }
      op.separator '                                       [1]: Selected-pairs mode in "one-dimensional" table'
      op.separator '                                          To analyzes IFIEs as [fragments]-[user\'s selected target] (fragment, ligand, peptide, H2O and so on) interaction'
      op.separator '                                          (selection of the fragment pairs, such as fragment number 1-100 (ALL) and fragment number 101(user\'s selected target))'
      op.separator '                                       [2]: All-pairs mode in "two-dimensional" table'
      op.separator '                                          To analyzes IFIEs as [fragments]-[fragments] (which may be included ligand, peptide, H2O and so on) interaction '
      op.separator '                                       * Notice:'
      op.separator '                                        << PAICS >>'
      op.separator '                                          - PAICS output with the "frag_calc_pair" option    => [1]: Selected-pairs mode'
      op.separator '                                          - PAICS output without the "frag_calc_pair" option => [2]: All-pairs mode'
      op.separator '                                            (that is, results of PAICS for all fragment calculation)'
      op.separator '                                          <Ref.>: Chapter 2. INPUT, P. 14 in PAICS manual (URL: http://www.paics.net/pdf/manual.pdf)'
      op.separator '                                        << GAMESS >>'
      op.separator '                                          - GAMESS-FMO output with no option              => [1]: Selected-pairs mode'
      op.separator '                                          - GAMESS-FMO output with the "MOLFRG(i)" option => [2]: All-pairs mode'
      op.separator '                                          <Ref.>: http://myweb.liu.edu/~nmatsuna/gamess/input/FMO.html'
      op.separator '                                        << ABINIT-MP >>'
      op.separator '                                          As of September 5th, 2018, ABINIT-MP or ABINIT-MP Open can calculate the FMO output of "All-pairs mode only"!'
      op.separator '                                          But, This program can extract data of "one-dimensional" table from the FMO output of "All-pairs mode"'
      op.separator '                                          as well as GAMESS and PAICS'
      op.separator ''

      op.on('-k', '--mode VALUE', Integer, "Select the type of energy data of ABINIT-MP (IFIE or PIEDA)") { |v|
        if !(/^[1-2]$/ =~ v.to_s) then
          argv_log.error "\nError: ", "-k option", "",  @@opts[:text]
          argv_log.error "Error: ", "Input argment value of type of energy data of ABINIT-MP (IFIE or PIEDA) option is not 1 or 2!!", "\n", @@opts[:text]
        else
          @@opts[:abinitmp] = v
          @@flags[:abinitmp] = true
          opt_count += 1
        end
      }
      op.separator '                                       [1]: IFIE energy (including HF, dMP2, MP2)'
      op.separator '                                       [2]: PIEDA energy (including E(total), E(es), E(ex), E(ct+mix), E(di))'
      op.separator '                                        * Notice:' 
      op.separator '                                         (1). If using [2], ABINIT-MP "Open" version or later!!'
      op.separator '                                         (2). This option is ABINIT-MP or ABINIT-MP Open only!!'
      op.separator ''

      op.on('-m', '--mode VALUE', Integer, "Select the write mode (type of energy data)") { |v|
        if !(v.to_s =~ /^[0-9]+$/) then
          argv_log.error "\nError: ", "-m option", "",  @@opts[:text]
          argv_log.error "Error: ", "Input argment value of write mode (type of energy data) option is not integer!!", "\n", @@opts[:text]
        else 
          @@opts[:mode] = v
          @@flags[:mode] = true
          opt_count += 1
        end
      }
      op.separator '                                     - PAICS (Selected-pairs mode in "one-dimensional" table)'
      op.separator '                                        [1]: HF   (a.u.) and HF   [kcal/mol]'
      op.separator '                                        [2]: dMP2 (a.u.) and dMP2 [kcal/mol]'
      op.separator '                                        [3]: MP2  (a.u.) and MP2  [kcal/mol] (All data)'
      op.separator '                                     - PAICS (All-pairs mode in "two-dimensional" table)'
      op.separator '                                        [1]: HF   (a.u.)'
      op.separator '                                        [2]: HF   [kcal/mol]'
      op.separator '                                        [3]: dMP2 (a.u.)'
      op.separator '                                        [4]: dMP2 [kcal/mol]'
      op.separator '                                        [5]: MP2  (a.u.)'
      op.separator '                                        [6]: MP2  [kcal/mol]'
      op.separator '                                     - GAMESS (Selected-pairs mode in "one-dimensional" table)'
      op.separator '                                        without option and output all data(above [1]~[8] at All-pairs mode)'
      op.separator '                                     - GAMESS (All-pairs mode in "two-dimensional" table)'
      op.separator '                                        [1]: E(es)     (Electrostatic)                [kcal/mol]'
      op.separator '                                        [2]: E(ex)     (Exchange repulsion)           [kcal/mol]'
      op.separator '                                        [3]: E(ct+mix) (charge transfer + MIX)        [kcal/mol]'
      op.separator '                                        [4]: E(disp)   (Dispersion)                   [kcal/mol]'
      op.separator '                                        [5]: G(sol)    (Solvation free energy)        [kcal/mol]'
      op.separator '                                        [6]: E(total)  (PIE:(pair interaction energy) [kcal/mol]'
      op.separator '                                        [7]: E_{ij} - E_{i} - E_{j}                   [kcal/mol]'
      op.separator '                                        [8]: Tr(dD^{ij}*V^{ij})                       [kcal/mol]'
      op.separator '                                     - ABINIT-MP (Selected-pairs mode in "one-dimensional" table)'
      op.separator '                                       < IFIE >'
      op.separator '                                        [1]: HF   (a.u.) and HF   [kcal/mol]'
      op.separator '                                        [2]: dMP2 (a.u.) and dMP2 [kcal/mol]'
      op.separator '                                        [3]: MP2  (a.u.) and MP2  [kcal/mol] (All data)'
      op.separator '                                       < PIEDA >'
      op.separator '                                        without option and output all data(above [1]~[5] at <PIEDA> of All-pairs mode)'
      op.separator '                                     - ABINIT-MP (All-pairs mode in "two-dimensional" table)'
      op.separator '                                       < IFIE >'
      op.separator '                                        [1]: HF   (a.u.)'
      op.separator '                                        [2]: HF   [kcal/mol]'
      op.separator '                                        [3]: dMP2 (a.u.)'
      op.separator '                                        [4]: dMP2 [kcal/mol]'
      op.separator '                                        [5]: MP2  (a.u.)'
      op.separator '                                        [6]: MP2  [kcal/mol]'
      op.separator '                                       < PIEDA >'
      op.separator '                                        [1]: E(es)     (Electrostatic)                [kcal/mol]'
      op.separator '                                        [2]: E(ex)     (Exchange repulsion)           [kcal/mol]'
      op.separator '                                        [3]: E(ct+mix) (charge transfer + MIX)        [kcal/mol]'
      op.separator '                                        [4]: E(disp)   (Dispersion) = E(di(MP2))      [kcal/mol]'
      op.separator '                                        [5]: E(total)  (PIE:(pair interaction energy) [kcal/mol]'
      op.separator '                                             * E(total) = E(es) + E(ex) + E(ct+mix) + E(di)'
      op.separator ''

      op.separator '   * Using -j (--fragment) options if "-i 2" (All-pairs mode) only!!'
      op.on('-j', '--fragment one,two', Array, "Extract data range between i and j fragment [fragment number]") { |v|
        if (v[0] == "all") then
          v[0] = 1
          v[1] = 0  ### Then, insert max fragment number
          @@opts[:fragment] = v.map!{|x| x.to_i}
          @@flags[:fragment] = true
        else
          for i in 0..1
            if (v[i].to_i == 0) then
              argv_log.error "\nError: ", "-j (--fragment) option", "",  @@opts[:text]
              argv_log.error "Error: ", "Input argment value is Zero!!", "\n", @@opts[:text]
            elsif (/^[0-9]+$/ =~ v[i].to_s) then  ### Data is numerical? and not zero
              numeric_count += 1
            end
          end
          if (numeric_count != 2) then
           argv_log.error "\nError: ", "-j (--fragment) option", "",  @@opts[:text]
           argv_log.error "Error: ", "Input argment value of fragment option is not two numerical values!!", "\n", @@opts[:text]
          else
            if (v[0].to_i <= v[1].to_i) then
              argv_log.error "\nError: ", "-j (--fragment) option", "",  @@opts[:text]
              argv_log.error "Error: ", "Two input numerical values must be \"(ifrag < jfrag)\"!!", "\n", @@opts[:text]
            else
              @opts[:fragment] = v.map!{|x| x.to_i}
              @flags[:fragment] = true
            end
          end
        end
      }
      op.separator '                                 -j [ifrag],[jfrag]   or   -j all'
      op.separator '                                     Specify fragment number range (between ifragment and jfragment) to extract data'
      op.separator '                                      * (ifrag < jfrag) and value is not zero'
      op.separator '                                     1. -j [ifrag],[jfrag]'
      op.separator '                                       (ex). Extract data from residue sequence number 300 to residue sequence number 400'
      op.separator '                                          -j 300,400'
      op.separator '                                     2. -j all'
      op.separator '                                       Extract all data (from residue sequence number 1 to max residue sequence number)'
      op.separator ''

      op.on('-x', '--xml', "Output XML (Extensible Markup Language) data file from PDB and Out file, if you type this option") {|v|
        @@opts[:xml] = v
      }
      op.separator ''

      op.separator '   * Using -n (--num) options if "-i 1" (ligand-interaction mode) and calculation type is "All-pairs"!!'
      op.on('-n', '--num VALUE', Integer, 'Extract data using a particular fragment number in All-pairs calculation with option of "Selected-pairs mode"') {|v|
        @@opts[:ligand_num] = v
        @@flags[:ligand_num] = true
      }
      op.separator ''

      op.separator 'Common options:'
      op.on_tail('-h', '--help', 'show this help message and exit') do
        puts op
        puts ""
        ### Remove ARGV error log file if ARGV options have no error
        argv_log.close
        if File.read(error_log_file).count("\n") == 1 then ### No error in options
          FileUtils.rm_rf(error_log_file)
        end
        exit
      end
      op.on_tail('-v', '--version', 'show program\'s version number and the last updated time') do
        op.version = $version
        puts "\n\n #{op.program_name}  Ver. #{op.version}"
        puts "  - Last updated at #{$last_update}\n\n"
        puts $references
        ### Remove ARGV error log file if ARGV options have no error
        argv_log.close
        if File.read(error_log_file).count("\n") == 1 then ### No error in options
          FileUtils.rm_rf(error_log_file)
        end
        exit
      end

      begin
        args = op.parse(input_array)
      rescue OptionParser::InvalidOption => e
        usage e.message
      end

=begin
     ### Check number of option with -t option if results was calculated by PAICS program
     if !(opts[:text]) then
       if !(opts[:gnuplot]) then
         check_opt(opt_count, 8, argv_log, opts[:text])
       else
         check_opt(opt_count, 10, argv_log, opts[:text])
       end
     end
=end
      ### Remove ARGV error log file if ARGV options have no error
      argv_log.close
      if File.read(error_log_file).count("\n") == 1 then ### No error in options
        FileUtils.rm_rf(error_log_file)
      end
    end

    #*** Check the number of options with -t option ***#
    def check_opt(num_of_opt, max_opt, argv_log, text_flag)
      if (num_of_opt != max_opt) then
        argv_log.error "\nError: ", "-t option", "", text_flag
        argv_log.error "Error: ", "If \"-t\" option is supplied, you must specify \"all\" option arguments for this program!!\n", "\n", text_flag 
#        exit(1);
      end
    end

    def test_run
      puts "opts: #{@@opts.to_s}"
      puts "flags: #{@@flags.to_s}"
    end
  end
end


#****************************************************#
#***    Class for Options and ARGV on terminal    ***#
#****************************************************#
class Terminal_input < Opt
  def initialize
    super(@@opts, @@flags)
  end
  
  #*** Check options on terminal ***#
  def check_main_opt_flag
    i = 0
    loop_flag = true      ### true is while loop continue, false is while loop break
    log_index = 0         ### Array index for log file
    log_data = []         ### log text data for log file
#    dmp2_line = ["", ""]  ### [0]: Start line of calculated dMP2 data by PAICS
#                          ### [1]: End line of calculated dMP2 data by PAICS

    if !(@@flags[:fmo]) then ### Type of FMO program
      while loop_flag do
        log_data[log_index] = "Please select a FMO calculation program!"
        log_index += 1
        log_data[log_index] = "============================"
        log_index += 1
        log_data[log_index] = "PAICS               : [1]"
        log_index += 1
        log_data[log_index] = "GAMESS              : [2]"
        log_index += 1
        log_data[log_index] = "ABINIT-MP           : [3]"
        log_index += 1
        log_data[log_index] = "Exit                : [exit]"
        log_index += 1
        log_data[log_index] = "============================"
        log_index += 1
        if @@opts[:text] then
          puts ""
          for i in i..(log_index - 1)
            puts "#{log_data[i]}"
          end
        end
        fmo = STDIN.gets.chomp.strip
        log_data[log_index] = ""
        log_index += 1
        i = log_index

        if (/^[1-3]$/ =~ fmo) then
          @@opts[:fmo] = fmo.to_i
          loop_flag = false
        elsif fmo == "exit" then
          exit_system(@@opts[:text])
        else
          log_data[log_index] = "Your select is wrong!!"
          log_index += 1
        end
      end
    end

    if @@opts[:fmo] == 1 then ### PAICS
      loop_flag = true
      if !(@@flags[:paics]) then  ### PAICS ver
        while loop_flag do
          log_data[log_index] = "Please select the version of PAICS program!"
          log_index += 1
          log_data[log_index] = "===================================================="
          log_index += 1
          log_data[log_index] = "Older version than PAICS 2012/01/17 version : [1]"
          log_index += 1
          log_data[log_index] = "PAICS 2012/05/13 version                    : [2]"
          log_index += 1
          log_data[log_index] = "Exit                                        : [exit]"
          log_index += 1
          log_data[log_index] = "===================================================="
          log_index += 1
          if @@opts[:text] then
            puts ""
            for i in i..(log_index - 1)
              puts "#{log_data[i]}"
            end
          end
          paics = STDIN.gets.chomp.strip
          log_data[log_index] = ""
          log_index += 1
          i = log_index
          case paics
          when "1"
            @@opts[:paics] = paics.to_i
#            dmp2_line[0] = "        < cmp2 ifie -- resolution of identity >"
#            dmp2_line[1] = "        < rhf result ( fmo-2 ) >"
            loop_flag = false
          when "2"
            @@opts[:paics] = paics.to_i
#            dmp2_line[0] = "        < ri-cmp2 ifie >"
#            dmp2_line[1] = "        < rhf total energy ( fmo-2 ) >"
            loop_flag = false
          when "exit"
            exit_system(@@opts[:text])
          else
            log_data[log_index] = "Your select is wrong!!"
            log_index += 1
          end
        end
      end
=begin
      loop_flag = true
      if !(@@flags[:inp]) then ### PAICS input program
        while loop_flag do
          log_data[log_index] = "Please select PaicsView or PaicsPy_input for making PAICS input file!"
          log_index += 1
          log_data[log_index] = "========================================================"
          log_index += 1
          log_data[log_index] = "PaicsView (PV) programing by T. Ishikawa        : [1]"
          log_index += 1
          log_data[log_index] = "PaicsPy_input on PyMOL programing by S. Nakano  : [2]"
          log_index += 1
          log_data[log_index] = "Exit                                            : [exit]"
          log_index += 1
          log_data[log_index] = "========================================================"
          log_index += 1
          if @@opts[:text] then
            puts ""
            for i in i..(log_index - 1)
              puts "#{log_data[i]}"
            end
          end
          inp = STDIN.gets.chomp.strip
          log_data[log_index] = ""
          log_index += 1
          i = log_index
          if (/^[1-2]$/ =~ inp) then
            @@opts[:inp] = inp.to_i
            loop_flag = false
          elsif inp == "exit" then
            exit_system(opts[:text])
          else
            log_data[log_index] = "Your select is wrong!!"
            log_index += 1
          end
        end
      end
=end
      loop_flag = true
      if !(@@flags[:interaction]) then ### Interaction type (Selected-pairs or All-pairs)
        while loop_flag do
          log_data[log_index] = "Please select the interaction type (Selected-pairs or All-pairs)"
          log_index += 1
          log_data[log_index] = "=========================================================="
          log_index += 1
          log_data[log_index] = "Selected-pairs mode in \"one-dimensional\" table    : [1]"
          log_index += 1
          log_data[log_index] = "All-pairs mode in \"two-dimensional\" table         : [2]"
          log_index += 1
          log_data[log_index] = "Exit                                              : [exit]"
          log_index += 1
          log_data[log_index] = "=========================================================="
          log_index += 1
          if @@opts[:text] then
            puts ""
            for i in i..(log_index - 1)
              puts "#{log_data[i]}"
            end
          end
          interaction = STDIN.gets.chomp.strip
          log_data[log_index] = ""
          log_index += 1
          i = log_index

          if (/^[1-2]$/ =~ interaction) then
            @@opts[:interaction] = interaction.to_i
            loop_flag = false
          elsif interaction == "exit" then
            exit_system(@@opts[:text])
          else
            log_data[log_index] = "Your select is wrong!!"
            log_index += 1
          end
        end
      end

      loop_flag = true
      if !(@@flags[:mode]) then ### Write mode
        if (@@opts[:interaction] == 1) then ### Selected-pairs mode
          while loop_flag do
            log_data[log_index] = "Please select write mode (at Selected-pairs mode)!"
            log_index += 1
            log_data[log_index] = "========================================"
            log_index += 1
            log_data[log_index] = "HF   (a.u.) and HF   [kcal/mol] : [1]"
            log_index += 1
            log_data[log_index] = "dMP2 (a.u.) and dMP2 [kcal/mol] : [2]"
            log_index += 1
            log_data[log_index] = "MP2  (a.u.) and MP2  [kcal/mol] : [3]"
            log_index += 1
            log_data[log_index] = "Exit                            : [exit]"
            log_index += 1
            log_data[log_index] = "========================================"
            log_index += 1
            if @@opts[:text] then
              puts ""
              for i in i..(log_index - 1)
                puts "#{log_data[i]}"
              end
            end
            mode = STDIN.gets.chomp.strip
            log_data[log_index] = ""
            log_index += 1
            i = log_index
            if (/^[1-3]$/ =~ mode) then
              @@opts[:mode] =mode.to_i
              loop_flag = false
            elsif mode == "exit" then
              exit_system(@@opts[:text])
            else
              log_data[log_index] = "Your select is wrong!!"
              log_index += 1
            end
          end
        elsif (@@opts[:interaction] == 2) then ### All-pairs mode
          while loop_flag do
            log_data[log_index] = "Please select write mode (at All-pairs mode)!"
            log_index += 1
            log_data[log_index] = "========================"
            log_index += 1
            log_data[log_index] = "HF   (a.u.)     : [1]"
            log_index += 1
            log_data[log_index] = "HF   [kcal/mol] : [2]"
            log_index += 1
            log_data[log_index] = "dMP2 (a.u.)     : [3]"
            log_index += 1
            log_data[log_index] = "dMP2 [kcal/mol] : [4]"
            log_index += 1
            log_data[log_index] = "MP2  (a.u.)     : [5]"
            log_index += 1
            log_data[log_index] = "MP2  [kcal/mol] : [6]"
            log_index += 1
            log_data[log_index] = "Exit            : [exit]"
            log_index += 1
            log_data[log_index] = "========================"
            log_index += 1
            if @@opts[:text] then
              puts ""
              for i in i..(log_index - 1)
                puts "#{log_data[i]}"
              end
            end
            mode = STDIN.gets.chomp.strip
            log_data[log_index] = ""
            log_index += 1
            i = log_index
            if (/^[1-6]$/ =~ mode) then
              @@opts[:mode] =mode.to_i
              loop_flag = false
            elsif mode == "exit" then
              exit_system(@@opts[:text])
            else
              log_data[log_index] = "Your select is wrong!!"
              log_index += 1
            end
          end
        end
      end
    elsif @@opts[:fmo] == 2 then ### GAMESS
      loop_flag = true
      if !(@@flags[:interaction]) then ### Interaction type (Selected-pair or All-pairs)
        while loop_flag do
          log_data[log_index] = "Please select the interaction type (Selected-pairs or All-pairs)"
          log_index += 1
          log_data[log_index] = "=========================================================="
          log_index += 1
          log_data[log_index] = "Selected-pairs mode in \"one-dimensional\" table    : [1]"
          log_index += 1
          log_data[log_index] = "All-pairs mode in \"two-dimensional\" table         : [2]"
          log_index += 1
          log_data[log_index] = "Exit                                              : [exit]"
          log_index += 1
          log_data[log_index] = "=========================================================="
          log_index += 1
          if @@opts[:text] then
            puts ""
            for i in i..(log_index - 1)
              puts "#{log_data[i]}"
            end
          end
          interaction = STDIN.gets.chomp.strip
          log_data[log_index] = ""
          log_index += 1
          i = log_index

          if (/^[1-2]$/ =~ interaction) then
            @@opts[:interaction] = interaction.to_i
            loop_flag = false
          elsif interaction == "exit" then
            exit_system(@@opts[:text])
          else
            log_data[log_index] = "Your select is wrong!!"
            log_index += 1
          end
        end
      end

      loop_flag = true
      if !(@@flags[:mode]) then ### Write mode
        if (@@opts[:interaction] == 1) then ### Selected-pairs mode
          @@opts[:mode] = 6  ### E(total: PIE) [kcal/mol]
        elsif (@@opts[:interaction] == 2) then ### All-pairs mode
          while loop_flag do
            log_data[log_index] = "Please select write mode (at All-pairs mode)!"
            log_index += 1
            log_data[log_index] = "======================================================="
            log_index += 1
            log_data[log_index] = "E(es: Electrostatic)              [kcal/mol] : [1]"
            log_index += 1
            log_data[log_index] = "E(ex: Exchange repulsion)         [kcal/mol] : [2]"
            log_index += 1
            log_data[log_index] = "E(ct+mix: charge transfer + MIX)  [kcal/mol] : [3]"
            log_index += 1
            log_data[log_index] = "E(disp: Dispersion)               [kcal/mol] : [4]"
            log_index += 1
            log_data[log_index] = "G(sol: Solvation free energy)     [kcal/mol] : [5]"
            log_index += 1
            log_data[log_index] = "E(total: PIE)                     [kcal/mol] : [6]"
            log_index += 1
            log_data[log_index] = ""
            log_index += 1
            log_data[log_index] = "E_{ij} - E_{i} - E_{j}            [kcal/mol] : [7]"
            log_index += 1
            log_data[log_index] = "Tr(dD^{ij}*V^{ij})                [kcal/mol] : [8]"
            log_index += 1
            log_data[log_index] = "Exit                                         : [exit]"
            log_index += 1
            log_data[log_index] = "======================================================="
            log_index += 1
            if @@opts[:text] then
              puts ""
              for i in i..(log_index - 1)
                puts "#{log_data[i]}"
              end
            end
            mode = STDIN.gets.chomp.strip
            log_data[log_index] = ""
            log_index += 1
            i = log_index
#            if (/^[1-46-8]$/ =~ mode) then
            if (/^[1-8]$/ =~ mode) then
              @@opts[:mode] = mode.to_i
              loop_flag = false
            elsif mode == "exit" then
              exit_system(@@opts[:text])
            else
              log_data[log_index] = "Your select is wrong!!"
              log_index += 1
            end
          end
        end
      end
    elsif @@opts[:fmo] == 3 then ### ABINIT-MP, ABINIT-MP Open
      loop_flag = true
      if !(@@flags[:interaction]) then ### Interaction type (Selected-pairs or All-pairs)
        while loop_flag do
          log_data[log_index] = "Please select the interaction type (Selected-pairs or All-pairs)"
          log_index += 1
          log_data[log_index] = "=========================================================="
          log_index += 1
          log_data[log_index] = "Selected-pairs mode in \"one-dimensional\" table    : [1]"
          log_index += 1
          log_data[log_index] = "All-pairs mode in \"two-dimensional\" table         : [2]"
          log_index += 1
          log_data[log_index] = "Exit                                              : [exit]"
          log_index += 1
          log_data[log_index] = "=========================================================="
          log_index += 1
          if @@opts[:text] then
            puts ""
            for i in i..(log_index - 1)
              puts "#{log_data[i]}"
            end
          end
          interaction = STDIN.gets.chomp.strip
          log_data[log_index] = ""
          log_index += 1
          i = log_index

          if (/^[1-2]$/ =~ interaction) then
            @@opts[:interaction] = interaction.to_i
            loop_flag = false
          elsif interaction == "exit" then
            exit_system(@@opts[:text])
          else
            log_data[log_index] = "Your select is wrong!!"
            log_index += 1
          end
        end
      end

      loop_flag = true
      if !(@@flags[:abinitmp]) then ### Select the type of energy data of ABINIT-MP (IFIE or PIEDA)
        while loop_flag do
          log_data[log_index] = "Please select the type of energy data of ABINIT-MP (IFIE or PIEDA)"
          log_index += 1
          log_data[log_index] = "======================="
          log_index += 1
          log_data[log_index] = "IFIE energy    : [1]"
          log_index += 1
          log_data[log_index] = "PIEDA energy   : [2]"
          log_index += 1
          log_data[log_index] = "Exit           : [exit]"
          log_index += 1
          log_data[log_index] = "======================="
          log_index += 1
          if @@opts[:text] then
            puts ""
            for i in i..(log_index - 1)
              puts "#{log_data[i]}"
            end
          end
          abinitmp = STDIN.gets.chomp.strip
          log_data[log_index] = ""
          log_index += 1
          i = log_index
            
          if (/^[1-2]$/ =~ abinitmp) then
            @@opts[:abinitmp] = abinitmp.to_i
            loop_flag = false
          elsif abinitmp == "exit" then
            exit_system(@@opts[:text])
          else
            log_data[log_index] = "Your select is wrong!!"
            log_index += 1
          end
        end
      end

      loop_flag = true
      if !(@@flags[:mode]) then ### Write mode
        if (@@opts[:abinitmp] == 1) then ### Energy type is IFIE 
          if (@@opts[:interaction] == 1) then ### Selected-pairs mode
            while loop_flag do
              log_data[log_index] = "Please select write mode (at Selected-pairs mode)!"
              log_index += 1
              log_data[log_index] = "========================================"
              log_index += 1
              log_data[log_index] = "HF   (a.u.) and HF   [kcal/mol] : [1]"
              log_index += 1
              log_data[log_index] = "dMP2 (a.u.) and dMP2 [kcal/mol] : [2]"
              log_index += 1
              log_data[log_index] = "MP2  (a.u.) and MP2  [kcal/mol] : [3]"
              log_index += 1
              log_data[log_index] = "Exit                            : [exit]"
              log_index += 1
              log_data[log_index] = "========================================"
              log_index += 1
              if @@opts[:text] then
                puts ""
                for i in i..(log_index - 1)
                  puts "#{log_data[i]}"
                end
              end
              mode = STDIN.gets.chomp.strip
              log_data[log_index] = ""
              log_index += 1
              i = log_index
              if (/^[1-3]$/ =~ mode) then
                @@opts[:mode] =mode.to_i
                loop_flag = false
              elsif mode == "exit" then
                exit_system(@@opts[:text])
              else
                log_data[log_index] = "Your select is wrong!!"
                log_index += 1
              end
            end
          elsif (@@opts[:interaction] == 2) then ### All-pairs mode
            while loop_flag do
              log_data[log_index] = "Please select write mode (at All-pairs mode)!"
              log_index += 1
              log_data[log_index] = "========================"
              log_index += 1
              log_data[log_index] = "HF   (a.u.)     : [1]"
              log_index += 1
              log_data[log_index] = "HF   [kcal/mol] : [2]"
              log_index += 1
              log_data[log_index] = "dMP2 (a.u.)     : [3]"
              log_index += 1
              log_data[log_index] = "dMP2 [kcal/mol] : [4]"
              log_index += 1
              log_data[log_index] = "MP2  (a.u.)     : [5]"
              log_index += 1
              log_data[log_index] = "MP2  [kcal/mol] : [6]"
              log_index += 1
              log_data[log_index] = "Exit            : [exit]"
              log_index += 1
              log_data[log_index] = "========================"
              log_index += 1
              if @@opts[:text] then
                puts ""
                for i in i..(log_index - 1)
                  puts "#{log_data[i]}"
                end
              end
              mode = STDIN.gets.chomp.strip
              log_data[log_index] = ""
              log_index += 1
              i = log_index
              if (/^[1-6]$/ =~ mode) then
                @@opts[:mode] =mode.to_i
                loop_flag = false
              elsif mode == "exit" then
                exit_system(@@opts[:text])
              else
                log_data[log_index] = "Your select is wrong!!"
                log_index += 1
              end
            end
          end
        elsif (@@opts[:abinitmp] == 2) then ### Energy type of PIEDA
          if (@@opts[:interaction] == 1) then ### Selected-pairs mode
            @@opts[:mode] = 5 ### E(total: PIE) [kcal/mol]
          elsif (@@opts[:interaction] == 2) then ### All-pairs mode
            while loop_flag do
              log_data[log_index] = "Please select write mode (at All-pairs mode)!"
              log_index += 1
              log_data[log_index] = "======================================================="
              log_index += 1
              log_data[log_index] = "E(es: Electrostatic)              [kcal/mol] : [1]"
              log_index += 1
              log_data[log_index] = "E(ex: Exchange repulsion)         [kcal/mol] : [2]"
              log_index += 1
              log_data[log_index] = "E(ct+mix: charge transfer + MIX)  [kcal/mol] : [3]"
              log_index += 1
              log_data[log_index] = "E(di: Dispersion)                 [kcal/mol] : [4]"
              log_index += 1
              log_data[log_index] = "E(total: PIE)                     [kcal/mol] : [5]"
              log_index += 1
#              log_data[log_index] = ""
#              log_index += 1
              log_data[log_index] = "Exit                                         : [exit]"
              log_index += 1
              log_data[log_index] = "======================================================="
              log_index += 1
              if @@opts[:text] then
                puts ""
                for i in i..(log_index - 1)
                  puts "#{log_data[i]}"
                end
              end
              mode = STDIN.gets.chomp.strip
              log_data[log_index] = ""
              log_index += 1
              i = log_index
              if (/^[1-6]$/ =~ mode) then
                @@opts[:mode] = mode.to_i
                loop_flag = false
              elsif mode == "exit" then
                exit_system(@@opts[:text])
              else
                log_data[log_index] = "Your select is wrong!!"
                log_index += 1
              end
            end
          end
        end
      end
    end

    loop_flag = true
    if !(@@flags[:add_chain]) ### Add chain identifier to input PDB file
      while loop_flag do
        log_data[log_index] = "Please select to ouput a new PDB file adding chain identifier: \"A\"."
        log_index += 1
        log_data[log_index] = "==============================================================="
        log_index += 1
        log_data[log_index] = "To continue normally (this process is nothing)         : [1]"
        log_index += 1
        log_data[log_index] = "Output a new PDB file adding chain identifier: \"A\"     : [2]"
        log_index += 1
        log_data[log_index] = " * Warning is issued when there is chain identifier"
        log_index += 1
        log_data[log_index] = "   in the original PDB file."
        log_index += 1
        log_data[log_index] = "Exit                                                   : [exit]"
        log_index += 1
        log_data[log_index] = "==============================================================="
        log_index += 1
        if @@opts[:text] then
          puts ""
          for i in i..(log_index - 1)
            puts "#{log_data[i]}"
          end
        end
        add_chain = STDIN.gets.chomp.strip
        log_data[log_index] = ""
        log_index += 1
        i = log_index
        if (/^[1-2]$/ =~ add_chain) then
          @@opts[:add_chain] = add_chain.to_i
          loop_flag = false
        elsif add_chain == "exit" then
          exit_system(@@opts[:text])
        else
          log_data[log_index] = "Your select is wrong!!"
          log_index += 1
        end
      end
    end

    if !(@@flags[:out]) then ### Get the Calculated OUT file name (*.out)
      if (@@opts[:fmo] == 1) then
        file_ext = "\"Calculated Out by PAICS\""
      elsif (@@opts[:fmo] == 2) then
        file_ext = "\"Calculated Out by GAMESS-FMO\""
      elsif (@@opts[:fmo] == 3) then
        file_ext = "\"Calculated Out by ABINIT-MP\""
      end
      f = File_Get.new()
      @@opts[:out], log_data, log_index = f.input_file(file_ext, log_data, log_index, @@opts[:text])
    end

    if !(@@flags[:pdb]) then ### Get the PDB file name (*.pdb)
      @@opts[:pdb], log_data, log_index = f.input_file("PDB", log_data, log_index, @@opts[:text]) 
    end

    if !(@@flags[:output]) then ### Get the output file name (*.txt: Text format)
      @@opts[:output], log_data, log_index = f.input_file("Output (Text format)", log_data, log_index, @@opts[:text])
    end 

    if (@@opts[:fmo] == 1) or (@@opts[:fmo] == 2) or (@@opts[:fmo] == 3) then
      all_flag = true
      i = log_index
      if (@@opts[:interaction] == 2) then ### All-pairs mode
        if !(@@flags[:fragment]) then
          loop_flag = true
          while loop_flag do
            log_data[log_index] = "Please specify the range of the i-fragment number to extract data!"
            log_index += 1
            log_data[log_index] = "==========================================================================="
            log_index += 1
            log_data[log_index] = "Input the fragment number to extract data with the first value (ifragment)"
            log_index += 1
            if @@opts[:text] then
              puts ""
              for i in i..(log_index - 1)
                puts "#{log_data[i]}"
              end
            end
            ifragment = STDIN.gets.chomp.strip
            log_data[log_index] = ""
            log_index += 1
            i = log_index
            if (ifragment == "0") then
              log_data[log_index] = "Your input value is Zero!!"
              log_index += 1
            elsif (ifragment == "all") then
              @@opts[:fragment][0] = 1
              @@opts[:fragment][1] = 0
              all_flag = false
              loop_flag = false
            elsif (/^[0-9]+$/ =~ ifragment) then
              @@opts[:fragment][0] = ifragment.to_i
              loop_flag = false
            else
              log_data[log_index] = "Your input value is not numerical number!!"
              log_index += 1
            end
          end
             
          if (all_flag) then
            loop_flag = true
          end
          while loop_flag do
            log_data[log_index] = "Please specify the range of the j-fragment number to extract data!"
            log_index += 1
            log_data[log_index] = "==========================================================================="
            log_index += 1
            log_data[log_index] = "Input the fragment number to extract data with the end value (jfragment)"
            log_index += 1
            if @@opts[:text] then
              puts ""
              for i in i..(log_index - 1)
                puts "#{log_data[i]}"
              end
            end
            jfragment = STDIN.gets.chomp.strip
            log_data[log_index] = ""
            log_index += 1
            i = log_index
            if (jfragment == "0") then
              log_data[log_index] = "Your input value is Zero or String value!!"
              log_index += 1
            elsif (jfragment.to_i < @@opts[:fragment][0]) then
              log_data[log_index] = "Error: jfrag(\"#{jfragment}\") < ifrag(\"#{opts[:fragment][0]}\")!!"
              log_index += 1
            elsif (/^[0-9]+$/ =~ jfragment) then
              @@opts[:fragment][1] = jfragment.to_i
              log_data[log_index] = "\n==========================================================================="
              log_index += 1
              puts log_data[log_index - 1] if @@opts[:text]
              loop_flag = false
            else
              log_data[log_index] = "Your input value is not numerical number!!"
              log_index += 1
            end
          end
        end         
      end
    end

    [@@opts, @@flags, log_data]
  end
   
  #*** Check option for Gnuplot ***#
  def check_gp_opt_flag(cmd_exist, log)
    if (cmd_exist[:gnuplot]) then ### Install gnuplot in your system
      if (@@opts[:gnuplot]) then ### Without -g option
        if !(@@flags[:aaletter]) then
          loop_flag = true
          while loop_flag do
            log.info "\n", "Input the letter code type of amino acid name", "", @@opts[:text]
            log.info "", "===========================================", "", @@opts[:text]
            log.info "", "* Amino acid name is 1 latter code  : [1]"   , "", @@opts[:text]
            log.info "", "* Amino acid name is 3 latter code  : [2]"   , "", @@opts[:text]
            log.info "", "* Exit                             : [exit]", "", @@opts[:text]
            log.info "", "===========================================", "", @@opts[:text]
            aaletter = STDIN.gets.chomp.strip
            if (/^[1-2]$/ =~ aaletter) then
              @@opts[:aaletter] = aaletter.to_i
              loop_flag = false
            elsif  aaletter == "exit" then
              exit(1);
            else
              log.info "\n", "Input data is bad statement!!", "", @@opts[:text]
            end
          end
        end

        if !(@@flags[:distance]) then
          log.info "\n\n\n", "Process: Plot data by using Gnuplot", "", @@opts[:text]
          if (@@opts[:fmo] == 1) or (@@opts[:fmo] == 3) then ### PAICS or ABINIT-MP
            loop_flag = true
            while loop_flag do
              log.info "\n", "Please specify data range [Angstrom] between min (R1) and max (R2) distances", "", @@opts[:text]
              log.info "", "================================================================================", "", @@opts[:text]
              log.info "", " - Input (int or float) minimum distance (R1) [A], (R1 >= 0.0 [A])", "", @@opts[:text]
              @@opts[:distance][0] = STDIN.gets.chomp.to_f
              log.info "", "#{@@opts[:distance][0]}", "", false
              if (/^[+]?[0-9]+(\.?[0-9]*)$/ =~ @@opts[:distance][0].to_s) then
                loop_flag = false
              else
                log.info "\n", "Input data is not numerical number!!", "", @@opts[:text]
              end
            end
            loop_flag = true
            while loop_flag do
              log.info "", " - Input (int or float) maximum distance (R2) [A] and (R2 > #{@@opts[:distance][0]} (R1) [A])", "", @@opts[:text]
              @@opts[:distance][1] = STDIN.gets.chomp.to_f
              log.info "", "#{@@opts[:distance][1]}", "", false
              if (/^[+]?[0-9]+(\.?[0-9]*)$/ =~ @@opts[:distance][1].to_s) then
                if (@@opts[:distance][0] >= @@opts[:distance][1]) then
                  log.error "\n", "", "Two input numerical values must be \"(min (R1) < max (R2))\"!!", @@opts[:text]
                else
                  loop_flag = false
                end
              else
                log.info "\n", "Input data is not  numerical number!!", "", @@opts[:text]
              end
            end
            log.info "", "================================================================================", "\n", @@opts[:text]
          elsif (@@opts[:fmo] == 2) then ### GAMESS-FMO
            loop_flag = true
            while loop_flag do
              log.info "\n", "Please specify data range [%] between min (R1) and max (R2) distances", "", @@opts[:text]
              log.info "", "================================================================================", "", @@opts[:text]
              log.info "", " - Input (int or float) minimum distance (R1) [%], (R1 >= 0.0)", "", @@opts[:text]
              @@opts[:distance][0] = STDIN.gets.chomp.to_f
              log.info "", "#{@@opts[:distance][0]}", "", false
              if (/^[+]?[0-9]+(\.?[0-9]*)$/ =~ @@opts[:distance][0].to_s) then
                loop_flag = false
              else
                log.info "\n", "Input data is not numerical number!!", "", @@opts[:text]
              end
            end
            loop_flag = true
            while loop_flag do
              log.info "", " - Input (int or float) maximum distance (R2) [%], (R2 > #{@@opts[:distance][0]} (R1))", "", @@opts[:text]
              @@opts[:distance][1] = STDIN.gets.chomp.to_f
              log.info "", "#{@@opts[:distance][1]}", "", false
              if (/^[+]?[0-9]+(\.?[0-9]*)$/ =~ @@opts[:distance][1].to_s) then
                if (@@opts[:distance][0] >= @@opts[:distance][1]) then
                  log.error "\n", "", "Two input numerical values must be \"(min (R1) < max (R2))\"!!", @@opts[:text]
                else
                  loop_flag = false
                end
              else
                log.info "\n", "Input data is not  numerical number!!", "", @@opts[:text]
              end
            end
            log.info "", "================================================================================", "\n", @@opts[:text]
          end
        end
      end
    end
  end

end


#*******************************************************************#
#***    Class for file get (out, pdb, output) and check exist    ***#
#*******************************************************************#
class File_Get
  def input_file(file_ext, log_data, log_index, text_flag)
    log_data[log_index] = "Input #{file_ext} file name within the file extension with full path information"
    log_index += 1
    puts "\n#{log_data[log_index - 1]}" if (text_flag)
    file_name = STDIN.gets.chomp.strip.tr("'", "")
    puts "" if (text_flag)

    ### File exist?
    if (file_ext != "Output (Text format)") then
      file_name, log_data, log_index = file_exist(file_name, file_ext, log_data, log_index, text_flag)
    else
      if (file_name == "" or file_name == nil) then
        loop_flag = false
        while loop_flag do
          tmp_i = log_index
          log_data[log_index] = "Input the \"#{file_name}\" is inappropriate!!"
          log_index += 1
          log_data[log_index] = "Please input #{file_ext} file name again!"
          log_index += 1
          if text_flag then
            puts ""
            for i in tmp_i..(log_index - 1)
              puts "#{log_data[i]}"
            end
          end
          file_name = STDIN.gets.chomp.strip.tr("'", "")

          log_data[log_index] = file_name
          log_index += 1
          puts "" if text_flag
          loop_flag = true if !(file_name == "" or file_name == nil)
        end
      end
    end
    [file_name, log_data, log_index]
  end

  def file_exist(file_name, file_ext, log_data, log_index, text_flag)
    while !(File.exist?(file_name)) do
      tmp_i = log_index
      log_data[log_index] = "Input the \"#{file_name}\" is not exist!!"
      log_index += 1
      log_data[log_index] = "Please input #{file_ext} file name again!"
      log_index += 1
      if text_flag then
        puts ""
        for i in tmp_i..(log_index - 1)
          puts "#{log_data[i]}"
        end
      end
      file_name = STDIN.gets.chomp.strip.tr("'", "")

      log_data[log_index] = file_name
      log_index += 1
      puts "" if text_flag
    end
    [file_name, log_data, log_index]
  end
end


#****************************************************#
#***    Class for analysis of PDB file (*.pdb)    ***#
#****************************************************#
class Analysis
  def initialize(opts, flags, log, pdb_all_data, cys_pdb_data, cb_pdb_data, h_pdb_data, his_pdb_name, xml_flag)
    @@opts = opts
    @@flags = flags
    @@log = log
    @@pdb_all_data = pdb_all_data  ### all data from PDB file
    @@cys_pdb_data = cys_pdb_data  ### CYS data with 
    @@cb_pdb_data = cb_pdb_data    ### CB in ILE or LEU
    @@h_pdb_data = h_pdb_data      ### H in ILE or LEU
    @@his_pdb_name = his_pdb_name  ### HIS name using HE2 and HD1 in PDB file
    @@xml_flag = xml_flag
  end

  class PDB < Analysis
    #*** Acquire the residue data from PDB file ***#
    def acquire_pdb_residue()
      tmp_residue_name = "" ### Temporary residue name
      tmp_residue_num = ""  ### Temporary residue number
      tmp_cys_res_num = ""  ### Tmp of CYS residue number

#      function_name = "acquire_pdb_residue" 
      next_flag = 0  ### flag is 0 for first and 1 for next residue data
      his_flag = 0   ### 0 is start to count H in HIS, 1 is end to count H and check type of HIS
      cys_flag = 0   ### 0 is start to count atoms in HIS, 
                     ### 1 is end to count atoms and check number of atoms in HIS
      atom_count = 1 ### Count atoms
      his_count = 0  ### Flag fo counting HIS
      hie_count = 0  ### Flag fo counting "HE2" in HIS
      hid_count = 0  ### Flag fo counting "HD1" in HIS
      ws1 = 0        ### Count "" of chain identifier (ws = white space)
      ws2 = 0        ### Count " " of chain identifier
      nc = 0         ### Count nil of chain identifier (nc = nil count)
      cyx_ss = ""    ### If number of CYX-SS is odd number

      ### Array
      @@pdb_all_data = []  ### all data from PDB file
      @@cys_pdb_data = []  ### CYS data with 
      @@cb_pdb_data = []   ### CB in ILE or LEU
      @@h_pdb_data = []    ### H in ILE or LEU
      @@his_pdb_name = []  ### HIS name using HE2 and HD1 in PDB file

      ### defalut values
      cys = {
        num_atoms: 0,     ### Number of atoms in CYS
        residue_num: "",  ### Chain and Redidue number of CYS (ex. "A 111")
        sg_atom_num: 0,   ### Atom sequence number of "SG" atom for CYX-SS (S-S bond)
      }

      @@log.info "\n", "Process: Obtain the residue name and residue number from PDB file", "", @@opts[:text]
      begin 
        file_data = open(@@opts[:pdb], "r")
      rescue SystemCallError => e
        @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
      rescue IOError => e
        @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
      end

      file_data.each do |line|
        ### For avoiding the same reference in Hash
        pdb_all = {
          atom_num: 0,             ### Atom serial number except for other than atom (ex. "TER")
          atom_name: "",           ### Atom name in PDB[12..15]
          residue_name: "",        ### Residue name in PDB[17..19]
          chain: "",               ### Chain identifier in PDB[21]
          residue_num: 0,          ### Residue sequence number in PDB[22.25] 
          x: 0.0,                  ### Orthogonal coordinates for X in PDB[30..37]
          y: 0.0,                  ### Orthogonal coordinates for Y in PDB[38..45]
          z: 0.0,                  ### Orthogonal coordinates for Z in PDB[46..53]
          occupancy: 0.0,          ### Occupancy in PDB[54..59]
          temperature_factor: 0.0, ### Temperature factor in PDB[60..65]
          element_symbol: "",      ### Element symbol in PDB[76..77]
          charge: 0,               ### Charge on the atom in PDB[78..79]
        }
        cb_atom = { ### CB atom in ILE or LEU
          residue_num: "",  ### Chain and residue sequence number of CB in ILE or LEU (ex. "A 111")
          atom_num: 0,      ### Atom serial number except for other than atom (ex. "TER")
        }
        h_atom = { ### "*H*" (H atom) in ILE or LEU
          residue_num: "",  ### Chain and residue sequence number of "*H*" atoms in ILE or LEU (ex. "A 111")
          atom_num: 0,      ### Atom serial number except for other than atom (ex. "TER")
        }

        if line.size > 5 then
          record_name = line[0..5].strip
          if record_name == "ATOM" or record_name == "HETATM" then
            atom_name = line[12..15].strip
            residue_name = line[17..19].strip
            residue_num = line[22..25].strip

            ### All data from PDB file
            pdb_all[:atom_num] = atom_count
            pdb_all[:atom_name] = line[12..15].strip
            pdb_all[:residue_name] = line[17..19].strip
            pdb_all[:chain] = line[21].strip
            pdb_all[:residue_num] = line[22..25].strip.to_i
            pdb_all[:x] = ("%.3f"%line[30..37].strip).to_f
            pdb_all[:y] = ("%.3f"%line[38..45].strip).to_f
            pdb_all[:z] = ("%.3f"%line[46..53].strip).to_f
            if line.size > 80 then
              pdb_all[:occupancy] = ("%.3f"%line[54..59].strip).to_f
              pdb_all[:temperature_factor] = ("%.3f"%line[60..65].strip).to_f
              pdb_all[:element_symbol] = line[76..77].strip
              pdb_all[:charge] = line[78..79].strip
            end
            @@pdb_all_data << pdb_all

            if next_flag == 0 then ### First residue
              if residue_name == "HIS" or residue_name == "HIE" or residue_name == "HID" or residue_name == "HIP" then
                his_flag = 1  ### 1 is end to count H and check type of HIS
                if atom_name == "HE2" then
                  hie_count = 1
                elsif atom_name == "HD1" then
                  hid_count = 1
                end
              elsif residue_name == "CYS" or residue_name == "CYX" then
                if cys_flag == 0 then
                  ### Reset
                  cys = {
                    num_atoms: 0,
                    residue_num: "",
                    sg_atom_num: 0,
                   }
                  cys[:num_atoms] = 0
                  tmp_cys_res_num = line[22..25].strip ### First time, tmp of CYS residue number
                  cys_flag = 1
                end
                
                if !(tmp_cys_res_num == line[22..25].strip) then ### Next residue of CYS is CYS in PDB
                  @@cys_pdb_data << cys
                  ### Reset
                  cys = {
                    num_atoms: 0,
                    residue_num: "",
                    sg_atom_num: 0,
                   }
                  cys[:num_atoms] = 0
                end
                cys[:num_atoms] += 1  ### Count atoms in CYS
                cys[:residue_num] = "#{line[21]} #{line[22..25].strip}"
  
                if atom_name == "SG" then  ### Wtih S-S bond
                  cys[:sg_atom_num] = atom_count
                end
      
                tmp_cys_res_num = line[22..25].strip ### Temporary of CYS residue number
              elsif residue_name == "ILE" or residue_name == "LEU" then
                if atom_name == "CB" then  ### Including CB in ILE or LEU?
                  cb_atom[:atom_num] = atom_count
                  cb_atom[:residue_num] = "#{line[21]} #{line[22..25].strip}"
                  @@cb_pdb_data << cb_atom
                elsif atom_name =~ /[H]/ then  ### Including "*H*" (H atom) in ILE or LEU?
                  h_atom[:atom_num] = atom_count
                  h_atom[:residue_num] = "#{line[21]} #{line[22..25].strip}"
                  @@h_pdb_data << h_atom
                end
              end  
              atom_count += 1 ### Count atoms

              ### First time, tmp of residue name and number
              tmp_residue_name = residue_name
              tmp_residue_num = residue_num
              next_flag = 1  ### 1 is flag for next residue data
            else ### next residue
              if (residue_name != tmp_residue_name) or (residue_num != tmp_residue_num) then
                if cys_flag == 1 then
                  @@cys_pdb_data << cys
                  cys_flag = 0   ### 0 is start to count atoms in HIS
                end
                if his_flag == 1 then ### Check type of HIS
                  if hie_count == 1 and hid_count == 0 then
                    @@his_pdb_name[his_count] = "HIE"
                  elsif hie_count == 0 and hid_count == 1 then
                    @@his_pdb_name[his_count] = "HID"
                  elsif hie_count == 1 and hid_count == 1 then
                    @@his_pdb_name[his_count] = "HIP"
                  else
                    @@his_pdb_name[his_count] = "HIS(XXX)"
                    @@log.warn "\n", "Warning : Atom name inculding \"HIS (#{residue_num.to_i - 1})\" is weird in PDB file", "", @@opts[:text]
                  end
                  his_count += 1
             
                  ### Reset
                  his_flag = 0
                  hie_count = 0
                  hid_count =0
                end

                ### Next, tmp of residue name and number
                tmp_residue_name = residue_name
                tmp_residue_num = residue_num
              end

              if residue_name == "HIS" or residue_name == "HIE" or residue_name == "HID" or residue_name == "HIP" then
                his_flag = 1  ### 1 is end to count H and check type of HIS
                if atom_name == "HE2" then
                  hie_count = 1
                elsif atom_name == "HD1" then
                  hid_count = 1
                end
              elsif residue_name == "CYS" or residue_name == "CYX" then
                if cys_flag == 0 then
                  ### Reset
                  cys = {
                    num_atoms: 0,
                    residue_num: "",
                    sg_atom_num: 0,
                   }
                  cys[:num_atoms] = 0
                  tmp_cys_res_num = line[22..25].strip ### First time, tmp of CYS residue number
                  cys_flag = 1
                end
              
                if !(tmp_cys_res_num == line[22..25].strip) then ### Next residue of CYS is CYS in PDB
                  @@cys_pdb_data << cys
                  ### Reset
                  cys = {
                    num_atoms: 0,
                    residue_num: "",
                    sg_atom_num: 0,
                   }
                  cys[:num_atoms] = 0
                end
                cys[:num_atoms] += 1  ### Count atoms in CYS
                cys[:residue_num] = "#{line[21]} #{line[22..25].strip}" ### Next residue of CYS is CYS in PDB
    
                if atom_name == "SG" then  ### Wtih S-S bond
                  cys[:sg_atom_num] = atom_count
                end
                tmp_cys_res_num = line[22..25].strip ### Temporary of CYS residue number
              elsif residue_name == "ILE" or residue_name == "LEU" then
                if atom_name == "CB" then  ### Including CB in ILE or LEU?
                  cb_atom[:atom_num] = atom_count
                  cb_atom[:residue_num] = "#{line[21]} #{line[22..25].strip}"
                  @@cb_pdb_data << cb_atom
                elsif atom_name =~ /[H]/ then  ### Including "*H*" (H atom) in ILE or LEU?
                  h_atom[:atom_num] = atom_count
                  h_atom[:residue_num] = "#{line[21]} #{line[22..25].strip}"
                  @@h_pdb_data << h_atom
                end
              end  
              atom_count += 1 ### Count atoms
            end
          end
        end
      end
      file_data.close  ### File close
   
      if ws1 > 0 then
        @@log.warn "\nWarning: ", "Chain identifier includes \"\" in PDB file.", "", @@opts[:text]
      elsif ws2 > 0 then
        @@log.warn "\nWarning: ", "Chain identifier includes \" \" in PDB file.", "", @@opts[:text]
      elsif nc > 0 then
        @@log.error "\nError: ", "Chain identifier includes \"nil\" in PDB file!!", "", @@opts[:text]
      end

      check_cys ### Check number of atoms including CYS
    
      if @@opts[:add_chain] == 2 then ### Add chain identifier "A"
        add_chain(ws1, ws2, nc)
      end
    end

    #*** Check existance of chain identifier in PDB file ***#
    def check_whitespace(ws1, ws2, nc, chain_identifier)
      if chain_identifier == "" then
        ws1 += 1
      elsif chain_identifier == " " then 
        ws2 += 1
      elsif chain_identifier == nil then
        nc += 1
      end
      [ws1, ws2, nc]
    end

    #*** Check number of atoms in CYS ***#
    def check_cys
      cyx_ss = ""
      for i in 0..(@@cys_pdb_data.size - 1)
        ### Abnormal CYS (Number of atoms in CYS is wrong)
        ### 11: Isolated CYS (no S-S bond), 10: CYX-SS
        if !(@@cys_pdb_data[i][:num_atoms] == 10) and !(@@cys_pdb_data[i][:num_atoms] == 11) then
          @@log.info "", "*****************************************************", "", @@opts[:text]
          @@log.info "Error: ", " A number of atoms in CYS is wrong!!", "", @@opts[:text]
          @@log.info "Error: ", " Please check the Abnormal CYS!!", "", @@opts[:text]
          @@log.info "", "         - Residue number of wrong CYS : #{@@cys_pdb_data[i][:residue_num]}", "", @@opts[:text]
          @@log.info "", "         - Number of atoms in CYS      : #{@@cys_pdb_data[i][:num_atoms]} atoms", "", @@opts[:text]
          @@log.info "", "*****************************************************", "", @@opts[:text]
        end
      end

      ### Number of CYX-SS is not "even" number
      ### Number of atoms in CYX-SS is "10"
      if @@cys_pdb_data.select{|i| i[:num_atoms] == 10}.count.modulo(2) == 1 then
        for i in 0..(@@cys_pdb_data.size - 1)
          if @@cys_pdb_data[i][:num_atoms] == 10 then
            cyx_ss += "\"#{@@cys_pdb_data[i][:residue_num]}\" "
          end
        end
        @@log.info "", "**********************************************************************", "", @@opts[:text]
        @@log.info "Error: ", " A number of CYX-SS is not \"even\" number!!", "", @@opts[:text]
        @@log.info "Error: ", " Please check the number of CYX-SS (Number of CYS with S-S bond)!", "", @@opts[:text]
        @@log.info "", "         - Number of CYX-SS : #{@@cys_pdb_data.select{|i| i[:num_atoms] == 10}.count}", "", @@opts[:text]
        @@log.info "", "         - Residue numbers of CYX-SS: ", "", @@opts[:text]
        @@log.info "", "             #{cyx_ss}", "", @@opts[:text]
        @@log.info "", "**********************************************************************", "", @@opts[:text]
      end
    end

    #*** Add chain identifier "A" ***#
    def add_chain(ws1, ws2, nc)
      chain_count = ws1 + ws2 + nc
      if (chain_count >= 0) and (chain_count != @@pdb_all_data.size) then
        @@log.warn "Warning: ", "Chain identifier exists in PDB file, but this script creates new PDB file replacing raw chain identifier to \"A\"!", "\n", @@opts[:text]
      end
      add_chain_pdb  ### create new PDB file adding chain identifier "A"
      @@pdb_all_data.select{|pdb| pdb[:chain_identifier] = "A"} ### Replace all chain identifier to "A"
    end

    #*** Create new PDB file adding chain identifier "A" ***#
    def add_chain_pdb
      new_pdb_file_name = @@opts[:pdb].gsub(File.extname(@@opts[:pdb]), "_addchain.pdb")
     
      data_file = open(@@opts[:pdb], "r")
      new_pdb_file = open(new_pdb_file_name, "w")
  
      data_file.each do |line|
        record_name = line[0..5].strip
        if record_name == "ATOM" or record_name == "HETATM" then
          line[21] = "A" ### insert chain "A"
        end
        new_pdb_file.write(line)
      end
      data_file.close ### Old file close
      new_pdb_file.close ### New file close
      @@opts[:pdb] = new_pdb_file
    end

    #*** Calculate the number of electrons in Ligand or HEATAM***#
    def cal_num_electron(element) ### element = pdb_line[76..79].strip
      num_electron = 0
      charge = 0
  
      ### charge
      if element =~ /[+]/ then
        if element =~ /[1]/ then
          charge = -1
        elsif element =~ /[2]/ then
          charge = -2
        elsif element =~ /[3]/ then
          charge = -3
        end
      elsif element =~ /[-]/ then
        if element =~ /[1]/ then
          charge = 1
        elsif element =~ /[2]/ then
          charge = 2
        elsif element =~ /[3]/ then
          charge = 3
        end
      else
        charge = 0
      end
  
      ### electron
      if element =~ /[C]/ then
        number_electron = 6
      elsif element =~ /[N]/ then
        number_electron = 7
      elsif element =~ /[O]/ then
        number_electron = 8
      elsif element =~ /[H]/ then
        number_electron = 1
      elsif element =~ /[S]/ then
        number_electron = 16
      elsif element =~ /[P]/ then
        number_electron = 15
      else
        number_electron = 0
      end
  
      return (number_electron + charge)
    end

    def run
      acquire_pdb_residue
      if (@@xml_flag) then
        if @@opts[:xml] then
          @@log.info "", "Process: Output XML from PDB data", "", @@opts[:text]
          XML.new(@@opts, @@log).xml_pdb(@@pdb_all_data)
        end
      end 
    end

    def test_run
      puts "PDB: #{@@pdb_all_data.to_s}"
      puts "CYS: #{@@cys_pdb_data.to_s}"
      puts "CB: #{@@cb_pdb_data.to_s}"
      puts "H: #{@@h_pdb_data.to_s}"
      puts "HIS: #{@@his_pdb_name.to_s}"
    end
  end
end

#******************************************************************#
#***    Class for analysis of Out file (*.out or *.log, ...)    ***#
#******************************************************************#
class PAICS < Analysis
  def initialize(frag_data = {}, cp_corr = "", out_data = [], amino_acid_letter = [], out_ss = [], final_pdb_res = [], 
                 energy_data = [], cmp2_data = [], mulliken_charge = [], sum_mulliken = [], ave_data = [], binding_affinity = 0.0, 
                 dat_file = "", energy_cal = ["", "", "", ""])
    super(@@opts, @@flags, @@log, @@pdb_all_data, @@cys_pdb_data, @@cb_pdb_data, @@h_pdb_data, @@his_pdb_name, @@xml_flag)
    @frag_data = frag_data
    @cp_corr = cp_corr
    @out_data = out_data
    @amino_acid_letter = amino_acid_letter
    @out_ss = out_ss                       ### SS ifrag, final SS residue name
    @final_pdb_res = final_pdb_res
    @energy_data = energy_data
    @cmp2_data = cmp2_data
    @mulliken_charge = mulliken_charge     ### Using for All-pairs mode only
    @sum_mulliken = sum_mulliken
    @ave_data = ave_data
    @binding_affinity = binding_affinity   ### Binding Affinity = Sum of MP2 [kcal/mol]
    @dat_file = dat_file
    ### [rhf, canonical mp2 = mp2, canonical mp2 ( resolution of the identity ) = ri-mp2, local mp2]
    @energy_cal = energy_cal
  end

  #*** Get the Fragment number of ligand and Number of fragments (max) ***# 
  def get_fragment_num
    line_count = 0
    cp_corr = false
    ligand_label = "          * Total properties cannot be calculated because not all fragment "
#    function_name = "get_fragment_num"

    @frag_data = {
      max: 0,       ### Number of fragments (Max)
      particle: 1,  ### Number of particle fragments (ligands)
      frag_num: [], ### Particle fragment numbers (ligands)
    }

    if @@opts[:interaction] == 1 then
      Write_data.new.write_txt_data("<File Name Path>\n", @@opts, 0, @@log)
      Write_data.new.write_txt_data(@@opts[:out], @@opts, 1, @@log)
      Write_data.new.write_txt_data("\n\n", @@opts, 1, @@log)
      Write_data.new.write_csv_data("\n\n,File Name Path,", @@opts, 0, @@log)
      Write_data.new.write_csv_data(@@opts[:out], @@opts, 1, @@log)
      Write_data.new.write_csv_data("\n\n", @@opts, 1, @@log)
    end

    @@log.info "\n", "Process: Get the number of fragment from PAICS out file", "", @@opts[:text]

    begin 
      data_file = open(@@opts[:out], "r")
    rescue SystemCallError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
    rescue IOError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
    end

    lines = data_file.readlines ### Read lines from opened file
    while (line_count < lines.size) do 
      line_data = lines[line_count].split(/\s* \s*/)
         
      ### Check the option of "BSSE correction with the counter-poise method"
      ### by PAICS using cp_corr (yes or no?)
      ### <Ref.>: Chapter 2. INPUT, P. 13 in PAICS manual (URL: http://www.paics.net/pdf/manual.pdf)
      if (line_data[1] == "cp" and line_data[2] == "corr" and line_data[3] == "=") then
        @@log.info "\n", "  * BSSE correction with the counter-poise method by PAICS using cp_corr:", "", @@opts[:text]
        @@log.info "", "    cp corr == #{line_data[4].tr("\r\n|\r|\n", "")}", "\n", @@opts[:text]
        if line_data[4].tr("\r\n|\r|\n", "") == "yes" then ### cp_corr == "yes"
          @cp_corr = true
        else ### cp_corr == "no"
          @cp_corr = false
        end
      end
 
      if (line_data[1] == "<" and line_data[2] == "rhf" and line_data[3].tr("\r\n|\r|\n", "") == ">") then ### < rhf >
        line_count = line_count + 2
        @energy_cal[1] = lines[line_count].split(/\s* \s*/)[3].tr("\r\n|\r|\n", "")
      elsif (line_data[1] == "<" and line_data[2] == "canonical" and line_data[3] = "mp2" and line_data[4].tr("\r\n|\r|\n", "") == ">") then ### < canonical mp2 >
        line_count = line_count + 2
        @energy_cal[2] = lines[line_count].split(/\s* \s*/)[4].tr("\r\n|\r|\n", "")
       elsif (line_data[1] == "<" and line_data[2] == "canonical" and line_data[3] = "mp2" and line_data[4] == "(") then ### < canonical mp2 ( resolution of the identity ) >
        line_count = line_count + 2
        @energy_cal[3] = lines[line_count].split(/\s* \s*/)[3].tr("\r\n|\r|\n", "")
       elsif (line_data[1] == "<" and line_data[2] == "local" and line_data[3] = "mp2" and line_data[4].tr("\r\n|\r|\n", "") == ">") then ### < local mp2 >
        line_count = line_count + 2
        @energy_cal[4] = lines[line_count].split(/\s* \s*/)[4].tr("\r\n|\r|\n", "")
      end

      if line_data[1] == "number" and line_data[3] == "fragment" then
        fragment_num =  "%s %s %s = %d\n\n"%[line_data[1], line_data[2], line_data[3], line_data[5]]
        fragment_num_csv = ",%s %s %s,%d\n\n"%[line_data[1], line_data[2], line_data[3], line_data[5]]
        @@log.info "", "  #{fragment_num.tr("\r\n|\r|\n", "")}", "", @@opts[:text]

        @frag_data[:max] = line_data[5].tr("\r\n|\r|\n", "").to_i ### Number of fragments (max)
        @frag_data[:frag_num][0] = @frag_data[:max]
        @@opts[:fragment][1] = @frag_data[:max] if (@@opts[:fragment][1] == 0) ### Using -j all

        if @@opts[:interaction] == 1 then
          Write_data.new.write_txt_data("<Number of fragment>\n", @@opts, 1, @@log)
          Write_data.new.write_txt_data(fragment_num, @@opts, 1, @@log)
          Write_data.new.write_csv_data(fragment_num_csv, @@opts, 1, @@log)
        end
      end
      if lines[line_count].tr("\r\n|\r|\n", "") == ligand_label then
        line_data = lines[line_count + 3].split(/\s* \s*/)
        @frag_data[:particle] = line_data.size - 1  ### Number of particle fragments (ligands)
        @@log.info "", "  Number of particle fragments (ligands):  #{@frag_data[:particle]}", "", @@opts[:text]
        if @@opts[:interaction] == 1 then
          Write_data.new.write_txt_data("\n<Target fragments>\n", @@opts, 1, @@log)
          Write_data.new.write_csv_data(",Target fragments,", @@opts, 1, @@log)
        end

        ligand_label = "  Ligand number:  "
        for i in 1..@frag_data[:particle]
          if i == @frag_data[:particle] then ### Last fragment including "new line"
            @frag_data[:frag_num][i - 1] = line_data[i].tr("\r\n|\r|\n", "").to_i ### Particle fragment (ligand) numbers
            ligand_label += "#{@frag_data[:frag_num][i - 1]}\n\n"
            if @@opts[:interaction] == 1 then
              Write_data.new.write_txt_data(@frag_data[:frag_num][i - 1].to_s + "\n", @@opts, 1, @@log)
              Write_data.new.write_csv_data(@frag_data[:frag_num][i - 1].to_s + "\n\n", @@opts, 1, @@log)
            end
          else
            @frag_data[:frag_num][i - 1] = line_data[i].to_i ### Particle fragment (ligand) numbers
            ligand_label += "#{@frag_data[:frag_num][i - 1]}, "
            if @@opts[:interaction] == 1 then
              Write_data.new.write_txt_data(@frag_data[:frag_num][i - 1].to_s + ", ", @@opts, 1, @@log)
              Write_data.new.write_csv_data(@frag_data[:frag_num][i - 1].to_s + ",", @@opts, 1, @@log)
            end
          end
        end
        @@log.info "", "#{ligand_label.tr("\r\n|\r|\n", "")}", "\n\n", @@opts[:text]
    
#        data_file.close  ### File close
        break
      end
      line_count += 1
    end
    data_file.close  ### File close
#    @cp_corr = false ### Not using enegy with cp corr
  end

  #*** Get the Coordinates ***#
  def get_out_xyz
    count_flag = false ### false is first coordination data, true is since second coordination data
    line_count = 0     ### Count lines of file
#    function_name = "get_out_xyz"

    ### Start line of calculated coordination data
    start_coordinate_line = "       < input coordinate of nucleus charge >"
    ### End line of calculated coordination data
    end_coordinate_line = "        ---------------------------------------------------------------------------------------------------------------------"

    @@log.info "", "Process: Obtain the coordinates of atoms from PAICS out file", "", @@opts[:text]
    begin 
      data_file = open(@@opts[:out], "r")
    rescue SystemCallError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
    rescue IOError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
    end

    lines = data_file.readlines ### Read lines from opened file
    while line_count < lines.size do 
      out = {
        atom_num: 0,   ### Atom number
        atom_name: "", ### Atom name 
        x: 0.0,        ### X coordinates [A]
        y: 0.0,        ### Y coordinates [A]
        z: 0.0,        ### Z coordinates [A]
       }
      if !(count_flag) then  ### First coordination data
        if (lines[line_count].tr("\r\n|\r|\n", "") == start_coordinate_line) then
          count_flag = true
          line_count += 5  ### Skip 5 lines
          data = lines[line_count].split(/\s* \s*/)
          out[:atom_num] = data[1].to_i
          out[:atom_name] = data[3]
          out[:x] = ("%.6f"%data[6]).to_f
          out[:y] = ("%.6f"%data[7]).to_f
          out[:z] = ("%.6f"%data[8]).to_f
          @out_data << out
        end
      else  ### Since second coordination data
        if !(lines[line_count].tr("\r\n|\r|\n", "") == end_coordinate_line) then
          data = lines[line_count].split(/\s* \s*/)
          out[:atom_num] = data[1].to_i
          out[:atom_name] = data[3]
          out[:x] = ("%.6f"%data[6]).to_f
          out[:y] = ("%.6f"%data[7]).to_f
          out[:z] = ("%.6f"%data[8]).to_f
          @out_data << out
        else ### End of getting data
          break
        end
      end
      line_count += 1
    end
    data_file.close ### file close
  end
    
  #*** Get amino acid data (PAICS) by using fragment ***#
  def get_amino_acid_data
    fragment_line = "       < input fragment >"  ### Number of fragment line
    count_flag = false  ### false is first amino acid name, true is since second amino acid name
    line_count = 0      ### Count lines of file
    aa_count = 0        ### Count number of amino acids
    ile_leu_count = 0   ### Count ILE and LEU
    atom_step = 10      ### atom numbers including fragment are written in PAICS Out file by 10
#    function_name = "get_amino_acid_data"

    @@log.info "", "Process: Define amino acid by using fragment number at PAICS out file", "", @@opts[:text]
    begin 
      data_file = open(@@opts[:out], "r")
    rescue SystemCallError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
    rescue IOError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
    end
    line_data = data_file.readlines### Read line from opened file

    while line_count < line_data.size do  ### If not EOF (End Of File)
      if !(count_flag) then ### First time
        if line_data[line_count].tr("\r\n|\r|\n", "") == fragment_line then
          count_flag = true ### Next amino acid
          line_count += 4   ### Skip 4 lines from "< input fragment >"
          (@amino_acid_letter[aa_count], ile_leu_count) = define_paics_amino_acid(line_data[line_count], ile_leu_count)

          ### Get the atom numbers including fragment
          atom_num = []
          atom_lines = @amino_acid_letter[aa_count][:sum_atoms].div(atom_step)
          if @amino_acid_letter[aa_count][:sum_atoms]%atom_step > 0 then
            atom_lines += 1
          end
          line_count += 1 ### Skip 1 line of "atom (add) ="
          line_position = line_count
          while (line_count < line_position + atom_lines) do
            line_count += 1
            if line_position + 1 == line_count then ### Line on "atom (in) =",
              data = line_data[line_count].split(/\s* \s*/)
              for i in 4..(data.size - 1)
                atom_num[i - 4] = data[i].tr("\r\n|\r|\n", "").to_i
              end
            else
              data = line_data[line_count].split(/\s* \s*/)
              tmp_i = i - 4
              for i in 1..(data.size - 1)
                atom_num[tmp_i + i] = data[i].tr("\r\n|\r|\n", "").to_i
              end
            end
          end
          @amino_acid_letter[aa_count][:atom_num] = atom_num
#          @amino_acid_letter[aa_count][:atom_num] = atom_num.sort
          aa_count += 1
        end
      else ### Next
        data = line_data[line_count].split(/\s* \s*/)
        if data[1] == "ifrag=" and data[2].to_i == @frag_data[:max] then
          (@amino_acid_letter[aa_count], ile_leu_count) = define_paics_amino_acid(line_data[line_count], ile_leu_count)

          ### Get the atom numbers including fragment
          atom_num = []
          atom_lines = @amino_acid_letter[aa_count][:sum_atoms].div(atom_step)
          if @amino_acid_letter[aa_count][:sum_atoms]%atom_step > 0 then
            atom_lines += 1
          end
          line_count += 1 ### Skip 1 line of "atom (add) ="
          line_position = line_count
          while (line_count < line_position + atom_lines) do
            line_count += 1
            if line_position + 1 == line_count then ### Line on "atom (in) =",
              data = line_data[line_count].split(/\s* \s*/)
              for i in 4..(data.size - 1)
                atom_num[i - 4] = data[i].tr("\r\n|\r|\n", "").to_i
              end
            else
              data = line_data[line_count].split(/\s* \s*/)
              tmp_i = i - 4
              for i in 1..(data.size - 1)
                atom_num[tmp_i + i] = data[i].tr("\r\n|\r|\n", "").to_i
              end
            end
          end
          @amino_acid_letter[aa_count][:atom_num] = atom_num
#          @amino_acid_letter[aa_count][:atom_num] = atom_num.sort
          aa_count += 1
          break
        elsif (data[1] == "ifrag=") then
          (@amino_acid_letter[aa_count], ile_leu_count) = define_paics_amino_acid(line_data[line_count], ile_leu_count)
           ### Get the atom numbers including fragment
          atom_num = []
          atom_lines = @amino_acid_letter[aa_count][:sum_atoms].div(atom_step)
          if @amino_acid_letter[aa_count][:sum_atoms]%atom_step > 0 then
            atom_lines += 1
          end
          line_count += 1 ### Skip 1 line of "atom (add) ="
          line_position = line_count
          while (line_count < line_position + atom_lines) do
            line_count += 1
            if line_position + 1 == line_count then ### Line on "atom (in) =",
              data = line_data[line_count].split(/\s* \s*/)
              for i in 4..(data.size - 1)
                atom_num[i - 4] = data[i].tr("\r\n|\r|\n", "").to_i
              end
            else
              data = line_data[line_count].split(/\s* \s*/)
              tmp_i = i - 4
              for i in 1..(data.size - 1)
                atom_num[tmp_i + i] = data[i].tr("\r\n|\r|\n", "").to_i
              end
            end
          end
          @amino_acid_letter[aa_count][:atom_num] = atom_num
#          @amino_acid_letter[aa_count][:atom_num] = atom_num.sort
          aa_count += 1
        end
      end
      line_count += 1 
    end
    data_file.close
  end

  #*** Define CYX-SS of PAICS Out file using CYS data in PDB file ***#
  def define_cyxss
    cyx_ss = @amino_acid_letter.select{|i| i[:sum_ele] == 106 && i[:sum_atoms] == 20} ### CYX data

    for i in 0..(cyx_ss.size - 1)
      for j in 0..(@@cys_pdb_data.size - 1)
        for k in 0..(cyx_ss[i][:atom_num].size - 1)
          cys = {
            ifrag: 0,        ### SS ifrag
            residue_num: "", ### Redidue number of CYS (Even of Array number: CYX SS, Odd of Array number: Attach to first one)
           }
          if @@cys_pdb_data[j][:sg_atom_num] == cyx_ss[i][:atom_num][k] then
            cys[:ifrag] = cyx_ss[i][:ifrag]
            cys[:residue_num] = @@cys_pdb_data[j][:residue_num]
            @out_ss << cys
          end
        end
      end
    end
    check_ss_pair
  end

  #*** check a number of S-S bonding pairs which is odd or even? ***#
  def check_ss_pair
    if @out_ss.size.modulo(2) == 1 then
       res_num = ""
       @@log.warn "", "*************************************************************************************", "", @@opts[:text]
       @@log.warn "Warning: ", "A number of S-S bonding pairs is an \"odd\" number to compare OUT with PDB!!", "", @@opts[:text]
       @@log.warn "Warning: ", "A number of S-S bonding pairs is \"#{@out_ss.size}\"!!", "", @@opts[:text]
       for i in 0..(@out_ss.size - 1)
         residue_num = res_num + @out_ss[i][:residue_num] + ", "
       end         
       @@log.warn "", "#{residue_num}", "", @@opts[:text]
       @@log.warn "", "*************************************************************************************", "", @@opts[:text]
    end
  end

  #*** Define residue number and name of PDB file using every fragments in PAICS Out file ***#
  def define_pdb_residue_data
#    function_name = "define_pdb_residue_data"
#    e = "%f"%(1.0e-6) ### Convergence condition (10^(-6)) at String type
    e = 1.0e-6 ### Convergence condition (10^(-6))
#    e = 1.0e-3 ### Convergence condition (10^(-3)) for Py_paics_input programed by Dr. S. Nakano

    pdb_letter_code = [{residue_name: "XXX", one_letter: "X"}, {residue_name: "ALA", one_letter: "A"},
                       {residue_name: "CYS", one_letter: "C"}, {residue_name: "ASP", one_letter: "D"},
                       {residue_name: "ASU", one_letter: "D"}, {residue_name: "GLU", one_letter: "E"},
                       {residue_name: "GLP", one_letter: "E"}, {residue_name: "PHE", one_letter: "F"},
                       {residue_name: "GLY", one_letter: "G"}, {residue_name: "HIS", one_letter: "H"},
                       {residue_name: "HIP", one_letter: "H"}, {residue_name: "ILE", one_letter: "I"},
                       {residue_name: "LYS", one_letter: "K"}, {residue_name: "LYY", one_letter: "K"},
                       {residue_name: "LEU", one_letter: "L"}, {residue_name: "MET", one_letter: "M"},
                       {residue_name: "ASN", one_letter: "N"}, {residue_name: "PRO", one_letter: "P"},
                       {residue_name: "GLN", one_letter: "Q"}, {residue_name: "ARG", one_letter: "R"},
                       {residue_name: "ARR", one_letter: "R"}, {residue_name: "SER", one_letter: "S"},
                       {residue_name: "THR", one_letter: "T"}, {residue_name: "VAL", one_letter: "V"},
                       {residue_name: "TRP", one_letter: "W"}, {residue_name: "TYR", one_letter: "Y"},
                       {residue_name: "HOH", one_letter: "o"}, {residue_name: "Na", one_letter: "n"},
                       {residue_name: "Ca", one_letter: "c"}, {residue_name: "Mg", one_letter: "m"},
                       {residue_name: "Cl", one_letter: "l"}, {residue_name: "CYX", one_letter: "C"}]

    @@log.info "", "Process: Define residue number from PAICS out file", "", @@opts[:text]

    for i in 0..(@amino_acid_letter.size - 1)
      data = {
        residue_num: 0,   ### Final residue number in PDB file
        residue_name: "", ### Final residue name (three letter code) in PDB file
        one_letter: "",   ### Final residue name (one letter code) from PDB file
        chain: "",        ### Final chain identifier in PDB file
       }
      @amino_acid_letter[i][:atom_num].each { |num|
        if ((@out_data[num - 1][:x].to_f - @@pdb_all_data[num - 1][:x].to_f).abs <= e and
            (@out_data[num - 1][:y].to_f - @@pdb_all_data[num - 1][:y].to_f).abs <= e and
            (@out_data[num - 1][:z].to_f - @@pdb_all_data[num - 1][:z].to_f).abs <= e) then
          data[:residue_num] = @@pdb_all_data[@amino_acid_letter[i][:atom_num][0] - 1][:residue_num]
          data[:residue_name] = @@pdb_all_data[@amino_acid_letter[i][:atom_num][0] - 1][:residue_name]
          data[:chain] = @@pdb_all_data[@amino_acid_letter[i][:atom_num][0] - 1][:chain]
          if pdb_letter_code.select{|x| x[:name] == @@pdb_all_data[num - 1][:residue_name]}[0] == nil then
            data[:one_letter] = "X"
          else
            data[:one_letter] = @@pdb_letter_code.select{|x| x[:name] == @@pdb_all_data[num - 1][:residue_name]}[0][:one_letter]
          end
          @final_pdb_res[i] = data
          break
        else ### Do not define residue data using coordinations of PDB and PAICS Out 
#          data[:residue_name] = @@pdb_all_data[@amino_acid_letter[i][:atom_num][0] - 1][:residue_name]
#          data[:residue_name] = "XXX"
#          data[:one_letter] = "-"
          data[:residue_num] = @@pdb_all_data[@amino_acid_letter[i][:atom_num][0] - 1][:residue_num]
          data[:residue_name] = "---"
          data[:one_letter] = "-"
          data[:chain] = @@pdb_all_data[@amino_acid_letter[i][:atom_num][0] - 1][:chain]
          @final_pdb_res[i] = data
        end
       }
      if @final_pdb_res[i] == nil then
        @@log.error "", "Error: Difference between XYZ coordinations of atom in PDB file and XYZ coordinations of atom in OUT file!!", "", @@opts[:text]
        @@log.error "", "Error: Please check those files!!", "", @@opts[:text]
      end
    end

    if !(@final_pdb_res.size == @amino_acid_letter.size) then
      @@log.error "", "Error: XYZ coordinations of atom in PDB file are not equal to XYZ coordinations of atom in OUT file!!", "", @@opts[:text]
      @@log.error "", "Error: Please check those files!!", "", @@opts[:text]
    end
  end

  #*** Define residue data from PAICS Out file using sum of electrons and sum of atoms ***#
  def define_paics_amino_acid(line_data, ile_leu_count)
    amino_aicds = [
      {residue_name: "XXX", one_letter: "X", sum_ele: 0, sum_atoms: 0, ifrag: 0, atom_num: [], ss: ""},   ### [0] is unknown amino acid name (= "XXX" or "X")
      {residue_name: "ALA", one_letter: "A", sum_ele: 38, sum_atoms: 10, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "CYS", one_letter: "C", sum_ele: 54, sum_atoms: 11, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "CYX SS", one_letter: "C", sum_ele: 106, sum_atoms: "20", ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "ASP", one_letter: "D", sum_ele: 60, sum_atoms: 12, ifrag: 0, atom_num: [], ss: ""}, ### ASP (COO^{-})
      {residue_name: "ASU", one_letter: "D", sum_ele: 61, sum_atoms: 13, ifrag: 0, atom_num: [], ss: ""}, ### ASU (COOH) = ASP
      {residue_name: "GLU", one_letter: "E", sum_ele: 68, sum_atoms: 15, ifrag: 0, atom_num: [], ss: ""}, ### GLU (COO^{-})
      {residue_name: "GLP", one_letter: "E", sum_ele: 69, sum_atoms: 16, ifrag: 0, atom_num: [], ss: ""}, ### GLU (COOH) = GLP
      {residue_name: "PHE", one_letter: "F", sum_ele: 78, sum_atoms: 20, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "GLY", one_letter: "G", sum_ele: 30, sum_atoms: 7, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "HIS", one_letter: "H", sum_ele: 72, sum_atoms: 17, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "HIP", one_letter: "H", sum_ele: 72, sum_atoms: 18, ifrag: 0, atom_num: [], ss: ""}, ### HIS with hydrogens on both nitrogens, this is positively charged
      {residue_name: "ILE", one_letter: "I", sum_ele: 62, sum_atoms: 19, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "LYS", one_letter: "K", sum_ele: 70, sum_atoms: 22, ifrag: 0, atom_num: [], ss: ""}, ### LYS (NH_{3}^{+})
      {residue_name: "LYY", one_letter: "K", sum_ele: 69, sum_atoms: 21, ifrag: 0, atom_num: [], ss: ""}, ### LYS (NH_{2}) = LYY
      {residue_name: "LEU", one_letter: "L", sum_ele: 62, sum_atoms: 19, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "MET", one_letter: "M", sum_ele: 70, sum_atoms: 17, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "ASN", one_letter: "N", sum_ele: 60, sum_atoms: 14, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "PRO", one_letter: "P", sum_ele: 52, sum_atoms: 14, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "GLN", one_letter: "Q", sum_ele: 68, sum_atoms: 17, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "ARG", one_letter: "R", sum_ele: 84, sum_atoms: 24, ifrag: 0, atom_num: [], ss: ""}, ### ARG (NH_{3}^{+})
      {residue_name: "ARR", one_letter: "R", sum_ele: 83, sum_atoms: 23, ifrag: 0, atom_num: [], ss: ""}, ### ARG (NH_{2}) = ARR
      {residue_name: "SER", one_letter: "S", sum_ele: 46, sum_atoms: 11, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "THR", one_letter: "T", sum_ele: 54, sum_atoms: 14, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "VAL", one_letter: "V", sum_ele: 54, sum_atoms: 16, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "TRP", one_letter: "W", sum_ele: 98, sum_atoms: 24, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "TYR", one_letter: "Y", sum_ele: 86, sum_atoms: 21, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "HOH", one_letter: "o", sum_ele: 10, sum_atoms: 3, ifrag: 0, atom_num: [], ss: ""},  ### H_{2}O = HOH, 1 letter code is defined "o"
      {residue_name: "Na+", one_letter: "n", sum_ele: 10, sum_atoms: 1, ifrag: 0, atom_num: [], ss: ""},  ### Na+, 1 letter code is defined "n"
      {residue_name: "Ca2+", one_letter: "c", sum_ele: 18, sum_atoms: 1, ifrag: 0, atom_num: [], ss: ""}, ### Ca2+, 1 letter code is defined "c"
      {residue_name: "Mg2+", one_letter: "m", sum_ele: 10, sum_atoms: 1, ifrag: 0, atom_num: [], ss: ""}, ### Mg2+, 1 letter code is defined "m"
      {residue_name: "Cl-", one_letter: "l", sum_ele: 18, sum_atoms: 1, ifrag: 0, atom_num: [], ss: ""},  ### Cl-, 1 letter code is defined "l"
     ]

    data = line_data.split(/\s* \s*/)
    if data[5] == "62" and data[8] == "19" then  ### ILE, LEU
      amino_acid_name = define_ile_leu(ile_leu_count)
      ile_leu_count += 1
      tmp = amino_aicds.select{|i| i[:residue_name] == amino_acid_name}[0].dup
      if amino_acid_name == "XXX" then
        tmp[:sum_ele] = data[5].to_i
        tmp[:sum_atoms] = data[8].to_i
        tmp[:ifrag] = data[2].to_i
        [tmp, ile_leu_count]
      else
        tmp[:ifrag] = data[2].to_i
        [tmp, ile_leu_count]
      end
    elsif amino_aicds.map{|i| i[:sum_ele] == data[5].to_i && i[:sum_atoms] == data[8].to_i}.include?(true) then
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ###
       ###   When ("same" sum of electrons) and ("same" sum of atoms), 
       ###   what to do with process in this condition...
       ###   (ex). amino_aicds.select{|i| i[:sum_ele].to_i == 10 && i[:sum_atoms].to_i == 1}
       ###        Counter ions, and so on...
       ###
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ###################################################################################################
       ####################################################################################################
       ####################################################################################################
      tmp = amino_aicds.select{|i| i[:sum_ele] == data[5].to_i && i[:sum_atoms] == data[8].to_i}[0].dup
      tmp[:ifrag] = data[2].to_i
      [tmp, ile_leu_count]
    else ### false (XXX)
      tmp = amino_aicds.select{|i| i[:sum_ele] == 0 && i[:sum_atoms] == 0}[0].dup
      tmp[:sum_ele] = data[5].to_i
      tmp[:sum_atoms] = data[8].to_i
      tmp[:ifrag] = data[2].to_i
      [tmp, ile_leu_count]
    end
  end
   
  #*** Define ILE or LEU using distance (= 1.* [A]) between CB atom and H atom ***#
  def define_ile_leu(ile_leu_count)
    count_ch = 0       ### Count the distance between CB and H = 1.*
    distance_ch = 0.0  ### Distance between CB and H

    for i in 0..10
      distance_ch = distance(@out_data[@@cb_pdb_data[ile_leu_count][:atom_num] - 1][:x].to_f, 
                             @out_data[@@cb_pdb_data[ile_leu_count][:atom_num] - 1][:y].to_f, 
                             @out_data[@@cb_pdb_data[ile_leu_count][:atom_num] - 1][:z].to_f, 
                             @out_data[@@h_pdb_data[i + 11 * ile_leu_count][:atom_num]][:x].to_f, 
                             @out_data[@@h_pdb_data[i + 11 * ile_leu_count][:atom_num]][:y].to_f, 
                             @out_data[@@h_pdb_data[i + 11 * ile_leu_count][:atom_num]][:z].to_f)
      ### Count number of H for bonding C-H
      ### if (1.000000 <= (C-H bond length) < 2.000000)
      if /[1][\.]/ =~ distance_ch.to_s then
        count_ch += 1
      end
    end

    if count_ch == 2 then ### LEU: Number of C-H is 2
      return "LEU"
    elsif count_ch == 1 then ### ILE: Number of C-H is 1
      return "ILE"
    else  ### Unknown (XXX)
      return "XXX"
    end
  end

  #*** Insert HIS and CYS of PDB into data of PAICS out ***#
  def insert_his_cys
    ss_count = 1
    his_count = 0

    while (ss_count <= (@out_ss.size - 1)) do
      ### out_ss[1], [3], [5], ...: S-S bond 
      ### even number: CYX SS, odd number: Attach to first one
      @amino_acid_letter.select{|i| i[:ifrag] == @out_ss[ss_count][:ifrag]}[0][:ss] = @out_ss[ss_count][:residue_num]
      ss_count += 2
    end

    @amino_acid_letter.select{|i| i[:residue_name] == "HIS" or i[:residue_name] == "HIP"}.each { |data|
      data[:residue_name] = @@his_pdb_name[his_count]
      his_count += 1
    }
  end

  #*** Get the distances, HF and dMP2 energies from PAICS out file ***#
  def get_distance_energy(num_of_atoms)
    i = 0
    line_count = 0
    rhf_flag = false      ### "true" is starting to get calculated RHF data 
    dmp2_flag = false     ### "true" is starting to get calculated dMP2 data 
    mulliken_flag = false ### "true" is starting to get mulliken data
#    function_name = "get_distance_energy"

    @sum_mulliken = {sum_pop: 0.0, sum_charge: 0.0}

    work_dir = File.dirname(@@opts[:out])
    distance_zero_filename = "dist_AA_zero.txt"
    distance_zero_path = File.join(work_dir, distance_zero_filename)
    begin 
      dist_file = open(distance_zero_path, "w")
    rescue SystemCallError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
    rescue IOError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
    end
    dist_file.write("\n     ================\n")
    dist_file.write("       fmo-2 result  \n")
    dist_file.write("     ================\n\n")
    dist_file.write("        < rhf ifie >\n\n")
    dist_file.write("                 ij-frag |  dist AA |          rhf     rhf(cp) |\n")
    dist_file.write("            ---------------------------------------------------|\n")

    ### Start line of calculated HF data by PAICS
    rhf_line = "        < rhf ifie >"
    if @@opts[:paics] == 1 then ### Older version than 2012/01/17
      ### Start line of calculated dMP2 data by PAICS
      start_dmp2_line = "        < cmp2 ifie -- resolution of identity >"
      ### End line of calculated dMP2 data by PAICS
      end_dmp2_line = "        < rhf result ( fmo-2 ) >"
      ### Start line of rhf mulliken population (fmo-2)
      start_mulliken = "        < mulliken population ( fmo-2 ) >"
    elsif @@opts[:paics] == 2 then ### 2012/05/13 version
      ### Start line of calculated dMP2 data by PAICS
      if @energy_cal[3] == "yes" then ### ri-mp2
        start_dmp2_line = "        < ri-cmp2 ifie >"
      elsif @energy_cal[2] == "yes" then ### canonical mp2 (= MP2)
        start_dmp2_line = "        < cmp2 ifie >"
      elsif @energy_cal[4] == "yes" then ### local mp2
        ########################################################################
        ########################################################################
        ########################################################################
        ########################################################################
        ########################################################################
        ########################################################################
        ########################################################################
        ########################################################################
        ###
        ###
        ###   Add analysis of process for "local mp2"
        ###
        start_dmp2_line = ""
        ###
        ########################################################################
        ########################################################################
        ########################################################################
        ########################################################################
        ########################################################################
        ########################################################################
        ########################################################################
        ########################################################################
      end
      ### End line of calculated dMP2 data by PAICS
      end_dmp2_line = "        < rhf total energy ( fmo-2 ) >"
      ### Start line of rhf mulliken population (fmo-2)
      start_mulliken = "        < rhf mulliken population ( fmo-2 ) >"
    end

    begin
      data_file = open(@@opts[:out], "r")
    rescue SystemCallError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
    rescue IOError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
    end

    lines = data_file.readlines ### Read line from opened file
    while line_count < lines.size do ### If not EOF
      data = {
        ifrag: 0,         ### i-th fragment
        jfrag: 0,         ### j-th fragment
        distance: 0.0,    ### Calculated distance between ifrag and jfrag [A]
        hf: 0.0,          ### Calculated HF of fragments [hartree]
        hf_cp: 0.0,       ### HF with cp correction [hartree]
        hfkcal: 0.0,      ### HF * 627.50948 [kcal/mol]
        hf_cpkcal: 0.0,   ### HF_cp * 627.50948 [kcal/mol]
        dmp2: 0.0,        ### Calculated dMP2 data of fragments [hartree]
        dmp2_cp: 0.0,     ### dMP2 with cp correction [hartree]
        dmp2kcal: 0.0,    ### dMP2 * 627.50948 [kcal/mol]
        dmp2_cpkcal: 0.0, ### dMP2_cp * 627.50948 [kcal/mol]
        mp2: 0.0,         ### MP2 = HF + dMP2 [hartree]
        mp2_cp: 0.0,      ### MP2_cp = HF_cp + dMP2_cp [hartree]
        mp2kcal: 0.0,     ### MP2 * 627.50948 [kcal/mol]
        mp2_cpkcal: 0.0,  ### MP2_cp * 627.50948 [kcal/mol]
      }
      cmp2 = { ### for canonical mp2 (= MP2)
        ifrag: 0,
        jfrag: 0,
        normal_not_scs: 0.0,        ### cmp2 ifie for normal ( not scs )
        normal_not_scs_cp: 0.0,
        normal_not_scskcal: 0.0,
        normal_not_scs_cpkcal: 0.0,
        grimme_scs: 0.0,            ### cmp2 ifie for Grimme's scs
        grimme_scs_cp: 0.0,
        grimme_scskcal: 0.0,
        grimme_scs_cpkcal: 0.0,
        jung_scs: 0.0,              ### cmp2 ifie for Jung's scs
        jung_scs_cp: 0.0,
        jung_scskcal: 0.0,
        jung_scs_cpkcal: 0.0,
        hill_scs: 0.0,              ### cmp2 ifie for Hill's scs
        hill_scs_cp: 0.0,
        hill_scskcal: 0.0,
        hill_scs_cpkcal: 0.0,
      }
      mulliken = {
        atom_num: 0,
        atom_name: "",
        population: 0.0, ### rhf mulliken population (fmo-2) 
        charge: 0.0,     ### rhf mulliken charge (fmo-2)
      }

      if lines[line_count].tr("\r\n|\r|\n", "") == rhf_line then
        @@log.info "", "Process: Get the Distance [A] and HF (a.u.)", "", @@opts[:text]
        line_count += 4 ### Skip 4 lines
        rhf_flag = true
      elsif lines[line_count].tr("\r\n|\r|\n", "") == start_dmp2_line then
        if ((@@opts[:interaction] == 1) and (@@opts[:mode].to_i == 1)) then
          break
        elsif !((@@opts[:interaction] == 2) and (@@opts[:mode].to_i <= 2)) then
          @@log.info "", "Process: Get the dMP2 (a.u.)", "", @@opts[:text]
          line_count += 5 ### Skip 5 lines
          rhf_flag = false
          dmp2_flag = true
        else
          break
        end
      elsif lines[line_count].tr("\r\n|\r|\n", "") == end_dmp2_line and @@opts[:interaction] == 1 then ### End to get data
        break
      elsif lines[line_count].tr("\r\n|\r|\n", "") == start_mulliken then ### Mulliken populations and charges
        @@log.info "", "Process: Get the mulliken population and charges (a.u.)", "", @@opts[:text]
        line_count += 4 ### Skip 5 lines
        dmp2_flag = false
        mulliken_flag = true
      end

      line_data = lines[line_count].split(/\s* \s*/)
      if (rhf_flag) and !(dmp2_flag) then ### HF data
        if /^[0-9]+$/ =~ line_data[1] and /^[0-9]+$/ =~ line_data[2] and line_data[3] == "|" then
          if (line_data[1].to_i < @frag_data[:frag_num][0].to_i) then
            data[:ifrag] = line_data[1].to_i
            data[:jfrag] = line_data[2].to_i
          elsif (line_data[1].to_i == @frag_data[:frag_num][0].to_i) then
            data[:ifrag] = line_data[2].to_i
            data[:jfrag] = line_data[1].to_i
          end
          data[:distance] = line_data[4].to_f
          if data[:distance] == 0.000 then
            dist_file.write(lines[line_count])
          end
          data[:hf] = line_data[6].to_f
          data[:hfkcal] = (BigDecimal(data[:hf].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
          if (@cp_corr) then
            if !(line_data[7] == "-") then
              data[:hf_cp] = line_data[7].to_f
            else
              data[:hf_cp] = 0.0
            end
            data[:hf_cpkcal] = (BigDecimal(data[:hf_cp].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
          end
          @energy_data << data
        end
      elsif !(rhf_flag) and (dmp2_flag) then ### dMP2 data
        if /^[0-9]+$/ =~ line_data[1] and /^[0-9]+$/ =~ line_data[2] and line_data[3] == "|" then
          if (@energy_data[i][:ifrag] == line_data[1].to_i and @energy_data[i][:jfrag] == line_data[2].to_i) or 
             (@energy_data[i][:ifrag] == line_data[2].to_i and @energy_data[i][:jfrag] == line_data[1].to_i) then
            @energy_data[i][:dmp2] = line_data[4].to_f  ### ri-mp2, or cmp2 (normal ( not scs )) if canonical mp2 (= MP2)
            @energy_data[i][:dmp2kcal] = (BigDecimal(@energy_data[i][:dmp2].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
            @energy_data[i][:mp2] = (BigDecimal(@energy_data[i][:hf].to_s) + BigDecimal(@energy_data[i][:dmp2].to_s)).to_f
            @energy_data[i][:mp2kcal] = (BigDecimal(@energy_data[i][:hfkcal].to_s) + BigDecimal(@energy_data[i][:dmp2kcal].to_s)).to_f
            if (@cp_corr) then
              if !(line_data[5] == "-") then
                @energy_data[i][:dmp2_cp] = line_data[5].to_f  ### ri-mp2, or cmp2 (normal ( not scs )) if canonical mp2 (= MP2)
              else
                @energy_data[i][:dmp2_cp] = 0.0
              end
              @energy_data[i][:dmp2_cpkcal] = (BigDecimal(@energy_data[i][:dmp2_cp].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
              @energy_data[i][:mp2_cp] = (BigDecimal(@energy_data[i][:hf_cp].to_s) + BigDecimal(@energy_data[i][:dmp2_cp].to_s)).to_f
              @energy_data[i][:mp2_cpkcal] = (BigDecimal(@energy_data[i][:hf_cpkcal].to_s) + BigDecimal(@energy_data[i][:dmp2_cpkcal].to_s)).to_f
            end
            if @energy_cal[2] == "yes" then  ### cmp2: canonical mp2 = MP2
              cmp2[:ifrag] = line_data[1].to_i
              cmp2[:jfrag] = line_data[2].to_i
              cmp2[:normal_not_scs] = line_data[4].to_f
              cmp2[:grimme_scs] = line_data[7].to_f
              cmp2[:jung_scs] = line_data[10].to_f
              cmp2[:hill_scs] = line_data[13].to_f
              cmp2[:normal_not_scskcal] = (BigDecimal(cmp2[:normal_not_scs].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
              cmp2[:grimme_scskcal] = (BigDecimal(cmp2[:grimme_scs].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
              cmp2[:jung_scskcal] = (BigDecimal(cmp2[:jung_scs].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
              cmp2[:hill_scskcal] = (BigDecimal(cmp2[:hill_scs].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
              if (@cp_corr) then
                if !(line_data[5] == "-") then
                  cmp2[:normal_not_scs_cp] = line_data[5].to_f
                  cmp2[:grimme_scs_cp] = line_data[8].to_f
                  cmp2[:jung_scs_cp] = line_data[11].to_f
                  cmp2[:hill_scs_cp] = line_data[14].to_f
                else
                  cmp2[:normal_not_scs_cp] = 0.0
                  cmp2[:grimme_scs_cp] = 0.0
                  cmp2[:jung_scs_cp] = 0.0
                  cmp2[:hill_scs_cp] = 0.0
                end
                cmp2[:normal_not_scs_cpkcal] = (BigDecimal(cmp2[:normal_not_scs_cp].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
                cmp2[:grimme_scs_cpkcal] = (BigDecimal(cmp2[:grimme_scs_cp].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
                cmp2[:jung_scs_cpkcal] = (BigDecimal(cmp2[:jung_scs_cp].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
                cmp2[:hill_scs_cpkcal] = (BigDecimal(cmp2[:hill_scs_cp].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
              end
              @cmp2_data << cmp2
            elsif @energy_cal[4] == "yes" then ### local mp2
                ############################################################################################
                ############################################################################################
                ############################################################################################
                ############################################################################################
                ############################################################################################
                ############################################################################################
                ###
                ###   Add analysis of process for "local mp2"
                ###
                ############################################################################################
                ############################################################################################
                ############################################################################################
                ############################################################################################
                ############################################################################################
                ############################################################################################
            end
            i += 1
          end
        end
      elsif (mulliken_flag) and !(dmp2_flag) then
        if (line_data[1].to_i == num_of_atoms) then
          mulliken[:atom_num] = line_data[1].to_i
          mulliken[:atom_name] = line_data[2]
          mulliken[:population] = ("%.6f"%line_data[3]).to_f
          mulliken[:charge] = ("%.6f"%line_data[4].tr("\r\n|\r|\n", "")).to_f
          @mulliken_charge << mulliken
          mulliken_flag = false
        else
          mulliken[:atom_num] = line_data[1].to_i
          mulliken[:atom_name] = line_data[2]
          mulliken[:population] = ("%.6f"%line_data[3]).to_f
          mulliken[:charge] = ("%.6f"%line_data[4].tr("\r\n|\r|\n", "")).to_f
          @mulliken_charge << mulliken
        end
      elsif line_data[1] == "sum" then
        @sum_mulliken[:sum_pop] = ("%.6f"%line_data[2]).to_f
        @sum_mulliken[:sum_charge] = ("%.6f"%line_data[3].tr("\r\n|\r|\n", "")).to_f
#        if !(@sum_mulliken[:sum_charge] == 0) then
#          @@log.error "\n", "Error: Sum of mulliken charge is not equal to 0!!", "", @@opts[:text]
#        end
        @@log.info "\n", "  * Sum of mulliken charge in this system: #{@sum_mulliken[:sum_charge]}", "", @@opts[:text]
        break
      end
      line_count += 1
    end

    dist_file.write("            ---------------------------------------------------|\n\n")
    dist_file.close

    if !(@mulliken_charge == []) ### Make new PDB file replacing B-factor with RHF-MP2 mulliken charge
      Write_data.new.make_pdb_charge(@mulliken_charge, @@opts)
    end
  end

  #*** Calculate the average distance and energy data "every particles (ligand)" ***#
  def cal_ave_data
    i = 1
    if !(@@flags[:ligand_num]) then
      if @frag_data[:particle] > 1 then
        while (i < @frag_data[:frag_num][0]) do
          j = 0
          data = {
            ifrag: "",        ### i-th fragment
            jfrag: "",        ### j-th fragment
            distance: 0.0,    ### Calculated average distance between ifrag and jfrag [A]
            distance_frag: [], 
            hf: 0.0,          ### Calculated HF of fragments [hartree]
            hf_frag: [], 
            hf_cp: 0.0,       ### HF with cp correction [hartree]
            hf_cp_frag: [], 
            hfkcal: 0.0,      ### HF * 627.50948 [kcal/mol]
            hfkcal_frag: [], 
            hf_cpkcal: 0.0,   ### HF_cp * 627.50948 [kcal/mol]
            hf_cpkcal_frag: [], 
            dmp2: 0.0,        ### Calculated dMP2 data of fragments [hartree]
            dmp2_frag: [], 
            dmp2_cp: 0.0,     ### dMP2 with cp correction [hartree]
            dmp2_cp_frag: [], 
            dmp2kcal: 0.0,    ### dMP2 * 627.50948 [kcal/mol]
            dmp2kcal_frag: [], 
            dmp2_cpkcal: 0.0, ### dMP2_cp * 627.50948 [kcal/mol]
            dmp2_cpkcal_frag: [], 
            mp2: 0.0,         ### MP2 = HF + dMP2 [hartree]
            mp2_frag: [], 
            mp2_cp: 0.0,      ### MP2_cp = HF_cp + dMP2_cp [hartree]
            mp2_cp_frag: [], 
            mp2kcal: 0.0,     ### MP2 * 627.50948 [kcal/mol]
            mp2kcal_frag: [], 
            mp2_cpkcal: 0.0,  ### MP2_cp * 627.50948 [kcal/mol]
            mp2_cpkcal_frag: [], 
           }
          @frag_data[:frag_num].each { |f|
            @energy_data.select{|t| t[:ifrag] == i && t[:jfrag] == f}.each { |d|
              data[:distance] = (BigDecimal(data[:distance].to_s) + BigDecimal(d[:distance].to_s)).to_f
              data[:distance_frag][j] = d[:distance]
              data[:hf] = (BigDecimal(data[:hf].to_s) + BigDecimal(d[:hf].to_s)).to_f
              data[:hf_frag][j] = d[:hf]
              data[:hf_cp] = (BigDecimal(data[:hf_cp].to_s) + BigDecimal(d[:hf_cp].to_s)).to_f
              data[:hf_cp_frag][j] = d[:hf_cp]
              data[:hfkcal] = (BigDecimal(data[:hfkcal].to_s) + BigDecimal(d[:hfkcal].to_s)).to_f
              data[:hfkcal_frag][j] = d[:hfkcal]
              data[:hf_cpkcal] = (BigDecimal(data[:hf_cpkcal].to_s) + BigDecimal(d[:hf_cpkcal].to_s)).to_f
              data[:hf_cpkcal_frag][j] = d[:hf_cpkcal]
              data[:dmp2] = (BigDecimal(data[:dmp2].to_s) + BigDecimal(d[:dmp2].to_s)).to_f
              data[:dmp2_frag][j] = d[:dmp2]
              data[:dmp2_cp] = (BigDecimal(data[:dmp2_cp].to_s) + BigDecimal(d[:dmp2_cp].to_s)).to_f
              data[:dmp2_cp_frag][j] = d[:dmp2_cp]
              data[:dmp2kcal] = (BigDecimal(data[:dmp2kcal].to_s) + BigDecimal(d[:dmp2kcal].to_s)).to_f
              data[:dmp2kcal_frag][j] = d[:dmp2kcal]
              data[:dmp2_cpkcal] = (BigDecimal(data[:dmp2_cpkcal].to_s) + BigDecimal(d[:dmp2_cpkcal].to_s)).to_f
              data[:dmp2_cpkcal_frag][j] = d[:dmp2_cpkcal]
              data[:mp2] = (BigDecimal(data[:mp2].to_s) + BigDecimal(d[:mp2].to_s)).to_f
              data[:mp2_frag][j] = d[:mp2]
              data[:mp2_cp] = (BigDecimal(data[:mp2_cp].to_s) + BigDecimal(d[:mp2_cp].to_s)).to_f
              data[:mp2_cp_frag][j] = d[:mp2_cp]
              data[:mp2kcal] = (BigDecimal(data[:mp2kcal].to_s) + BigDecimal(d[:mp2kcal].to_s)).to_f
              data[:mp2kcal_frag][j] = d[:mp2kcal]
              data[:mp2_cpkcal] = (BigDecimal(data[:mp2_cpkcal].to_s) + BigDecimal(d[:mp2_cpkcal].to_s)).to_f
              data[:mp2_cpkcal_frag][j] = d[:mp2_cpkcal]
              j += 1
             }
          }
          data[:ifrag] = i
#          data[:jfrag] = "target"
          data[:jfrag] = @frag_data[:frag_num][0]
          data[:distance] /= @frag_data[:particle]
          @ave_data << data
          i += 1
        end
      elsif (@frag_data[:particle] == 1) then
        if (@frag_data[:max] == @energy_data.size) then
          @ave_data = @energy_data.dup
        else ### If data is All-pairs mode and opts[:interaction] == 1 (Ligand mode)
          if (@frag_data[:frag_num][0].to_i < @frag_data[:max]) then
            while (i <= @frag_data[:max]) do
              data = {
                ifrag: "",
                jfrag: "",
                distance: 0.0,
                hf: 0.0,
                hf_cp: 0.0,
                hfkcal: 0.0,
                hf_cpkcal: 0.0,
                dmp2: 0.0,
                dmp2_cp: 0.0,
                dmp2kcal: 0.0,
                dmp2_cpkcal: 0.0,
                mp2: 0.0,
                mp2_cp: 0.0,
                mp2kcal: 0.0,
                mp2_cpkcal: 0.0,
               }
              @energy_data.select{|t| t[:ifrag] == i && t[:jfrag] == @frag_data[:frag_num][0]}.each { |d|
                data[:ifrag] = i
                data[:jfrag] = @frag_data[:frag_num][0]
                data[:distance] = d[:distance]
                data[:hf] = d[:hf]
                data[:hf_cp] = d[:hf_cp]
                data[:hfkcal] = d[:hfkcal]
                data[:hf_cpkcal] = d[:hf_cpkcal]
                data[:dmp2] = d[:dmp2]
                data[:dmp2_cp] = d[:dmp2_cp]
                data[:dmp2kcal] = d[:dmp2kcal]
                data[:dmp2_cpkcal] = d[:dmp2_cpkcal]
                data[:mp2] = d[:mp2]
                data[:mp2_cp] = d[:mp2_cp]
                data[:mp2kcal] = d[:mp2kcal]
                data[:mp2_cpkcal] = d[:mp2_cpkcal]
               }
              if !(i == @frag_data[:frag_num][0].to_i) then
                @ave_data << data
              end
              i += 1
            end
          elsif (@frag_data[:frag_num][0] == @frag_data[:max]) then
            while (i < @frag_data[:max]) do
              data = {
                ifrag: "",
                jfrag: "",
                distance: 0.0,
                hf: 0.0,
                hf_cp: 0.0,
                hfkcal: 0.0,
                hf_cpkcal: 0.0,
                dmp2: 0.0,
                dmp2_cp: 0.0,
                dmp2kcal: 0.0,
                dmp2_cpkcal: 0.0,
                mp2: 0.0,
                mp2_cp: 0.0,
                mp2kcal: 0.0,
                mp2_cpkcal: 0.0,
               }
              @energy_data.select{|t| t[:ifrag] == i && t[:jfrag] == @frag_data[:frag_num][0]}.each { |d|
                data[:ifrag] = i
                data[:jfrag] = @frag_data[:frag_num][0]
                data[:distance] = d[:distance]
                data[:hf] = d[:hf]
                data[:hf_cp] = d[:hf_cp]
                data[:hfkcal] = d[:hfkcal]
                data[:hf_cpkcal] = d[:hf_cpkcal]
                data[:dmp2] = d[:dmp2]
                data[:dmp2_cp] = d[:dmp2_cp]
                data[:dmp2kcal] = d[:dmp2kcal]
                data[:dmp2_cpkcal] = d[:dmp2_cpkcal]
                data[:mp2] = d[:mp2]
                data[:mp2_cp] = d[:mp2_cp]
                data[:mp2kcal] = d[:mp2kcal]
                data[:mp2_cpkcal] = d[:mp2_cpkcal]
               }
              @ave_data << data
              i += 1
            end
          end
        end
      end
    else ### With -n option
      while (i <= @frag_data[:max]) do
        if !(i == @@opts[:ligand_num]) then
          data = {
            ifrag: "",
            jfrag: "",
            distance: 0.0,
            hf: 0.0,
            hf_cp: 0.0,
            hfkcal: 0.0,
            hf_cpkcal: 0.0,
            dmp2: 0.0,
            dmp2_cp: 0.0,
            dmp2kcal: 0.0,
            dmp2_cpkcal: 0.0,
            mp2: 0.0,
            mp2_cp: 0.0,
            mp2kcal: 0.0,
            mp2_cpkcal: 0.0,
           }
        end
        if (i < @@opts[:ligand_num]) then
          @energy_data.select{|t| t[:ifrag] == i && t[:jfrag] == @@opts[:ligand_num]}.each { |d|
            data[:ifrag] = i
            data[:jfrag] = @@opts[:ligand_num]
            data[:distance] = d[:distance]
            data[:hf] = d[:hf]
            data[:hf_cp] = d[:hf_cp]
            data[:hfkcal] = d[:hfkcal]
            data[:hf_cpkcal] = d[:hf_cpkcal]
            data[:dmp2] = d[:dmp2]
            data[:dmp2_cp] = d[:dmp2_cp]
            data[:dmp2kcal] = d[:dmp2kcal]
            data[:dmp2_cpkcal] = d[:dmp2_cpkcal]
            data[:mp2] = d[:mp2]
            data[:mp2_cp] = d[:mp2_cp]
            data[:mp2kcal] = d[:mp2kcal]
            data[:mp2_cpkcal] = d[:mp2_cpkcal]
           }
        elsif (i > @@opts[:ligand_num]) then
          @energy_data.select{|t| t[:ifrag] == @@opts[:ligand_num] && t[:jfrag] == i}.each { |d|
            data[:ifrag] = i
            data[:jfrag] = @@opts[:ligand_num]
            data[:distance] = d[:distance]
            data[:hf] = d[:hf]
            data[:hf_cp] = d[:hf_cp]
            data[:hfkcal] = d[:hfkcal]
            data[:hf_cpkcal] = d[:hf_cpkcal]
            data[:dmp2] = d[:dmp2]
            data[:dmp2_cp] = d[:dmp2_cp]
            data[:dmp2kcal] = d[:dmp2kcal]
            data[:dmp2_cpkcal] = d[:dmp2_cpkcal]
            data[:mp2] = d[:mp2]
            data[:mp2_cp] = d[:mp2_cp]
            data[:mp2kcal] = d[:mp2kcal]
            data[:mp2_cpkcal] = d[:mp2_cpkcal]
           }
        end
        @ave_data << data
        i += 1
      end
    end
  end

  #*** Make data line for 1-dimensional table (Selected-pairs mode) from PAICS Out file ***#
  def paics_selectedpairs_output
#    function_name = "paics_selectedpairs_output"
    i = 0

    ### Decide target number of fragments (Ligands)
    if !(@@flags[:ligand_num]) then
      if @frag_data[:particle] == 1 then
        target = @frag_data[:frag_num][0].to_s
      else
#        target = "target"
        target = @frag_data[:frag_num][0].to_s
      end
    else
      target = @@opts[:ligand_num].to_s
    end

    @@log.info "\n", "Process: Write energy data at one-dimensional table", "", @@opts[:text]
    if @@opts[:mode] == 1 then ### HF
      @@log.info "", "Process: Write the HF (a.u.) or HF [kcal/mol]", "\n", @@opts[:text]
      write_line = "-" * 135 + "\n"
      data_txt_label = "   ij-frag   | %11s | %15s | %5s | %14s | %8s | %15s | % 9s  | % 20s |\n"%["Amino Acid" , "Amino Acid(PDB)", "Chain", 
                       "Residue Number".center(14), "S-S bond", "Distance [A]".center(15), "E(ij)^HF", "E(ij)^HF [kcal/mol]"]
      data_csv_label = ",,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n"%["Number", "Fragment Number", "Amino Acid" , "Amino Acid(PDB)", "Chain", 
                       "Residue Number", "S-S bond", "Distance", "E(ij)^HF", "E(ij)^HF [kcal/mol]"]
    elsif @@opts[:mode] == 2 then ### dMP2
      @@log.info "", "Process: Write the dMP2 (a.u.) or dMP2 [kcal/mol]", "\n", @@opts[:text]
      write_line = "-" * 150 + "\n"
      data_txt_label = "   ij-frag   | %11s | %15s | %5s | %14s | %8s | %15s | % 9s  | % 10s | %21s |\n"%["Amino Acid" , "Amino Acid(PDB)", "Chain", 
                       "Residue Number".center(14), "S-S bond", "Distance [A]".center(15), "E(ij)^HF", "E(ij)^dMP2", "E(ij)^dMP2 [kcal/mol]"]
      data_csv_label = ",,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n"%["Number", "Fragment Number", "Amino Acid", "Amino Acid(PDB)", "Chain", 
                       "Residue Number", "S-S bond", "Distance", "E(ij)^HF", "E(ij)^dMP2", "MP2", "E(ij)^dMP2 [kcal/mol]"]
    elsif @@opts[:mode] == 3 then ### MP2
      @@log.info "", "Process: Write the MP2 (a.u.) or MP2 [kcal/mol]", "\n", @@opts[:text]
      write_line = "-" * 153 + "\n"
      data_txt_label = "   ij-frag   | %11s | %15s | %5s | %14s | %8s | %15s | % 9s  | % 10s | %10s | %11s |\n"%["Amino Acid" , "Amino Acid(PDB)", "Chain", 
                       "Residue Number".center(14), "S-S bond", "Distance [A]".center(15), "E(ij)^HF", "E(ij)^dMP2", "MP2".center(9), "[kcal/mol]"]
      data_csv_label = ",,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n"%["Number", "Fragment Number", "Amino Acid" , "Amino Acid(PDB)", "Chain", 
                       "Residue Number", "S-S bond", "Distance", "E(ij)^HF", "E(ij)^dMP2","MP2", "MP2[kcal/mol]"]
    end
    ### Write header in output
    Write_data.new.write_txt_data("\n<Data>\n", @@opts, 1, @@log)
    Write_data.new.write_txt_data(write_line, @@opts, 1, @@log)
    Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
    Write_data.new.write_txt_data(write_line, @@opts, 1, @@log)
    Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)

    if (@@flags[:ligand_num]) then  ### With -n option
      while (i < (@frag_data[:max] - 1)) do
        if @@opts[:mode] == 1 then ### HF
          if (@cp_corr) then ### cp corr == yes
            if (i + 1 < @@opts[:ligand_num]) then
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                               @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                               @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
            elsif (i + 1 >= @@opts[:ligand_num]) then
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 2), target, 
                               @amino_acid_letter[i + 1][:residue_name].center(11), @final_pdb_res[i + 1][:residue_name].center(15), @final_pdb_res[i + 1][:chain].center(5), 
                               @final_pdb_res[i + 1][:residue_num].to_s.center(14), @amino_acid_letter[i + 1][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 2), target, 
                               @amino_acid_letter[i + 1][:residue_name], @final_pdb_res[i + 1][:residue_name], @final_pdb_res[i + 1][:chain], 
                               @final_pdb_res[i + 1][:residue_num].to_s, @amino_acid_letter[i + 1][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
            end
          else ### cp corr == no
            if (i + 1 < @@opts[:ligand_num]) then
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                               @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hfkcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                               @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hfkcal]]
            elsif (i + 1 >= @@opts[:ligand_num]) then
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 2), target, 
                               @amino_acid_letter[i + 1][:residue_name].center(11), @final_pdb_res[i + 1][:residue_name].center(15), @final_pdb_res[i + 1][:chain].center(5), 
                               @final_pdb_res[i + 1][:residue_num].to_s.center(14), @amino_acid_letter[i + 1][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hfkcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 2), target, 
                               @amino_acid_letter[i + 1][:residue_name], @final_pdb_res[i + 1][:residue_name], @final_pdb_res[i + 1][:chain], 
                               @final_pdb_res[i + 1][:residue_num].to_s, @amino_acid_letter[i + 1][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hfkcal]]
            end
          end
        elsif @@opts[:mode] == 2 then ### dMP2
          if (@cp_corr) then ### cp corr == yes
            if (i + 1 < @@opts[:ligand_num]) then
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                               @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                               @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
            elsif (i + 1 >= @@opts[:ligand_num]) then
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 2), target, 
                               @amino_acid_letter[i + 1][:residue_name].center(11), @final_pdb_res[i + 1][:residue_name].center(15), @final_pdb_res[i + 1][:chain].center(5), 
                               @final_pdb_res[i + 1][:residue_num].to_s.center(14), @amino_acid_letter[i + 1][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 2), target, 
                               @amino_acid_letter[i + 1][:residue_name], @final_pdb_res[i + 1][:residue_name], @final_pdb_res[i + 1][:chain], 
                               @final_pdb_res[i + 1][:residue_num].to_s, @amino_acid_letter[i + 1][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
            end
          else ### cp corr == no
            if (i + 1 < @@opts[:ligand_num]) then
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                               @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                               @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
            elsif (i + 1 >= @@opts[:ligand_num]) then
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 2), target, 
                               @amino_acid_letter[i + 1][:residue_name].center(11), @final_pdb_res[i + 1][:residue_name].center(15), @final_pdb_res[i + 1][:chain].center(5), 
                               @final_pdb_res[i + 1][:residue_num].to_s.center(14), @amino_acid_letter[i + 1][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 2), target, 
                               @amino_acid_letter[i + 1][:residue_name], @final_pdb_res[i + 1][:residue_name], @final_pdb_res[i + 1][:chain], 
                               @final_pdb_res[i + 1][:residue_num].to_s, @amino_acid_letter[i + 1][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
            end
          end
        elsif @@opts[:mode] == 3 then ### MP2
          if (@cp_corr) then ### cp corr == yes
            if (i + 1 < @@opts[:ligand_num]) then
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                               @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                               @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
              @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal].to_s)).to_f
            elsif (i + 1 >= @@opts[:ligand_num]) then
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 2), target, 
                               @amino_acid_letter[i + 1][:residue_name].center(11), @final_pdb_res[i + 1][:residue_name].center(15), @final_pdb_res[i + 1][:chain].center(5), 
                               @final_pdb_res[i + 1][:residue_num].to_s.center(14), @amino_acid_letter[i + 1][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 2), target, 
                               @amino_acid_letter[i + 1][:residue_name], @final_pdb_res[i + 1][:residue_name], @final_pdb_res[i + 1][:chain], 
                               @final_pdb_res[i + 1][:residue_num].to_s, @amino_acid_letter[i + 1][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
              @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cpkcal].to_s)).to_f
            end
          else ### cp corr == no
            if (i + 1 < @@opts[:ligand_num]) then
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                               @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                               @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal]]
              @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal].to_s)).to_f
            elsif (i + 1 >= @@opts[:ligand_num]) then
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 2), target, 
                               @amino_acid_letter[i + 1][:residue_name].center(11), @final_pdb_res[i + 1][:residue_name].center(15), @final_pdb_res[i + 1][:chain].center(5), 
                               @final_pdb_res[i + 1][:residue_num].to_s.center(14), @amino_acid_letter[i + 1][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2kcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 2), target, 
                               @amino_acid_letter[i + 1][:residue_name], @final_pdb_res[i + 1][:residue_name], @final_pdb_res[i + 1][:chain], 
                               @final_pdb_res[i + 1][:residue_num].to_s, @amino_acid_letter[i + 1][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2kcal]]
              @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2kcal].to_s)).to_f
            end
          end
        end
        Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
        Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
        i += 1
      end
    else ### without -n option
      if (@frag_data[:particle] == 1) then
        while (i < (@frag_data[:max] - 1)) do
          if @@opts[:mode] == 1 then ### HF
            if (@cp_corr) then ### cp corr == yes
              if (i + 1 < @frag_data[:frag_num][0]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 1), target, 
                                 @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                                 @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 1), target, 
                                 @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                                 @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
              elsif (i + 1 >= frag_data[:frag_num][0]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 2), target, 
                                 @amino_acid_letter[i + 1][:residue_name].center(11), @final_pdb_res[i + 1][:residue_name].center(15), @final_pdb_res[i + 1][:chain].center(5), 
                                 @final_pdb_res[i + 1][:residue_num].to_s.center(14), @amino_acid_letter[i + 1][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 2), target, 
                                 @amino_acid_letter[i + 1][:residue_name], @final_pdb_res[i + 1][:residue_name], @final_pdb_res[i + 1][:chain], 
                                 @final_pdb_res[i + 1][:residue_num].to_s, @amino_acid_letter[i + 1][:ss], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
              end
            else ### cp corr == no
              if (i + 1 < @frag_data[:frag_num][0]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 1), target, 
                                 @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                                 @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hfkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 1), target, 
                                 @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                                 @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hfkcal]]
              elsif (i + 1 >= @frag_data[:frag_num][0]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 2), target, 
                                 @amino_acid_letter[i + 1][:residue_name].center(11), @final_pdb_res[i + 1][:residue_name].center(15), @final_pdb_res[i + 1][:chain].center(5), 
                                 @final_pdb_res[i + 1][:residue_num].to_s.center(14), @amino_acid_letter[i + 1][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hfkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 2), target, 
                                 @amino_acid_letter[i + 1][:residue_name], @final_pdb_res[i + 1][:residue_name], @final_pdb_res[i + 1][:chain], 
                                 @final_pdb_res[i + 1][:residue_num].to_s, @amino_acid_letter[i + 1][:ss], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hfkcal]]
              end
            end
          elsif @@opts[:mode] == 2 then ### dMP2
            if (@cp_corr) then ### cp corr == yes
              if (i + 1 < @frag_data[:frag_num][0]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 1), target, 
                                 @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                                 @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                 @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                                 @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
              elsif (i + 1 >= @frag_data[:frag_num][0]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 2), target, 
                                 @amino_acid_letter[i + 1][:residue_name].center(11), @final_pdb_res[i + 1][:residue_name].center(15), @final_pdb_res[i + 1][:chain].center(5), 
                                 @final_pdb_res[i + 1][:residue_num].to_s.center(14), @amino_acid_letter[i + 1][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 2), target, 
                                 @amino_acid_letter[i + 1][:residue_name], @final_pdb_res[i + 1][:residue_name], @final_pdb_res[i + 1][:chain], 
                                 @final_pdb_res[i + 1][:residue_num].to_s, @amino_acid_letter[i + 1][:ss], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
              end
            else ### cp corr == no
              if (i + 1 < @frag_data[:frag_num][0]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 1), target, 
                                 @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                                 @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                 @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                                 @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
              elsif (i + 1 >= @frag_data[:frag_num][0]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 2), target, 
                                 @amino_acid_letter[i + 1][:residue_name].center(11), @final_pdb_res[i + 1][:residue_name].center(15), @final_pdb_res[i + 1][:chain].center(5), 
                                 @final_pdb_res[i + 1][:residue_num].to_s.center(14), @amino_acid_letter[i + 1][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 2), target, 
                                 @amino_acid_letter[i + 1][:residue_name], @final_pdb_res[i + 1][:residue_name], @final_pdb_res[i + 1][:chain], 
                                 @final_pdb_res[i + 1][:residue_num].to_s, @amino_acid_letter[i + 1][:ss], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
              end
            end
          elsif @@opts[:mode] == 3 then ### MP2
            if (@cp_corr) then ### cp corr == yes
              if (i + 1 < @frag_data[:frag_num][0]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 1), target, 
                                 @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                                 @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                 @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                                 @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
                @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal].to_s)).to_f
              elsif (i + 1 >= @frag_data[:frag_num][0]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 2), target, 
                                 @amino_acid_letter[i + 1][:residue_name].center(11), @final_pdb_res[i + 1][:residue_name].center(15), @final_pdb_res[i + 1][:chain].center(5), 
                                 @final_pdb_res[i + 1][:residue_num].to_s.center(14), @amino_acid_letter[i + 1][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 2), target, 
                                 @amino_acid_letter[i + 1][:residue_name], @final_pdb_res[i + 1][:residue_name], @final_pdb_res[i + 1][:chain], 
                                 @final_pdb_res[i + 1][:residue_num].to_s, @amino_acid_letter[i + 1][:ss], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
                @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cpkcal].to_s)).to_f
              end
            else ### cp corr == no
              if (i + 1 < @frag_data[:frag_num][0]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 1), target, 
                                 @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                                 @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                 @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                                 @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal]]
                @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal].to_s)).to_f
              elsif (i + 1 >= @frag_data[:frag_num][0]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 2), target, 
                                 @amino_acid_letter[i + 1][:residue_name].center(11), @final_pdb_res[i + 1][:residue_name].center(15), @final_pdb_res[i + 1][:chain].center(5), 
                                 @final_pdb_res[i + 1][:residue_num].to_s.center(14), @amino_acid_letter[i + 1][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2kcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 2), target, 
                                 @amino_acid_letter[i + 1][:residue_name], @final_pdb_res[i + 1][:residue_name], @final_pdb_res[i + 1][:chain], 
                                 @final_pdb_res[i + 1][:residue_num].to_s, @amino_acid_letter[i + 1][:ss], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2kcal]]
                @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2kcal].to_s)).to_f
              end
            end
          end
          Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
          Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
          i += 1
        end
      elsif (@frag_data[:particle] > 1) then
         ###################################################################################
         ###################################################################################
         ###################################################################################
         ###################################################################################
         ###################################################################################
         ###################################################################################
         ###################################################################################
         ###################################################################################
         ###
         ###  Now, [1, 2, ..., (100, 101, 102, ...), ..., max] is not able to analyze...
         ###    (* In this case, [100, 101, 102, ...] are particle fragments.)
         ###
         ###################################################################################
         ###################################################################################
         ###################################################################################
         ###################################################################################
         ###################################################################################
         ###################################################################################
         ###################################################################################
         ###################################################################################
        while (i < (@frag_data[:frag_num][0] - 1)) do
          if @@opts[:mode] == 1 then ### HF
            if (@cp_corr) then ### cp corr == yes
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                               @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                               @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
            else ### cp corr == no
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                               @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hfkcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                               @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hfkcal]] 
            end
          elsif @@opts[:mode] == 2 then ### dMP2
            if (@cp_corr) then ### cp corr == yes
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                               @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                               @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
            else ### cp corr == no
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                               @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                               @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
            end
          elsif @@opts[:mode] == 3 then ### MP2
            if (@cp_corr) then ### cp corr == yes
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                               @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                               @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
              @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal].to_s)).to_f
            else ### cp corr == no
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name].center(11), @final_pdb_res[i][:residue_name].center(15), @final_pdb_res[i][:chain].center(5), 
                               @final_pdb_res[i][:residue_num].to_s.center(14), @amino_acid_letter[i][:ss].center(8), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 1), target, 
                               @amino_acid_letter[i][:residue_name], @final_pdb_res[i][:residue_name], @final_pdb_res[i][:chain], 
                               @final_pdb_res[i][:residue_num].to_s, @amino_acid_letter[i][:ss], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal]]
              @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal].to_s)).to_f
            end
          end
          Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
          Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
          i += 1
        end
      end
    end
    Write_data.new.write_txt_data(write_line, @@opts, 1, @@log)

    if @@opts[:mode] == 3 then ### MP2
      ### Label for Binding Affinity
      data_txt_label = "Binding Affinity = % 9.4f [kcal/mol]"%@binding_affinity
      data_csv_label = "\n\n,,Binding Affinity,%9.4f [kcal/mol]"%@binding_affinity
      @@log.info "\n", "  #{data_txt_label}", "\n", @@opts[:text]
      Write_data.new.write_txt_data("\n", @@opts, 1, @@log)
      Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
      Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
    end
  end

  #*** Make data line for 2-dimensional table (All fragment interaction mode) from PAICS Out file ***#
  def paics_all_output(energy)
#    function_name = "paics_all_output"
    data_txt_label = ""
    data_csv_label = ""
    dat_line = ""
    @dat_file = "2d_energy.dat"
    plot_energy = []
    energy_count = 0

    @@log.info "\n", "Process: Write energy data at two-dimensional table", "\n", @@opts[:text]

    for i in (@@opts[:fragment][0] - 1)..@@opts[:fragment][1]
      for j in (@@opts[:fragment][0] - 1)..(@@opts[:fragment][1] + 1)
        if i == (@@opts[:fragment][0] - 1) then ### First line
          if j == (@@opts[:fragment][0] - 1) then
            data_txt_label += "| %16s "%""
            data_csv_label += ",,,,"
          elsif j == (@@opts[:fragment][0]) or j == (@@opts[:fragment][0] + 1) then
            data_txt_label += " %12s "%""
            data_csv_label += "%s,"%""
          elsif j == (@@opts[:fragment][1] + 1) then
            data_txt_label += "%25s |\n"%(j - 2).to_s
            data_csv_label += ",%s\n"%(j - 2).to_s
          else
            data_txt_label += "%24s "%(j - 2).to_s
            data_csv_label += ",%s"%(j - 2).to_s
          end 
        else ### Other line (2rd, 3rd, 4th,... Nth line)
          if j == (@@opts[:fragment][0] - 1) then
            data_txt_label += "| %5s |"%i.to_s
            data_csv_label += ",%s,"%i.to_s
          elsif j == @@opts[:fragment][0] then
            data_txt_label += " %6s | %6s | %s | %6s |"%[@amino_acid_letter[i - 1][:residue_name], @final_pdb_res[i - 1][:residue_name], 
                                                         @final_pdb_res[i - 1][:chain], @amino_acid_letter[i - 1][:ss]]
            data_csv_label += " %s, %s,%s, %s,"%[@amino_acid_letter[i - 1][:residue_name], @final_pdb_res[i - 1][:residue_name], 
                                                 @final_pdb_res[i - 1][:chain], @amino_acid_letter[i - 1][:ss]]
          elsif j == (@@opts[:fragment][0] + 1) then ### Residue number
            data_txt_label += " %5s |"%@final_pdb_res[i - 1][:residue_num]
            data_csv_label += "%s,"%@final_pdb_res[i - 1][:residue_num]
          elsif j == (@@opts[:fragment][1] + 1) then
#            dat_line += "%i %i %f\n\n"%[i - 1, j - 2, energy[j - 2][i]] if ((j - 2) < (i - 1))
            data_txt_label += " %22s |\n"%energy[j - 2][i]
            data_csv_label += " %22s\n"%energy[j - 2][i]
          else
            if ((j - 2) < (i - 1))
              plot_energy[energy_count] = energy[j - 2][i]
              energy_count += 1
              dat_line += "%i %i %f\n"%[i - 1, j - 2, energy[j - 2][i]]
            end 
            dat_line += "\n" if ((j - 1) == (i - 1))
            data_txt_label += " %22s |"%energy[j - 2][i]
            data_csv_label += "%22s,"%energy[j - 2][i]
          end
        end
      end
      if (i == 0) then ### Write first line 
        Write_data.new.write_txt_data(data_txt_label, @@opts, 0, @@log)
        Write_data.new.write_csv_data(data_csv_label, @@opts, 0, @@log)
        Write_data.new.write_data(dat_line, @@opts, 0, @@log, @dat_file)
      else ### Write ohter line
        Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
        Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
        Write_data.new.write_data(dat_line, @@opts, 1, @@log, @dat_file)
      end
      ### Reset
      data_txt_label = ""
      data_csv_label = ""
      dat_line = ""
    end
    return plot_energy
  end

  def run(cmd_exist)
    work_dir = File.dirname(@@opts[:out]) ### Get the path of work dir
    get_fragment_num
    get_out_xyz
    get_amino_acid_data
    define_cyxss
    insert_his_cys
    define_pdb_residue_data
    get_distance_energy(@@pdb_all_data.size)

    if (@@opts[:interaction] == 1) then ### Selected-pairs mode (User's selected target vs All fragments)
      if (@cp_corr) then ### cp_corr == yes
        mode = [:hf_cpkcal, :dmp2_cpkcal, :mp2_cpkcal]
      else
        mode = [:hfkcal, :dmp2kcal, :mp2kcal]
      end
      cal_ave_data
      paics_selectedpairs_output

      if cmd_exist[:gnuplot] and @@opts[:gnuplot] then ### Plot
        Dir.chdir(work_dir) do
          @@log.info "\n", "****************", "", @@opts[:text]
          @@log.info "", "* Plot Process *"  , "", @@opts[:text]
          @@log.info "", "****************", "", @@opts[:text]
          plot = Plot.new(@@opts, @frag_data, @dat_file, @@log)
          plot.extract_paics_analysis_data(@ave_data, @final_pdb_res, @amino_acid_letter, mode[@@opts[:mode] - 1], @cp_corr)
          plot.make_one_d_plt("paics")
          plot.plot_gnuplot
          if (cmd_exist[:ps2pdf] or cmd_exist[:gs])  then
            plot.convert_ps2pdf
          else
            @@log.warn "\n", "Warning: Do not convert PS file into PDF file because the Ghostscript (gs) program is not installed on your system!", "\n", @@opts[:text]
          end
        end
      elsif !(cmd_exist[:gnuplot]) and @@opts[:gnuplot]
        @@log.error "\n", "Error: Gnuplot program is not installed on your system!", "\n", @@opts[:text]
      else
        @@log.info "\n", "Process: All process finished \"without plot process\"!", "\n", @@opts[:text]
      end
    elsif (@@opts[:interaction] == 2) then ### All fragment interaction (All fragments vs All fragments)
      energy = Array.new(@frag_data[:max]).map{Array.new(@frag_data[:max], 0.0)}
      if (@cp_corr) then ### cp_corr == yes
        mode = [:hf_cp, :hf_cpkcal, :dmp2_cp, :dmp2_cpkcal, :mp2_cp, :mp2_cpkcal]
      else
        mode = [:hf, :hfkcal, :dmp2, :dmp2kcal, :mp2, :mp2kcal]
      end
      @energy_data.each { |d|
        if (d[:distance] == 0.0000) then
          energy[d[:ifrag]][d[:jfrag]] = 0.0
        else
          energy[d[:ifrag]][d[:jfrag]] = d[mode[@@opts[:mode] - 1]]
        end
      }
      plot_energy = paics_all_output(energy)
      plot = Plot.new(@@opts, @frag_data, @dat_file, @@log)
      plot.make_two_d_plt(plot_energy)
      Dir.chdir(work_dir) do
        if cmd_exist[:gnuplot] then
          @@log.info "\n", "****************", "", @@opts[:text]
          @@log.info "", "* Plot Process *"  , "", @@opts[:text]
          @@log.info "", "****************", "", @@opts[:text]
          plot.plot_gnuplot
          if cmd_exist[:ps2pdf] then
            plot.convert_ps2pdf
          end
        end
      end
    end
    
    if (@@xml_flag) then
      if @@opts[:xml] then
        @@log.info "\n", "Process: Output XML from Analysis PAICS out data", "", @@opts[:text]
        xml = XML.new(@@opts, @@log)
        xml.xml_paics(@frag_data, @cp_corr, @out_data, @amino_acid_letter, @final_pdb_res, @energy_data, 
                      @ave_data, @mulliken_charge, @cmp2_data, @energy_cal, @binding_affinity)
      end
    end
  end

end


#**************************************************************************#
#***    Class for analysis of GAMESS Out file (*.out or *.log, ...)     ***#
#**************************************************************************#
class GAMESS < Analysis
  def initialize(frag_data = {}, gamess_header = {}, total_energy = {}, frag_statistics = [], one_body_fmo = [],
                 two_body_fmo = [], three_body_fmo = [], fmo_property = [], ct = [], mulliken_charge = [],
                 ave_data = [], sum_total_e = 0.0, dat_file = "")
    super(@@opts, @@flags, @@log, @@pdb_all_data, @@cys_pdb_data, @@cb_pdb_data, @@h_pdb_data, @@his_pdb_name, @@xml_flag)
    @frag_data = frag_data
    @gamess_header = gamess_header
    @total_energy = total_energy
    @frag_statistics = frag_statistics ### Fragment statistics
    @one_body_fmo = one_body_fmo
    @two_body_fmo = two_body_fmo
    @three_body_fmo = three_body_fmo
    @fmo_property = fmo_property       ### Frontier molecular orbital (FMO!) properties based on Koopmans' theorem
    @ct = ct                           ### Charge trasfer
    @mulliken_charge = mulliken_charge ### N-body Mulliken atomic charges: Q(N)
    @ave_data = ave_data
    @sum_total_e = sum_total_e         ### Sum of E(total) [kcal/mol]
    @dat_file = dat_file
  end

  #*** Get the data of SCC (self consistent charge) calculation on GAMESS-FMO ***#
  def get_gamess_scc
    scc_file = "scc_data.csv"
#    scc_data = []
    results = File.readlines(@@opts[:out]).grep(/DD=/)
    frag_num = results.grep(/Iter=  1/).size
    for i in 1..frag_num
      pattern = "iFrag=%5s"%i
      scc = results.grep(/#{pattern}/)
#      scc_data[i-1] = scc.dup
      header_line = "%s,%s,%s,%s,%s\n"%["Iteration", "ifragment (fragment (monomer) number)", 
                                        "EFMO (monomer energy) /hartree", "DD (difference of density matrix)", 
                                        "DE (difference of monomer energy = EFMO_{n} - EFMO_{n-1})"]
      if (i == 1) then
        Write_data.new.write_data(header_line, @@opts, 0, @@log, scc_file)
      else
        Write_data.new.write_data(header_line, @@opts, 1, @@log, scc_file)
      end
      for j in 0..(scc.size - 1)
=begin
        if (i == 1) and (j == 0) then ### For first time
          header_line = "%s,%s,%s,%s,%s\n"%["Iteration", "ifragment (fragment (monomer) number)", 
                                          "EFMO (monomer energy) /hartree", "DD (difference of density matrix)", 
                                          "DE (difference of monomer energy = EFMO_{n} - EFMO_{n-1})"]
          Write_data.new.write_data(header_line, @@opts, 0, @@log, scc_file)
        end
=end
        data = scc[j].tr(",", "").gsub("DE=", "DE= ").strip.split(/\s* \s*/)
        csv_line = "%s,%s,%s,%s,%s\n"%[data[1], data[3], data[5], data[7], data[9].tr("\r\n|\r|\n", "")]
        Write_data.new.write_data(csv_line, @@opts, 1, @@log, scc_file)
      end
    end
  end

  #*** Acquire data for residues and energies, and so on, ... from GAMESS Out file ***#
  def acquire_gamess_data
    i = 0
    data_flag = ""
    particle_frag = false
    first_frag = true
    line_count = 0
    res_count = 0 
    fmo2_charge = false ### True: make new pdb file replacing b-factor with FMO2 mulliken charge (Q(2))
    sum_q1 = 0.0
    sum_q2 = 0.0
    sum_q3 = 0.0

    work_dir = File.dirname(@@opts[:out])
    distance_zero_filename = "dist_AA_zero.txt"
    distance_zero_path = File.join(work_dir, distance_zero_filename)
    begin 
      dist_file = open(distance_zero_path, "w")
    rescue SystemCallError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
    rescue IOError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
    end
    dist_file.write("\n Two-body FMO properties.\n")
    dist_file.write(" ========================\n\n")
    dist_file.write(" DL: D=C dynamically correlated (MP2,CI), D=N not dynamically correlated\n")
    dist_file.write(" (RHF,DFT). D=S separated dimer: semiclassical interaction (ES), D=M MCSCF.\n")
    dist_file.write(" L stands for layer, Z is the monomer charge product, R is the interfragment\n")
    dist_file.write(" distance relative to van-der-Waals radii (-1.00 is printed if distances are\n")
    dist_file.write(" not computed). dDIJ*VIJ is the explicit embedded charge transfer energy.\n")
    dist_file.write(" Q(I->J) is the charge transfer amount, printed as zero if not available.\n")
    dist_file.write(" Positive values correspond to I in IJ having extra negative charge.\n")
    dist_file.write(" total = (EIJ-EI-EJ)+dDIJ*VIJ = Ees+Eex+Ect+mix+Edisp+Gsol (all are in kcal/mol).\n\n")
    dist_file.write("    I    J DL  Z    R   Q(I->J)  EIJ-EI-EJ dDIJ*VIJ    total     Ees      Eex    Ect+mix    Edisp    Gsol\n")
    dist_file.write(" ---------------------------------------------------------------------------------------------------------\n")

    pdb_res_num = [] ### Array of residue number in PDB file
    @@pdb_all_data.each{ |d|
      pdb_res_num << d[:residue_num]
    }
    pdb_res_num.uniq! ### Returns a new array by removing duplicate values in self

    @frag_data = {
      max: 0,       ### Number of fragments (Max)
      particle: 1,  ### Number of particle fragments (ligands)
      frag_num: [], ### Particle fragment numbers (ligands)
    }
    @gamess_header = {
      version: 0.0,         ### GAMESS version
      charge: 0,            ### Total charge
      spin: 0,              ### Total spin multiplicity
      n_body_fmo: 2,        ### N-body expansion of FMO method
      n_body_fmo_label: "", ### Label for N-body expansion of FMO method
      fmo_method: "",       ### FMO method
      num_of_atoms: 0,      ### Number of atoms 
#      modmol: 0,            ### MODMOL option at http://myweb.liu.edu/~nmatsuna/gamess/input/FMO.html
    }
    @total_energy = {
      correlated_energy1: 0.0,   ### Ecorr(1): Total correlated energy of monomer (FMO1-MP2)
                                 ###   E^{FMO1-MP2} = Sigma_{I} E^{''}_{I} [hartree]
      uncorrelated_energy1: 0.0, ### Euncorr(1): Total uncorrelated energy of monomer (FMO1-RHF)
                                 ###   Eun^{FMO1-RHF} = Sigma_{I} Eun^{''}_{I} [hartree]
      energy_delta1: 0.0,        ### Edelta(1): [hartree]
      dipole_moment_x1: 0.0,     ### D(x) of FMO1 = dx [Debye]
      dipole_moment_y1: 0.0,     ### D(y) of FMO1 = dy [Debye]
      dipole_moment_z1: 0.0,     ### D(z) of FMO1 = dz [Debye]
      norm_da1: 0.0,             ### DA1: Norm of FMO1 as d_total = (dx**2 + dy**2 + dz**2)**0.5
                                 ###   D^{FMO1-RHF} [Debye]
      correlated_energy2: 0.0,   ### Ecorr(2): Total correlated energy of dimer (FMO2-MP2)
                                 ### E^{FMO2-MP2} [hartree]
      uncorrelated_energy2: 0.0, ### Euncorr(2): Total uncorrelated energy of dimer (FMO2-RHF)
                                 ### Eun^{FMO2-RHF} [hartree]
      energy_delta2: 0.0,        ### Edelta(2): [hartree]
      dipole_moment_x2: 0.0,     ### D(x) of FMO2 = dx [Debye]
      dipole_moment_y2: 0.0,     ### D(y) of FMO2 = dy [Debye]
      dipole_moment_z2: 0.0,     ### D(z) of FMO2 = dz [Debye]
      norm_da2: 0.0,             ### DA2: Norm of FMO2 as d_total = (dx**2 + dy**2 + dz**2)**0.5
                                 ###   D^{FMO2-RHF} [Debye]
      correlated_energy3: 0.0,   ### Ecorr(3): Total correlated energy of dimer (FMO3-MP2)
                                 ### E^{FMO3-MP2} = [hartree]
      uncorrelated_energy3: 0.0, ### Euncorr(2): Total uncorrelated energy of dimer (FMO3-RHF)
                                 ### Eun^{FMO3-RHF} = [hartree]
      energy_delta3: 0.0,        ### Edelta(3): [hartree]
      dipole_moment_x3: 0.0,     ### D(x) of FMO3 = dx [Debye]
      dipole_moment_y3: 0.0,     ### D(y) of FMO3 = dy [Debye]
      dipole_moment_z3: 0.0,     ### D(z) of FMO3 = dz [Debye]
      norm_da3: 0.0,             ### DA3: Norm of FMO3 as d_total = (dx**2 + dy**2 + dz**2)**0.5
                                 ###   D^{FMO3-RHF} [Debye]
      corrected_ebb: 0.0,        ### The backbone energy EBB (corrected): EBBcorr(2) [hartree]
      uncorrected_ebb: 0.0,      ### The backbone energy EBB (uncorrected): EBBuncorr(2) [hartree]
      e_int: 0.0,                ### Total interaction (PL state): 
                                 ###   Eint = Sigma_{I>J} Delta_E^{int}_{IJ} = EES + EEX + E(CT+mix) + EDI [kcal/mol]
      e_es: 0.0,                 ### Electrostatic (PL state, incl. EPLs): 
                                 ###   EES = Sigma_{I>J} Delta_E^{ES}_{IJ} [kcal/mol]
      e_ex: 0.0,                 ### Exchange (PL state): 
                                 ###   EEX = Sigma_{I>J} Delta_E^{EX}_{IJ} [kcal/mol]
      e_ct_mix: 0.0,             ### Charge transfer (PL state): 
                                 ###   E(CT+mix) = Sigma_{I>J} Delta_E^{CT+mix}_{IJ} [kcal/mol]
      e_di: 0.0,                 ### Dispersion (PL state): 
                                 ###   EDI = Sigma_{I>J} Delta_E^{DI}_{IJ} [kcal/mol]
      e_dash_int: 0.0,           ### Total unconnected interaction (PL state):
                                 ###   E'int = E'ES + E'EX + E'(CT+mix) + E'DI [kcal/mol]
      e_dash_es: 0.0,            ### Unconnected electrostatic (PL state, incl. EPLs): E'ES [kcal/mol]
      e_dash_ex: 0.0,            ### Unconnected exchange (PL state): E'EX [kcal/mol]
      e_dash_ct_mix: 0.0,        ### Unconnected charge transfer (PL state): E'(CT+mix) [kcal/mol]
      e_dash_di: 0.0,            ### Unconnected dispersion (PL state): E'DI [kcal/mol]
      e_int_bda: 0.0,            ### Total interaction (BDA: Bond-Detached Atom): EintBDA [kcal/mol]
      e_es_bda: 0.0,             ### Electrostatic (BDA): EESBDA [kcal/mol]
      e_ex_bda: 0.0,             ### Exchange (BDA): EEXBDA [kcal/mol]
      e_ct_mix_bda: 0.0,         ### Charge transfer (BDA): E(CT+mix)BDA [kcal/mol]
      e_di_bda: 0.0,             ### Dispersion (BDA): EDIBDA [kcal/mol]
    }

    if @@opts[:interaction] == 1 then
      Write_data.new.write_txt_data("<File Name Path>\n", @@opts, 0, @@log)
      Write_data.new.write_txt_data(@@opts[:out], @@opts, 1, @@log)
      Write_data.new.write_txt_data("\n\n", @@opts, 1, @@log)
      Write_data.new.write_csv_data("\n\n,File Name Path,", @@opts, 0, @@log)
      Write_data.new.write_csv_data(@@opts[:out], @@opts, 1, @@log)
      Write_data.new.write_csv_data("\n\n", @@opts, 1, @@log)
    end

    @@log.info "\n", "Process: Acquire data for residue and energies from GAMESS Out file", "", @@opts[:text]

    begin
      data_file = open(@@opts[:out], "r")
    rescue SystemCallError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
    rescue IOError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
    end

    lines = data_file.readlines ### Read line from opened file
    while line_count < lines.size do ### If not EOF
      line_data = lines[line_count].split(/\s* \s*/)
      ### For the selected pair mode
      ### not including "!": no comment out
      if line_data[1] == "INPUT" and line_data[2] == "CARD>" then
        if (line_data.size - 1 > 3) then
          if line_data[3].include?("MODMOL") then
             ################################################################################################### 
             ################################################################################################### 
             ################################################################################################### 
             ################################################################################################### 
             ################################################################################################### 
             ################################################################################################### 
             ### 
             ### What does "MODMOL" mean?, Num of particle frag?
             ### 
             ################################################################################################### 
             ################################################################################################### 
             ################################################################################################### 
             ################################################################################################### 
             ################################################################################################### 
             ################################################################################################### 
          elsif line_data[3].include?("MOLFRG") then
            num = line_data[3].tr("\r\n|\r|\n", "").split("(")[1].split(")")[0].to_i
            @frag_data[:frag_num][num - 1] = line_data[3].tr("\r\n|\r|\n", "").split(/\s*=\s*/)[1].to_i
            particle_frag = true
          end
        end
      elsif line_data[1] == "Version" then
        @gamess_header[:version] = ("%.1f"%line_data[2].tr("\r\n|\r|\n", "")).to_f
      elsif line_data[1] == "Number" and line_data[2] == "of" and line_data[3] == "fragments:" then ### Number of fragments
        @frag_data[:max] = line_data[4].tr("\r\n|\r|\n", "").to_i
        @frag_data[:frag_num][0] = @frag_data[:max] if !(particle_frag)
        @@opts[:fragment][1] = @frag_data[:max] if (@@opts[:fragment][1] == 0) ### Using -j all
        ### E_tot = (EIJ-EI-EJ) + dDIJ*VIJ
        eij_ei_ej = Array.new(@frag_data[:max]).map{Array.new(@frag_data[:max], 0.0)}
        dij_vij = Array.new(@frag_data[:max]).map{Array.new(@frag_data[:max], 0.0)}

        if !(particle_frag) then
            ################################################################################################### 
            ################################################################################################### 
            ################################################################################################### 
            ################################################################################################### 
            ################################################################################################### 
            ################################################################################################### 
            ###
            ### For GAMESS-FMO, partcile == 1 only ?
            ###
            ################################################################################################### 
            ################################################################################################### 
            ################################################################################################### 
            ################################################################################################### 
            ################################################################################################### 
            ################################################################################################### 
          @frag_data[:particle] = 1
        else
          @frag_data[:particle] = @frag_data[:frag_num].size
        end
        @@log.info "\n", "  Number of fragments = #{@frag_data[:max]}", "", @@opts[:text]
        @@log.info "", "  Number of particle fragments (ligands):  #{@frag_data[:particle]}", "", @@opts[:text]

        if @@opts[:interaction] == 1 then
          Write_data.new.write_txt_data("<Number of fragment>\n", @@opts, 1, @@log)
          Write_data.new.write_txt_data("Number of fragments = #{@frag_data[:max]}\n", @@opts, 1, @log)
          Write_data.new.write_csv_data(",Number of fragments,#{@frag_data[:max]}\n\n", @@opts, 1, @@log)
          Write_data.new.write_txt_data("\n<Target fragments>\n", @@opts, 1, @@log)
          Write_data.new.write_csv_data(",Target fragments,", @@opts, 1, @@log)

          ligand_label = "  Ligand number:  "
          for i in 1..@frag_data[:particle]
            if i == @frag_data[:particle] then ### Last fragment including "new line"
#              @frag_data[:frag_num][i - 1] = line_data[i].tr("\r\n|\r|\n", "").to_i ### Particle fragment (ligand) numbers
              ligand_label += "#{@frag_data[:frag_num][i - 1]}\n\n"
              if @@opts[:interaction] == 1 then
                Write_data.new.write_txt_data(@frag_data[:frag_num][i - 1].to_s + "\n", @@opts, 1, @@log)
                Write_data.new.write_csv_data(@frag_data[:frag_num][i - 1].to_s + "\n\n", @@opts, 1, @@log)
              end
            else
#              @frag_data[:frag_num][i - 1] = line_data[i].to_i ### Particle fragment (ligand) numbers
              ligand_label += "#{@frag_data[:frag_num][i - 1]}, "
              if @@opts[:interaction] == 1 then
                Write_data.new.write_txt_data(@frag_data[:frag_num][i - 1].to_s + ", ", @@opts, 1, @@log)
                Write_data.new.write_csv_data(@frag_data[:frag_num][i - 1].to_s + ",", @@opts, 1, @@log)
              end
            end
          end
        @@log.info "", "#{ligand_label.tr("\r\n|\r|\n", "")}", "\n\n", @@opts[:text]
        end
        @@log.info "", "", "", @@opts[:text]
      elsif line_data[1] == "Number" and line_data[2] == "of" and line_data[3] == "atoms:" then ### Number of atoms
        @gamess_header[:num_of_atoms] = line_data[4].tr("\r\n|\r|\n", "").to_i 
      elsif line_data[1] == "Total" and line_data[2] == "charge:" then ### Charge
        @gamess_header[:charge] = line_data[3].tr("\r\n|\r|\n", "").to_i
      elsif line_data[1] == "Total" and line_data[2] == "spin" and line_data[3] == "multiplicity:" then ### Spin multiplicity
        @gamess_header[:spin] = line_data[3].tr("\r\n|\r|\n", "").to_i
      elsif line_data[1] == "N-body" and line_data[2] == "FMO" and line_data[3] == "method:" then ### N-body FMO expansion
        @gamess_header[:n_body_fmo] = line_data[4].tr("\r\n|\r|\n", "").to_i
        if (@gamess_header[:n_body_fmo] == 0) then
          @gamess_header[:n_body_fmo_label] = "Only initial monomer guess"
        elsif (@gamess_header[:n_body_fmo] == 1) then
          @gamess_header[:n_body_fmo_label] = "One-body FMO expansion (FMO1, monomer SCF)"
        elsif (@gamess_header[:n_body_fmo] == 2) then ### Default
          @gamess_header[:n_body_fmo_label] = "Two-body FMO expansion (FMO2, dimers)"
        elsif (@gamess_header[:n_body_fmo] == 3) then
          @gamess_header[:n_body_fmo_label] = "Three-body FMO expansion (FMO3, trimers)"
        else
          @gamess_header[:n_body_fmo_label] = ""
        end
      elsif line_data[1] == "FMO" and line_data[2] == "method:" then ### FMO method
        @gamess_header[:fmo_method] = line_data[3].tr("\r\n|\r|\n", "")
      elsif line_data[1] == "I" and line_data[2] == "NAME" and line_data[3] == "Q" and line_data[4] == "NAT0" then ### Fragment statistics
        skip = 1
        line_count += skip
        data_flag = "fragment statistics"
      elsif line_data[1] == "One-body" and line_data[2] == "FMO" and line_data[3].tr("\r\n|\r|\n", "") == "properties." then
        ### One-body FMO properties
        skip = 3
        line_count += skip
        data_flag = "residue"
      elsif line_data[1] == "EA" and line_data[2] == "and" and line_data[3] == "related" then
        skip = 1
        line_count += skip
        data_flag = "EA"
      elsif line_data[1] == "Charge" and line_data[2] == "instability" and line_data[3] == "detected:" then
        data_flag = ""
      elsif line_data[1] == "Total" and line_data[2] == "energy" and line_data[3] == "of" and line_data[4] == "the" then
        if line_data[6] == "Ecorr" then ### Ecorr
          if line_data[7] == "(1)=" then
            @total_energy[:correlated_energy1] = ("%.9f"%line_data[8].tr("\r\n|\r|\n", "")).to_f
          elsif line_data[7] == "(2)=" then
            @total_energy[:correlated_energy2] = ("%.9f"%line_data[8].tr("\r\n|\r|\n", "")).to_f
          elsif line_data[7] == "(3)=" then
            @total_energy[:correlated_energy3] = ("%.9f"%line_data[8].tr("\r\n|\r|\n", "")).to_f
          end
        elsif line_data[6] == "Edelta" then ### Edelta
          if line_data[7] == "(1)=" then
            @total_energy[:energy_delta1] = ("%.9f"%line_data[8].tr("\r\n|\r|\n", "")).to_f
          elsif line_data[7] == "(2)=" then
            @total_energy[:energy_delta2] = ("%.9f"%line_data[8].tr("\r\n|\r|\n", "")).to_f
          elsif line_data[7] == "(3)=" then
            @total_energy[:energy_delta3] = ("%.9f"%line_data[8].tr("\r\n|\r|\n", "")).to_f
          end
        else ### Euncorr
          if line_data[6][7..9] == "(1)" then
            @total_energy[:uncorrelated_energy1] = ("%.9f"%line_data[7].tr("\r\n|\r|\n", "")).to_f
          elsif line_data[6][7..9] == "(2)" then
            @total_energy[:uncorrelated_energy2] = ("%.9f"%line_data[7].tr("\r\n|\r|\n", "")).to_f
          elsif line_data[6][7..9] == "(3)" then
            @total_energy[:uncorrelated_energy3] = ("%.9f"%line_data[7].tr("\r\n|\r|\n", "")).to_f
          end
        end
      elsif line_data[1] == "The" and  line_data[2] == "backbone" and  line_data[3] == "energy" then
        if line_data[4] == "EBBcorr" then ### The backbone energy EBBcorr(2)
          @total_energy[:corrected_ebb] = ("%.9f"%line_data[6].tr("\r\n|\r|\n", "")).to_f
        else ### The backbone energy EBBuncorr(2)
          ### Sum of PIE between internal energy of monomar on molecule and internal energy of covalently bonded dimer
          ### Therefore, total unconnected (non-binded) energy: difference between this above energy and total energy
          @total_energy[:uncorrected_ebb] = ("%.9f"%line_data[5].tr("\r\n|\r|\n", "")).to_f
        end
      ##########################################################################
      #  Interaction energy relative to PL state:                              #
      #    Eint = EES + EEX + E(CT+mix) + EDI                                  #
      #    Eint = E(FMO2) - E(FMO1) - E(BDA)                                   #
      #    Eint - interaction relative to PL state using PL state densities.   #
      #                                                                        #
      #  Unconnected interaction energy relative to PL state:                  #
      #    E'int = E'ES + E'EX + E'(CT+mix) + E'DI                             #
      #    E'int = E'(FMO2) - E'(FMO1)                                         #
      #    E'int - interaction relative to PL state using PL state densities,  #
      #  excluding contributions from dimers between which                     #
      #  a covalent bond is fractioned.                                        #
      #                                                                        #
      #  BDA(Bond-Detached Atom) energies                                      #
      ##########################################################################
      elsif line_data[1] == "Electrostatic" then
        if line_data[6] == "EES"then ### Electrostatic (PL state, incl. EPLs): EES
          @total_energy[:e_es] = ("%.3f"%line_data[7].tr("\r\n|\r|\n", "")).to_f
        elsif line_data[6] == "E'ES"then ### Electrostatic (PL state, incl. EPLs): E'ES
          @total_energy[:e_dash_es] = ("%.3f"%line_data[7].tr("\r\n|\r|\n", "")).to_f
        elsif line_data[2] == "(BDA)" and line_data[3] == "EESBDA" then ### Electrostatic (BDA): EESBDA 
          @total_energy[:e_es_bda] = ("%.3f"%line_data[4].tr("\r\n|\r|\n", "")).to_f
        end
      elsif line_data[1] == "Exchange" then
        if line_data[4] == "EEX"then ### Exchange (PL state): EEX
          @total_energy[:e_ex] = ("%.3f"%line_data[5].tr("\r\n|\r|\n", "")).to_f
        elsif line_data[4] == "E'EX"then ### Exchange (PL state): E'EX
          @total_energy[:e_dash_ex] = ("%.3f"%line_data[5].tr("\r\n|\r|\n", "")).to_f
        elsif line_data[2] == "(BDA)" and line_data[3] == "EEXBDA" then ### Exchange (BDA): EEXBDA 
          @total_energy[:e_ex_bda] = ("%.3f"%line_data[4].tr("\r\n|\r|\n", "")).to_f
        end
      elsif line_data[1] == "Charge" and line_data[2] == "transfer" then
        if line_data[5] == "E(CT+mix)"then ### Charge transfer (PL state): E(CT+mix)
          @total_energy[:e_ct_mix] = ("%.3f"%line_data[6].tr("\r\n|\r|\n", "")).to_f
        elsif line_data[5] == "E'(CT+mix)"then ### Charge transfer (PL state): E'(CT+mix)
          @total_energy[:e_dash_ct_mix] = ("%.3f"%line_data[6].tr("\r\n|\r|\n", "")).to_f
        elsif line_data[3] == "(BDA)" and line_data[4] == "E(CT+mix)BDA" then ### Charge transfer (BDA): E(CT+mix)BDA
          @total_energy[:e_ct_mix_bda] = ("%.3f"%line_data[5].tr("\r\n|\r|\n", "")).to_f
        end
      elsif line_data[1] == "Dispersion" then
        if line_data[4] == "EDI"then ### Dispersion (PL state): EDI
          @total_energy[:e_di] = ("%.3f"%line_data[5].tr("\r\n|\r|\n", "")).to_f
        elsif line_data[4] == "E'DI"then ### Dispersion (PL state): E'DI
          @total_energy[:e_dash_di] = ("%.3f"%line_data[5].tr("\r\n|\r|\n", "")).to_f
        elsif line_data[2] == "(BDA)" and line_data[3] == "EDIBDA" then ### Dispersion (BDA): EDIBDA
          @total_energy[:e_di_bda] = ("%.3f"%line_data[4].tr("\r\n|\r|\n", "")).to_f
        end
      elsif line_data[1] == "Total" and line_data[2] == "interaction" then
        if line_data[5] == "Eint"then ### Total interaction (PL state): Eint
          @total_energy[:e_int] = ("%.3f"%line_data[6].tr("\r\n|\r|\n", "")).to_f
        elsif line_data[5] == "E'int"then ### Total interaction (PL state): E'int
          @total_energy[:e_dash_int] = ("%.3f"%line_data[6].tr("\r\n|\r|\n", "")).to_f
        elsif line_data[3] == "(BDA)" and line_data[4] == "EintBDA" then ### Total interaction (BDA): EintBDA
          @total_energy[:e_int_bda] = ("%.3f"%line_data[5].tr("\r\n|\r|\n", "")).to_f
        end
      elsif line_data[1] == "Dipole" and  line_data[2] == "moment" then
        if line_data[3].split(/\s*,\s*/)[0] == "D(xyz)" and line_data[3].split(/\s*,\s*/)[1] == "DA(1)="
          @total_energy[:dipole_moment_x1] = ("%.7f"%line_data[4]).to_f
          @total_energy[:dipole_moment_y1] = ("%.7f"%line_data[5]).to_f
          @total_energy[:dipole_moment_z1] = ("%.7f"%line_data[6]).to_f
          @total_energy[:norm_da1] = ("%.7f"%line_data[7].tr("\r\n|\r|\n", "")).to_f
        elsif line_data[3].split(/\s*,\s*/)[0] == "D(xyz)" and line_data[3].split(/\s*,\s*/)[1] == "DA(2)="
          @total_energy[:dipole_moment_x2] = ("%.7f"%line_data[4]).to_f
          @total_energy[:dipole_moment_y2] = ("%.7f"%line_data[5]).to_f
          @total_energy[:dipole_moment_z2] = ("%.7f"%line_data[6]).to_f
          @total_energy[:norm_da2] = ("%.7f"%line_data[7].tr("\r\n|\r|\n", "")).to_f
        elsif line_data[3].split(/\s*,\s*/)[0] == "D(xyz)" and line_data[3].split(/\s*,\s*/)[1] == "DA(3)="
          @total_energy[:dipole_moment_x3] = ("%.7f"%line_data[4]).to_f
          @total_energy[:dipole_moment_y3] = ("%.7f"%line_data[5]).to_f
          @total_energy[:dipole_moment_z3] = ("%.7f"%line_data[6]).to_f
          @total_energy[:norm_da3] = ("%.7f"%line_data[7].tr("\r\n|\r|\n", "")).to_f
        end
      elsif line_data[1] == "I" and line_data[2] == "J" and line_data[3] == "DL" and line_data[4] == "Z" then
        ### Two-body FMO properties
        skip = 1
        line_count += skip
        data_flag = "energy"
      elsif line_data[1] == "I" and line_data[2] == "J" and line_data[3] == "K" and line_data[4] == "DL" then
        ### Three-body FMO properties
        skip = 1
        line_count += skip
        data_flag = "three-body"
      elsif line_data[1] == "IFG" and line_data[2] == "QFG" and line_data[3] == "DeltaQ" and line_data[4] == "and" then
        ### Charge transfer for each fragment
        skip = 1
        line_count += skip
        data_flag = "charge transfer"
      elsif line_data[1] == "IAT" and line_data[2] == "IFG" and line_data[3] == "Z" and line_data[4] == "Q(1)" then
        ### N-body Mulliken  atomic charges: Q(N)
        data_flag = "mulliken"
      elsif data_flag == "fragment statistics" ### Fragment statistics
        if lines[line_count].tr("\r\n|\r|\n", "") == "" then
          @@log.info "", "Process: Get data for fragment statistics from GAMESS Out file", "", @@opts[:text]
          data_flag = ""
        else
          data = {
            ifrag: 0,                   ### i-th fragment number
            residue_name: "",           ### Residue name
            residue_num: 0,             ### Residue number 
                                        ###  * But, this number is always starting from "1" on GAMESS-FMO !!
                                        ###    Therefore, this number is not equal to "residue sequence number in PDB file"!!
            q: 0,                       ### Q: charge???????? (value: 0, -1, 1)
            num_of_atoms: 0,            ### Number of atoms in ith-fragment
            final_pdb_residue_name: "", ### Final PDB residue name 
            final_pdb_residue_num: "",  ### Final PDB residue number
            chain: "",                  ### Chain
          }
          if first_frag then
            first_frag = false
            while (lines[line_count][0..(5 + i)].strip.to_i == 0) do
              i += 1
            end
          end

          data[:ifrag] = lines[line_count][0..(5 + i)].strip.to_i
          if lines[line_count][(7 + i)..(15 + i)].include?("-") then
            data[:residue_name] = lines[line_count][(7 + i)..(9 + i)]
            data[:residue_num] = lines[line_count][(11 + i)..(15 + i)].strip.to_i
          else ### residue_name == "FRAG*"
            data[:residue_name] = lines[line_count][(7 + i)..(15 + i)].strip
            data[:residue_num] = 0
          end
          data[:q] = lines[line_count][(16 + i)..(17 + i)].strip.to_i
          data[:num_of_atoms] = lines[line_count][(18 + i)..(22 + i)].strip.to_i

          case check_num_of_atoms(data)
          when 0 then ### fragment including "1 amino acid" only
=begin
            data[:final_pdb_residue_name] = @@pdb_all_data.select{|i| i[:residue_num] == pdb_res_num[res_count]}[0][:residue_name]
            data[:final_pdb_residue_num] = @@pdb_all_data.select{|i| i[:residue_num] == pdb_res_num[res_count]}[0][:residue_num].to_s
            data[:chain] = @@pdb_all_data.select{|i| i[:residue_num] == pdb_res_num[res_count]}[0][:chain]
=end
            data[:final_pdb_residue_name] = @@pdb_all_data.select{|i| i[:residue_num] == data[:residue_num]}[0][:residue_name]
            data[:final_pdb_residue_num] = @@pdb_all_data.select{|i| i[:residue_num] == data[:residue_num]}[0][:residue_num].to_s
            data[:chain] = @@pdb_all_data.select{|i| i[:residue_num] == data[:residue_num]}[0][:chain]
            res_count += 1
          when 1 then ### fragment including amino acids more than 1!!
=begin
            data[:final_pdb_residue_name] = @@pdb_all_data.select{|i| i[:residue_num] == pdb_res_num[res_count]}[0][:residue_name]}
            data[:final_pdb_residue_num] = @@pdb_all_data.select{|i| i[:residue_num] == pdb_res_num[res_count]}[0][:residue_num]}
#            data[:final_pdb_residue_name] += "#{@@pdb_all_data.select{|i| i[:residue_num] == (pdb_res_num[res_count] + 1)}[0][:residue_name]}" 
#            data[:final_pdb_residue_num] += "#{@@pdb_all_data.select{|i| i[:residue_num] == (pdb_res_num[res_count] + 1)}[0][:residue_num]}"
            data[:chain] = @@pdb_all_data.select{|i| i[:residue_num] == pdb_res_num[res_count]}[0][:chain]
=end
            data[:final_pdb_residue_name] = @@pdb_all_data.select{|i| i[:residue_num] == data[:residue_num]}[0][:residue_name]
            data[:final_pdb_residue_num] = @@pdb_all_data.select{|i| i[:residue_num] == data[:residue_num]}[0][:residue_num].to_s
            data[:chain] = @@pdb_all_data.select{|i| i[:residue_num] == data[:residue_num]}[0][:chain]
            res_count += 2
          when 2 then ### Unknown fragment name
            data[:final_pdb_residue_name] = @@pdb_all_data.select{|i| i[:residue_num] == pdb_res_num[res_count]}[0][:residue_name]
            data[:final_pdb_residue_num] = @@pdb_all_data.select{|i| i[:residue_num] == pdb_res_num[res_count]}[0][:residue_num].to_s
            data[:chain] = @@pdb_all_data.select{|i| i[:residue_num] == pdb_res_num[res_count]}[0][:chain]
            res_count += 1
          end
          @frag_statistics << data
        end
      elsif data_flag == "residue" then ### One-body FMO properties
        if lines[line_count].tr("\r\n|\r|\n", "") == "" then
          @@log.info "", "Process: Get data for One-body FMO properties from GAMESS Out file", "", @@opts[:text]
          data_flag = ""
        else
          data = {
            ifrag: 0,                 ### ith-fragment number
            residue_name: "",         ### Residue name (Three letter code)
            residue_num: 0,           ### Residue sequence number
            correlated_energy: 0.0,   ### E"corr (E^{''}_{I}): Correlated energy of monomer (FMO1) [Hartree]
            uncorrelated_energy: 0.0, ### E"uncorr (Eun^{''}_{I}): Uncorrelated energy of monomer (FMO1) [Hartree]
            dipole_moment_x: 0.0,     ### DX: Dipole moment of x component for monomar (FMO1) [Debye]
            dipole_moment_y: 0.0,     ### DY: Dipole moment of y component for monomar (FMO1) [Debye]
            dipole_moment_z: 0.0,     ### DZ: Dipole moment of z component for monomar (FMO1) [Debye]
          }
          data[:ifrag] = lines[line_count][0..4].strip.to_i
          tmp_data = lines[line_count][6..16].split(",")
          if tmp_data[0].split("-").size == 1 then ### "FRAG*"
            data[:residue_name] = tmp_data[0]
            data[:residue_num] = 0  ### Unknown
          else
            data[:residue_name] = tmp_data[0].split("-")[0]
            data[:residue_num] = tmp_data[0].split("-")[1].to_i
          end
          data[:correlated_energy] = ("%.9f"%lines[line_count][18..34].strip).to_f
          data[:uncorrelated_energy] = ("%.9f"%lines[line_count][35..51].strip).to_f
          data[:dipole_moment_x] = ("%.5f"%lines[line_count][52..61].strip).to_f
          data[:dipole_moment_y] = ("%.5f"%lines[line_count][62..71].strip).to_f
          data[:dipole_moment_z] = ("%.5f"%lines[line_count][72..81].strip).to_f
          @one_body_fmo << data
        end
      elsif data_flag == "EA" then
        if lines[line_count].to_s.tr("\r\n|\r|\n", "") == "" then
          data_flag = ""
        else
          data = {
            ifrag: 0,                    ### ith-fragment number
            ionization_potential: 0.0,   ### IP [eV]
            electron_affinity: 0.0,      ### EA [eV] 
            chemical_potential: 0.0,     ### Electronegativity = - chemical potential [eV]
            global_hardness: 0.0,        ### [eV]
            global_softness: 0.0,        ### [eV]
            electrophilicity_index: 0.0, ### [eV]
          }
          data[:ifrag] = lines[line_count][0..5].strip.to_i
          data[:ionization_potential] = ("%.6f"%lines[line_count][6..17].strip).to_f
          data[:electron_affinity] = ("%.6f"%lines[line_count][18..29].strip).to_f
          data[:chemical_potential] = ("%.6f"%lines[line_count][30..41].strip).to_f
          data[:global_hardness] = ("%.6f"%lines[line_count][42..53].strip).to_f
          data[:global_softness] = ("%.6f"%lines[line_count][54..65].strip).to_f
          data[:electrophilicity_index] = ("%.6f"%lines[line_count][66..79].strip).to_f
        end
        @fmo_property << data
      elsif data_flag == "energy" then ### Two-body FMO properties
        #######################################################################################
        # <Two-body FMO properties>                                                           #
        #   DL: D=C dynamically correlated (MP2,CI), D=N not dynamically correlated           #
        #   (RHF,DFT). D=S separated dimer: semiclassical interaction (ES), D=M MCSCF.        #
        #   L stands for layer, Z is the monomer charge product, R is the interfragment       #
        #   distance relative to van-der-Waals radii (-1.00 is printed if distances are       #
        #   not computed). dDIJ*VIJ is the explicit embedded charge transfer energy.          #
        #   Q(I->J) is the charge transfer amount, printed as zero if not available.          #
        #   Positive values correspond to I in IJ having extra negative charge.               #
        #    total = (EIJ-EI-EJ)+dDIJ*VIJ = Ees+Eex+Ect+mix+Edisp+Gsol (all are in kcal/mol). #
        #######################################################################################
        if lines[line_count].to_s.tr("\r\n|\r|\n", "") == "" then
          @@log.info "", "Process: Get data for TWO-body FMO properties from GAMESS Out file", "", @@opts[:text]
          data_flag = ""
        else
          data = {
            ifrag: 0,       ### ith-fragment of dimer between ith and jth: J => i
            jfrag: 0,       ### jth-fragment of dimer between ith and jth: I => j
            d: "",          ### D label in DL: Calculation method
                            ###  - D = C: Dynamically correlated method (MP2,CI)
                            ###  - D = N (No): Not dynamically correlated method (RHF,DFT) 
                            ###  - D = S: Separated dimer: semiclassical interaction (ES)
                            ###  - D = M: MCSCF method
            d_label: "",    ### Label (D) for calculation method
            l: 0,           ### L label in DL: Layer number of multi-layer
            z: 0,           ### Monomer charge product between ith- and jth-fragment (value: 0, -1, 1)
                            ###   (ex). ith-fragment (charge = 0) * jth-fragment (charge = 0) = 0
            r: 0.0,         ### Interfragment distance relative to van-der-Waals radii between ith- and jth-fragment [%]
                            ###   It show how many times distance from value which sum of van-der-Waals radii of each atom is 1
                            ###   -1.00 is printed if distances are not computed.
                            ###   Therefore, if covalent bond between fragments is lost, its distance is 0.0.
                            ###   (Ref.): "RESPAP" on http://myweb.liu.edu/~nmatsuna/gamess/input/FMO.html
                            ###     the distance is relative to van der Waals radii; 
                            ###     e.g. two atoms A and B separated by R are defined to have the distance equal to R/(RA+RB), 
                            ###     where RA and RB are van der Waals radii of A and B).
            q_i_j: 0.0,     ### Q(i->j): Charge transfer amount from ith- to jth-fragment, 
                            ###   printed as 0.0000 (Zero) if without Mulliken option
            eij_ei_ej: 0.0, ### E_{ij} - E_{i} - E_{j} [kcal/mol]: 
                            ###   - E_{ij}: Internal energy of dimer (ij)
                            ###   - E_{i}: Internal energy of monomer (i)
                            ###   - E_{j}: Internal energy of monomer (j)
            dij_vij: 0.0,   ### Tr(dD^{ij}*V^{ij}): Explicit embedded charge transfer energy [kcal/mol]
            e_total: 0.0,   ### PIE (pair interaction energy): 
                            ###   total = (EIJ-EI-EJ) + dDIJ*VIJ = Ees + Eex + Ect+mix + Edisp + Gsol [kcal/mol]
            e_es: 0.0,      ### Electrostatic energy [kcal/mol]
            e_ex: 0.0,      ### Exchange repulsion energy [kcal/mol]
            e_ct_mix: 0.0,  ### Energy for charge transfer + MIX [kcal/mol]
            e_disp: 0.0,    ### Dispersion energy [kcal/mol]
            g_sol: 0.0,     ### Solvation free energy [kcal/mol]
          }
          if (particle_frag) then
            if @frag_data[:frag_num][0] < lines[line_count][0..4].strip.to_i then
              data[:ifrag] = lines[line_count][0..4].strip.to_i
              data[:jfrag] = lines[line_count][5..9].strip.to_i
            else
              data[:ifrag] = lines[line_count][5..9].strip.to_i ### J => i
              data[:jfrag] = lines[line_count][0..4].strip.to_i ### I => j
            end
          else
            data[:ifrag] = lines[line_count][5..9].strip.to_i ### J => i
            data[:jfrag] = lines[line_count][0..4].strip.to_i ### I => j
          end
          data[:d] = lines[line_count][11]
          if data[:d] == "C" then
            data[:d_label] = "Dynamically correlated method (MP2,CI)"
          elsif data[:d] == "N" then
            data[:d_label] = "Not dynamically correlated method (RHF,DFT)"
          elsif data[:d] == "S" then
            data[:d_label] = "Separated dimer: semiclassical interaction (ES)"
          elsif data[:d] == "M" then
            data[:d_label] = "MCSCF method"
          else
            data[:d_label] = ""
          end
          data[:l] = lines[line_count][12].to_i
          data[:z] = lines[line_count][15].to_i
          data[:r] = ("%.2f"%lines[line_count][16..22].strip).to_f
          if (data[:r] == 0.00) then
            dist_file.write(lines[line_count])
          end
          data[:q_i_j] = ("%.4f"%lines[line_count][23..30].strip).to_f
          data[:eij_ei_ej] = ("%.3f"%lines[line_count][31..40].strip).to_f
          data[:dij_vij] = ("%.3f"%lines[line_count][41..49].strip).to_f
          data[:e_total] = ("%.3f"%lines[line_count][50..60].strip).to_f
          data[:e_es] = ("%.3f"%lines[line_count][61..70].strip).to_f
          data[:e_ex] = ("%.3f"%lines[line_count][71..79].strip).to_f
          data[:e_ct_mix] = ("%.3f"%lines[line_count][80..89].strip).to_f
          data[:e_disp] = ("%.3f"%lines[line_count][90..98].strip).to_f
          data[:g_sol] = ("%.3f"%lines[line_count][99..107].strip).to_f
=begin
          eij_ei_ej[data[:ifrag] - 1][data[:jfrag] - 1] = data[:eij_ei_ej]
          dij_vij[data[:ifrag] - 1][data[:jfrag] - 1] = data[:dij_vij]
          e_total[data[:ifrag] - 1][data[:jfrag] - 1] = data[:e_total]
          e_es[data[:ifrag] - 1][data[:jfrag] - 1] = data[:e_es]
          e_ex[data[:ifrag] - 1][data[:jfrag] - 1] = data[:e_ex]
          e_ct_mix[data[:ifrag] - 1][data[:jfrag] - 1] = data[:e_ct_mix]
          e_disp[data[:ifrag] - 1][data[:jfrag] - 1] = data[:e_disp]
          g_sol[data[:ifrag] - 1][data[:jfrag] - 1] = data[:g_sol]
=end
          @two_body_fmo << data
        end
      elsif data_flag == "charge transfer" then ### Charge transfer for each fragment
        if lines[line_count].to_s.tr("\r\n|\r|\n", "") == "" then
          @@log.info "", "Process: Get data for Charge transfer for each fragment from GAMESS Out file", "", @@opts[:text]
          data_flag = ""
        else
          data = {
            ifrag: 0,     ### ith-fragment number
            qfg: 0,       ### ???? (Value: 0, 1, -1)
            delta_q: 0.0, ### Contains the number of electrons lost by ith-fragment: 
                          ###   delta_q = Q(j1 -> i) + Q(j2 -> i) + ... + Q(jn -> i)
            jfrag1: 0,    ### (j1): jth-fragment number of Q(j1 -> i)
            q1: 0.0,      ### Number of electrons lost at j1 by ith-fragment
            jfrag2: 0,    ### (j2): jth-fragment number of Q(j2 -> i)
            q2: 0.0,      ### Number of electrons lost at j2 by ith-fragment
            jfrag3: 0,    ### (j3): jth-fragment number of Q(j3 -> i)
            q3: 0.0,      ### Number of electrons lost at j3 by ith-fragment
            jfrag4: 0,    ### (j4): jth-fragment number of Q(j4 -> i)
            q4: 0.0,      ### Number of electrons lost at j4 by ith-fragment
          }
          data[:ifrag] = lines[line_count][0..4].strip.to_i
          data[:qfg] = lines[line_count][5..7].strip.to_i
          data[:delta_q] = ("%.4f"%lines[line_count][8..16].strip).to_f
          data[:jfrag1] = lines[line_count][19..23].strip.to_i
          data[:q1] = ("%.4f"%lines[line_count][26..33].strip).to_f
          data[:jfrag2] = lines[line_count][34..38].strip.to_i
          data[:q2] = ("%.4f"%lines[line_count][41..48].strip).to_f
          if !(lines[line_count][56..63] == nil) and !(lines[line_count][49..53].to_s.tr("\r\n|\r|\n", "") == "") then
            data[:jfrag3] = lines[line_count][49..53].strip.to_i
            data[:q3] = ("%.4f"%lines[line_count][56..63].strip).to_f
            if !(lines[line_count][71..78] == nil) and !(lines[line_count][71..78].to_s.tr("\r\n|\r|\n", "") == "") then
              data[:jfrag4] = lines[line_count][64..68].strip.to_i
              data[:q4] = ("%.4f"%lines[line_count][71..78].strip).to_f
            end
          end
          @ct << data
        end
      elsif data_flag == "three-body" then ### Three-body FMO propaties
        if lines[line_count].to_s.tr("\r\n|\r|\n", "") == "" then
          @@log.info "", "Process: Get data for Three-body FMO propaties from GAMESS Out file", "", @@opts[:text]
          data_flag = ""
        else
          data = {
            ifrag: 0,       ### ith-fragment of dimer between ith and jth, kth
            jfrag: 0,       ### jth-fragment of dimer between ith and jth, kth
            kfrag: 0,       ### kth-fragment of dimer between ith and jth, kth
            d: "",          ### D label in DL: Calculation method
                            ###  - D = C: Dynamically correlated method (MP2,CI)
                            ###  - D = N (No): Not dynamically correlated method (RHF,DFT) 
                            ###  - D = S: Separated dimer: semiclassical interaction (ES)
                            ###  - D = M: MCSCF method
            d_label: "",    ### Label (D) for calculation method
            l: 0,           ### L label in DL: Layer number of multi-layer

              ##################################################################
              ##################################################################
              ##################################################################
              ##################################################################
              ##################################################################
              ##################################################################
              ###
              ### Add necessary data for three-body   
              ###
              ##################################################################
              ##################################################################
              ##################################################################
              ##################################################################
              ##################################################################
              ##################################################################
            }
            ##################################################################
            ##################################################################
            ##################################################################
            ##################################################################
            ##################################################################
            ##################################################################
            ###
            ### Add analysis of process for three-body    
            ###
            ##################################################################
            ##################################################################
            ##################################################################
            ##################################################################
            ##################################################################
            ##################################################################
          @three_body_fmo << data
        end
      elsif data_flag == "mulliken" then ### N-body Mulliken atomic charges: Q(n)
        if @@opts[:interaction] == 2 then ### All-pairs mode
          ##################################################################
          ##################################################################
          ##################################################################
          ##################################################################
          ##################################################################
          ##################################################################
          ###
          ### if opts[:interaction] == 1 and FMO caluclation is All-pairs mode,
          ###   extract mulliken charge?
          ###
          ##################################################################
          ##################################################################
          ##################################################################
          ##################################################################
          ##################################################################
          ##################################################################
          if lines[line_count].to_s.tr("\r\n|\r|\n", "") == "" then
            @@log.info "", "Process: Get data for N-body Mulliken atomic charges from GAMESS Out file", "", @@opts[:text]
            data_flag = ""
          else
            data = {
              atom_num: 0,    ### IAT = Atom sequence number
              residue_num: 0, ### IFG = Residue number
              z: 0,           ### Z: Atomic number (%.1f in Out file => int in this program)
              atom_name: "",  ### Atom name: Symbol defined by Z(Atomic number)
              q1: 0.0,        ### Q(1): 1-body Mulliken atomic charges
              q2: 0.0,        ### Q(2): 2-body Mulliken atomic charges, exact value from the FMO calculation
              q3: 0.0,        ### Q(3): 3-body Mulliken atomic charges
            }
            data[:atom_num] = lines[line_count][0..5].strip.to_i
            data[:residue_num] = lines[line_count][6..10].strip.to_i
#            data[:z] = ("%.1f"%lines[line_count][11..16].strip).to_f
            data[:z] = lines[line_count][11..16].strip.to_i
            data[:atom_name] = $symbol[data[:z] - 1]
            data[:q1] = ("%.6f"%lines[line_count][17..28].strip).to_f
            sum_q1 = (BigDecimal(sum_q1.to_s) + BigDecimal(data[:q1].to_s)).to_f
            if !(lines[line_count][29..40] == nil) and !(lines[line_count][29..40].to_s.tr("\r\n|\r|\n", "") == "") then
              fmo2_charge = true
              data[:q2] = ("%.6f"%lines[line_count][29..40].strip).to_f
              sum_q2 = (BigDecimal(sum_q2.to_s) + BigDecimal(data[:q2].to_s)).to_f
              if !(lines[line_count][41..52] == nil) and !(lines[line_count][41..52].to_s.tr("\r\n|\r|\n", "") == "") then
                data[:q3] = ("%.6f"%lines[line_count][41..52].strip).to_f
                sum_q3 = (BigDecimal(sum_q3.to_s) + BigDecimal(data[:q3].to_s)).to_f
              end 
            end
            @mulliken_charge << data
          end
        elsif @@opts[:interaction] == 1 then ### Selected-pairs mode
          line_count += @gamess_header[:num_of_atoms] ### Skip by number of atoms
          data_flag = ""
          @@log.info "\n", "  * If the calculation mode is \"Selected-pairs\", mulliken charge has not been calculated correctly by FMO.", "", @@opts[:text]
          @@log.info "", "    So, in the case of \"Selected-pairs\", mulliken charge is not extracted from Out file.", "", @@opts[:text]
          @@log.info "", "  * Otherwise, If you selected analysis mode for \"Selected-pairs\", mulliken charge is not extracted from Out file.", "", @@opts[:text]
        end
      end
      line_count += 1
    end

    dist_file.write(" ---------------------------------------------------------------------------------------------------------\n\n")
    dist_file.close

    @@log.info "\n", "  Charge on your system (input): #{@gamess_header[:charge]}", "" , @@opts[:text]
    @@log.info "", "   - Sum of Q(1, FMO1): #{sum_q1}", "" , @@opts[:text]
    @@log.info "", "   - Sum of Q(2, FMO2): #{sum_q2}", "" , @@opts[:text]
    @@log.info "", "   - Sum of Q(3, FMO3): #{sum_q3}", "" , @@opts[:text]
    @@log.info "", "    *(If value is 0.0, no calculation)", "\n" , @@opts[:text]
    Write_data.new.make_pdb_charge(@mulliken_charge, @@opts) if (fmo2_charge)
  end

  #*** Define amino acid data using number of atoms for GAMESS-FMO ***#
  def check_num_of_atoms(data)
    amino_acid = {
      "ALA"=>10, "ARG"=>23, "ASN"=>14, "ASP"=>13, "CYS"=>11,
      "GLN"=>17, "GLU"=>16, "GLY"=>7, "HIS"=>17, "HIP"=>17,
      "ILE"=>19, "LEU"=>19, "LYS"=>22, "MET"=>17, "PHE"=>20,
      "PRO"=>14, "SER"=>11, "THR"=>14, "TRP"=>26, "TYR"=>21,
      "VAL"=>16,
    }
    ### Error bar at number of atoms
    ### (ex). Number of atoms in ALA = 10 or 13 as given in GAMESS-FMO Out file
    error = 5

    if amino_acid.select{|key,_| data[:residue_name].include?(key)}[data[:residue_name]] == nil then
      return 2  ### Unknown fragment name, no amino acid, FRAG*, ..., and so on.
    else
      ### Check whether the actual No of atoms in the frag is larger than the max possible number
      if (data[:num_of_atoms] > (amino_acid.select{|key,_| data[:residue_name].include?(key)}[data[:residue_name]] + error)) then
        return 1  ### fragment including amino acids more than 1!!
      else
        return 0  ### fragment including "1 amino acid" only
      end
    end
  end

  #*** Calculate the average distance and energy data "every particles (ligand)" ***#
  def cal_ave_data
    i = 1
    if !(@@flags[:ligand_num]) then ### Without -n option
      if @frag_data[:particle] > 1 then
        while (i < @frag_data[:frag_num][0]) do
          j = 0
          data = {
            ifrag: 0,           ### ith-fragment of dimer between ith and jth
            jfrag: 0,           ### jth-fragment of dimer between ith and jth
            r: 0.0,             ### Interfragment distance relative to van-der-Waals radii between ith- and jth-fragment [%]
            r_frag: [],
            eij_ei_ej: 0.0,     ### E_{ij} - E_{i} - E_{j} [kcal/mol]
            eij_ei_ej_frag: [],
            dij_vij: 0.0,       ### Tr(dD^{ij}*V^{ij}): Explicit embedded charge transfer energy [kcal/mol]
            dij_vij_frag: [],
            e_total: 0.0,       ### PIE (pair interaction energy) [kcal/mol] 
            e_total_frag: [],
            e_es: 0.0,          ### Electrostatic energy [kcal/mol]
            e_es_frag: [],
            e_ex: 0.0,          ### Exchange repulsion energy [kcal/mol]
            e_ex_frag: [],
            e_ct_mix: 0.0,      ### Energy for charge transfer + MIX [kcal/mol]
            e_ct_mix_frag: [],
            e_disp: 0.0,        ### Dispersion energy [kcal/mol]
            e_disp_frag: [],
            g_sol: 0.0,         ### Solvation free energy [kcal/mol]
            g_sol_frag: [],
          }
          @frag_data[:frag_num].each { |f|
            @two_body_fmo.select{|t| t[:ifrag] == i && t[:jfrag] == f}.each { |d|
              data[:r] = (BigDecimal(data[:r].to_s) + BigDecimal(d[:r].to_s)).to_f
              data[:r_frag][j] = d[:r]
              data[:eij_ei_ej] = (BigDecimal(data[:eij_ei_ej].to_s) + BigDecimal(d[:eij_ei_ej].to_s)).to_f
              data[:eij_ei_ej_frag][j] = d[:eij_ei_ej]
              data[:dij_vij] = (BigDecimal(data[:dij_vij].to_s) + BigDecimal(d[:dij_vij].to_s)).to_f
              data[:dij_vij_frag][j] = d[:dij_vij]
              data[:e_total] = (BigDecimal(data[:e_total].to_s) + BigDecimal(d[:e_total].to_s)).to_f
              data[:e_total_frag][j] = d[:e_total]
              data[:e_es] = (BigDecimal(data[:e_es].to_s) + BigDecimal(d[:e_es].to_s)).to_f
              data[:e_es_frag][j] = d[:e_es]
              data[:e_ex] = (BigDecimal(data[:e_ex].to_s) + BigDecimal(d[:e_ex].to_s)).to_f
              data[:e_ex_frag][j] = d[:e_ex]
              data[:e_ct_mix] = (BigDecimal(data[:e_ct_mix].to_s) + BigDecimal(d[:e_ct_mix].to_s)).to_f
              data[:e_ct_mix_frag][j] = d[:e_ct_mix]
              data[:e_disp] = (BigDecimal(data[:e_disp].to_s) + BigDecimal(d[:e_disp].to_s)).to_f
              data[:e_disp_frag][j] = d[:e_disp]
              data[:g_sol] = (BigDecimal(data[:g_sol].to_s) + BigDecimal(d[:g_sol].to_s)).to_f
              data[:g_sol_frag][j] = d[:g_sol]
              j += 1
            }
          }
          data[:ifrag] = i
#          data[:jfrag] = "target"
          data[:jfrag] = @frag_data[:frag_num][0]
          data[:distance] /= @frag_data[:particle]
          @ave_data << data
          i += 1
        end
      elsif (@frag_data[:particle] == 1) then
        if (@frag_data[:max] == @two_body_fmo.size) then
          @ave_data = @two_body_fmo.dup
        else ### If data is All-pairs mode and opts[:interaction] == 1 (Ligand mode)
          if (@frag_data[:frag_num][0].to_i < @frag_data[:max]) then
            while (i <= @frag_data[:max]) do
              data = {
                ifrag: 0,       ### ith-fragment of dimer between ith and jth
                jfrag: 0,       ### jth-fragment of dimer between ith and jth
                r: 0.0,         ### Interfragment distance relative to van-der-Waals radii between ith- and jth-fragment [%]
                eij_ei_ej: 0.0, ### E_{ij} - E_{i} - E_{j} [kcal/mol]:
                dij_vij: 0.0,   ### Tr(dD^{ij}*V^{ij}): Explicit embedded charge transfer energy [kcal/mol]
                e_total: 0.0,   ### PIE (pair interaction energy) [kcal/mol] 
                e_es: 0.0,      ### Electrostatic energy [kcal/mol]
                e_ex: 0.0,      ### Exchange repulsion energy [kcal/mol]
                e_ct_mix: 0.0,  ### Energy for charge transfer + MIX [kcal/mol]
                e_disp: 0.0,    ### Dispersion energy [kcal/mol]
                g_sol: 0.0,     ### Solvation free energy [kcal/mol]
              }
              @two_body_fmo.select{|t| t[:ifrag] == i && t[:jfrag] == @frag_data[:frag_num][0]}.each { |d|
                data[:ifrag] = i
                data[:jfrag] = @frag_data[:frag_num][0]
                data[:r] = d[:r]
                data[:eij_ei_ej] = d[:eij_ei_ej]
                data[:dij_vij] = d[:dij_vij]
                data[:e_total] = d[:e_total]
                data[:e_es] = d[:e_es]
                data[:e_ex] = d[:e_ex]
                data[:e_ct_mix] = d[:e_ct_mix]
                data[:e_disp] = d[:e_disp]
                data[:g_sol] = d[:g_sol]
              }
              if !(i == @frag_data[:frag_num][0].to_i) then
                @ave_data << data
              end
              i += 1
            end
          elsif (@frag_data[:frag_num][0] == @frag_data[:max]) then
            while (i < @frag_data[:max]) do
              data = {
                ifrag: 0,       ### ith-fragment of dimer between ith and jth
                jfrag: 0,       ### jth-fragment of dimer between ith and jth
                r: 0.0,         ### Interfragment distance relative to van-der-Waals radii between ith- and jth-fragment [%]
                eij_ei_ej: 0.0, ### E_{ij} - E_{i} - E_{j} [kcal/mol]:
                dij_vij: 0.0,   ### Tr(dD^{ij}*V^{ij}): Explicit embedded charge transfer energy [kcal/mol]
                e_total: 0.0,   ### PIE (pair interaction energy) [kcal/mol] 
                e_es: 0.0,      ### Electrostatic energy [kcal/mol]
                e_ex: 0.0,      ### Exchange repulsion energy [kcal/mol]
                e_ct_mix: 0.0,  ### Energy for charge transfer + MIX [kcal/mol]
                e_disp: 0.0,    ### Dispersion energy [kcal/mol]
                g_sol: 0.0,     ### Solvation free energy [kcal/mol]
              }
              @two_body_fmo.select{|t| t[:ifrag] == i && t[:jfrag] == @frag_data[:frag_num][0]}.each { |d|
                data[:ifrag] = i
                data[:jfrag] = @frag_data[:frag_num][0]
                data[:r] = d[:r]
                data[:eij_ei_ej] = d[:eij_ei_ej]
                data[:dij_vij] = d[:dij_vij]
                data[:e_total] = d[:e_total]
                data[:e_es] = d[:e_es]
                data[:e_ex] = d[:e_ex]
                data[:e_ct_mix] = d[:e_ct_mix]
                data[:e_disp] = d[:e_disp]
                data[:g_sol] = d[:g_sol]
              }
              @ave_data << data
              i += 1
            end
          end
        end
      end
    else ### With -n option
      while (i <= @frag_data[:max]) do
        if !(i == @@opts[:ligand_num]) then
          data = {
            ifrag: 0,       ### ith-fragment of dimer between ith and jth
            jfrag: 0,       ### jth-fragment of dimer between ith and jth
            r: 0.0,         ### Interfragment distance relative to van-der-Waals radii between ith- and jth-fragment [%]
            eij_ei_ej: 0.0, ### E_{ij} - E_{i} - E_{j} [kcal/mol]:
            dij_vij: 0.0,   ### Tr(dD^{ij}*V^{ij}): Explicit embedded charge transfer energy [kcal/mol]
            e_total: 0.0,   ### PIE (pair interaction energy) [kcal/mol] 
            e_es: 0.0,      ### Electrostatic energy [kcal/mol]
            e_ex: 0.0,      ### Exchange repulsion energy [kcal/mol]
            e_ct_mix: 0.0,  ### Energy for charge transfer + MIX [kcal/mol]
            e_disp: 0.0,    ### Dispersion energy [kcal/mol]
            g_sol: 0.0,     ### Solvation free energy [kcal/mol]
          }
        end
        if (i < @@opts[:ligand_num]) then
          @two_body_fmo.select{|t| t[:ifrag] == i && t[:jfrag] == @@opts[:ligand_num]}.each { |d|
            data[:ifrag] = i
            data[:jfrag] = @@opts[:ligand_num]
            data[:r] = d[:r]
            data[:eij_ei_ej] = d[:eij_ei_ej]
            data[:dij_vij] = d[:dij_vij]
            data[:e_total] = d[:e_total]
            data[:e_es] = d[:e_es]
            data[:e_ex] = d[:e_ex]
            data[:e_ct_mix] = d[:e_ct_mix]
            data[:e_disp] = d[:e_disp]
            data[:g_sol] = d[:g_sol]
          }
        elsif (i > @@opts[:ligand_num]) then
          @two_body_fmo.select{|t| t[:ifrag] == @@opts[:ligand_num] && t[:jfrag] == i}.each { |d|
            data[:ifrag] = i
            data[:jfrag] = @@opts[:ligand_num]
            data[:r] = d[:r]
            data[:eij_ei_ej] = d[:eij_ei_ej]
            data[:dij_vij] = d[:dij_vij]
            data[:e_total] = d[:e_total]
            data[:e_es] = d[:e_es]
            data[:e_ex] = d[:e_ex]
            data[:e_ct_mix] = d[:e_ct_mix]
            data[:e_disp] = d[:e_disp]
            data[:g_sol] = d[:g_sol]
          }
        end
        @ave_data << data
        i += 1
      end
    end
  end

  #*** Make data line for 1-dimensional table (Selected-pairs mode) from GAMESS-FMO Out file ***#
  def gamess_fmo_selectedpairs_output
#    function_name = "gamess_fmo_selectedpairs_output"
    i = 0

    ### Decide target number of fragments (Ligands)
    if !(@@flags[:ligand_num]) then
      if @frag_data[:particle] == 1 then
        target = @frag_data[:frag_num][0].to_s
      else
#        target = "target"
        target = @frag_data[:frag_num][0].to_s
      end
    else
      target = @@opts[:ligand_num].to_s
    end

    @@log.info "\n", "Process: Write all energy data at one-dimensional table", "", @@opts[:text]

    write_line = "-" * 303 + "\n"
    data_txt_label = "   ij-frag   | %11s | %15s | %5s | %14s | %8s | %15s | % 18s  | % 18s | % 22s | % 20s | % 19s | % 21s | % 30s | % 30s |\n"%["Amino Acid" , 
                     "Amino Acid(PDB)", "Chain", "Residue Number".center(14), "S-S bond", "Distance [%]".center(15), "E_{es} [kcal/mol]", "E_{ex} [kcal/mol]", 
                     "E_{ct+mix} [kcal/mol]", "E_{disp} [kcal/mol]", "G_{sol} [kcal/mol]", "E_{total} [kcal/mol]",
                     "E_{ij}-E_{i}-E_{j} [kcal/mol]", "Tr(dD^{ij}*V^{ij}) [kcal/mol]"]
    data_csv_label = ",,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n"%["Number", "Fragment Number", "Amino Acid" , "Amino Acid(PDB)", "Chain",
                     "Residue Number", "S-S bond", "Distance [%]", "E_{es} [kcal/mol]", "E_{ex} [kcal/mol]", "E_{ct+mix} [kcal/mol]", 
                     "E_{disp} [kcal/mol]", "G_{sol} [kcal/mol]", "E_{total} [kcal/mol]", "E_{ij}-E_{i}-E_{j} [kcal/mol]", "Tr(dD^{ij}*V^{ij}) [kcal/mol]"]
    ### Write header in output
    Write_data.new.write_txt_data("\n<Data>\n", @@opts, 1, @@log)
    Write_data.new.write_txt_data(write_line, @@opts, 1, @@log)
    Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
    Write_data.new.write_txt_data(write_line, @@opts, 1, @@log)
    Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)

    if !(@@flags[:ligand_num]) then ### Without -n option
      if (@frag_data[:particle] == 1) then
        while (i < (@frag_data[:max] - 1)) do
          if (i + 1 < @frag_data[:frag_num][0]) then
            data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#19.3f | %#18.3f | %#22.3f | %#20.3f | %#19.3f | %#21.3f | %#30.3f | %#30.3f |\n"%[
                             (i + 1), target, @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                             @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                             " ".center(8), @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:r].to_s.rjust(14),
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_es], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ex], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_disp], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:g_sol], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total],
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:eij_ei_ej],
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dij_vij]]
            data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%f,%f,%f,%f\n"%[
                             (i + 1), target, @frag_statistics[i][:residue_name], @frag_statistics[i][:final_pdb_residue_name], @frag_statistics[i][:chain], 
                             @frag_statistics[i][:final_pdb_residue_num], " ", 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:r].to_s,
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_es], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ex], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_disp], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:g_sol], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total],
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:eij_ei_ej],
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dij_vij]]
            @sum_total_e = (BigDecimal(@sum_total_e.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total].to_s)).to_f
          elsif (i + 1 >= @frag_data[:frag_num][0]) then
            data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#19.3f | %#18.3f | %#22.3f | %#20.3f | %#19.3f | %#21.3f | %#30.3f | %#30.3f |\n"%[
                             (i + 2), target, @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                             @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                             " ".center(8), @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:r].to_s.rjust(14),
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_es], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ex], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_disp], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:g_sol], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_total],
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:eij_ei_ej],
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dij_vij]]
            data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%f,%f,%f,%f\n"%[
                             (i + 2), target, @frag_statistics[i + 1][:residue_name], @frag_statistics[i + 1][:final_pdb_residue_name], @frag_statistics[i + 1][:chain], 
                             @frag_statistics[i + 1][:final_pdb_residue_num], " ", 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:r].to_s,
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_es], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ex], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_disp], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:g_sol], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_total],
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:eij_ei_ej],
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dij_vij]]
            @sum_total_e = (BigDecimal(@sum_total_e.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_total].to_s)).to_f
          end
          Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
          Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
          i += 1
        end
      elsif (@frag_data[:particle] > 1) then
        while (i < (@frag_data[:frag_num][0] - 1)) do
          data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#19.3f | %#18.3f | %#22.3f | %#20.3f | %#19.3f | %#21.3f | %#30.3f | %#30.3f |\n"%[
                           (i + 1), target, @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                           @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                           " ".center(8), @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14),
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_es], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ex], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_disp], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:g_sol], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total],
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:eij_ei_ej],
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dij_vij]]
          data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%f,%f,%f,%f\n"%[
                           (i + 1), target, @frag_statistics[i][:residue_name], @frag_statistics[i][:final_pdb_residue_name], @frag_statistics[i][:chain], 
                           @frag_statistics[i][:final_pdb_residue_num], " ", 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s,
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_es], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ex], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_disp], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:g_sol], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total],
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:eij_ei_ej],
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dij_vij]]
          @sum_total_e = (BigDecimal(@sum_total_e.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total].to_s)).to_f
          Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
          Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
          i += 1
        end
      end
    else ### With -n option
      while (i < (@frag_data[:max] - 1)) do
        if (i + 1 < @@opts[:ligand_num]) then
          data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#19.3f | %#18.3f | %#22.3f | %#20.3f | %#19.3f | %#21.3f | %#30.3f | %#30.3f |\n"%[
                           (i + 1), target, @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                           @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                           " ".center(8), @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:r].to_s.rjust(14),
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_es], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ex], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_disp], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:g_sol], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total],
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:eij_ei_ej],
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dij_vij]]
          data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%f,%f,%f,%f\n"%[
                           (i + 1), target, @frag_statistics[i][:residue_name], @frag_statistics[i][:final_pdb_residue_name], @frag_statistics[i][:chain], 
                           @frag_statistics[i][:final_pdb_residue_num], " ", 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:r].to_s,
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_es], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ex], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_disp], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:g_sol], 
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total],
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:eij_ei_ej],
                           @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dij_vij]]
          @sum_total_e = (BigDecimal(@sum_total_e.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total].to_s)).to_f
        elsif (i + 1 >= @@opts[:ligand_num]) then
          data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#19.3f | %#18.3f | %#22.3f | %#20.3f | %#19.3f | %#21.3f | %#30.3f | %#30.3f |\n"%[
                           (i + 2), target, @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                           @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                           " ".center(8), @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:r].to_s.rjust(14),
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_es], 
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ex], 
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_disp], 
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:g_sol], 
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_total],
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:eij_ei_ej],
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dij_vij]]
          data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%f,%f,%f,%f\n"%[
                           (i + 2), target, @frag_statistics[i + 1][:residue_name], @frag_statistics[i + 1][:final_pdb_residue_name], @frag_statistics[i + 1][:chain], 
                           @frag_statistics[i + 1][:final_pdb_residue_num], " ", 
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:r].to_s,
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_es], 
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ex], 
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_disp], 
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:g_sol], 
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_total],
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:eij_ei_ej],
                           @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dij_vij]]
          @sum_total_e = (BigDecimal(@sum_total_e.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_total].to_s)).to_f
        end
        Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
        Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
        i += 1
      end
    end
    Write_data.new.write_txt_data(write_line, @@opts, 1, @@log)
    ### Label for Binding Affinity
    data_txt_label = "Sum of E(total) = % 9.3f [kcal/mol]"%@sum_total_e
    data_csv_label = "\n\n,,Sum of E(total),%9.3f [kcal/mol]"%@sum_total_e
    @@log.info "\n", "  #{data_txt_label}", "\n", @@opts[:text]
    Write_data.new.write_txt_data("\n", @@opts, 1, @@log)
    Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
    Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
  end

  #*** Make data line for 2-dimensional table (All fragment interaction mode) from GAMESS-FMO Out file ***#
  def gamess_fmo_all_output(energy)
#    function_name = "gamess_fmo_all_output"
    data_txt_label = ""
    data_csv_label = ""
    dat_line = ""
    @dat_file = "2d_energy.dat"
    plot_energy = []
    energy_count = 0
    mode = [
      "E_{es} (Electrostatic)", "E_{ex} (Exchange repulsion)", "E_{ct+mix} (Charge transfer + MIX)", 
      "E_{disp} (Dispersion)", "G_{sol} (Solvation free energy)", "E_{total} (PIE: pair interaction energy)",
      "(E_{ij} - E_{i} - E_{j})", "Tr(dD^{ij} * V^{ij})", 
    ]

    @@log.info "\n", "Process: Write energy data (#{mode[@@opts[:mode] - 1]} [kcal/mol]) at two-dimensional table", "", @@opts[:text]

    for i in (@@opts[:fragment][0] - 1)..@@opts[:fragment][1]
      for j in (@@opts[:fragment][0] - 1)..(@@opts[:fragment][1] + 1)
        if i == (@@opts[:fragment][0] - 1) then ### First line
          if j == (@@opts[:fragment][0] - 1) then
            data_txt_label += "| %16s "%""
            data_csv_label += ",,,,"
          elsif j == (@@opts[:fragment][0]) or j == (@@opts[:fragment][0] + 1) then
            data_txt_label += " %12s "%""
            data_csv_label += "%s,"%""
          elsif j == (@@opts[:fragment][1] + 1) then
            data_txt_label += "%25s |\n"%(j - 2).to_s
            data_csv_label += ",%s\n"%(j - 2).to_s
          else
            data_txt_label += "%24s "%(j - 2).to_s
            data_csv_label += ",%s"%(j - 2).to_s
          end 
        else ### Other line (2rd, 3rd, 4th,... Nth line)
          if j == (@@opts[:fragment][0] - 1) then
            data_txt_label += "| %5s |"%i.to_s
            data_csv_label += ",%s,"%i.to_s
          elsif j == @@opts[:fragment][0] then
            data_txt_label += " %6s | %6s | %s | %6s |"%[@frag_statistics[i - 1][:residue_name], @frag_statistics[i - 1][:final_pdb_residue_name], 
                                                         @frag_statistics[i - 1][:chain], " "]
            data_csv_label += " %s, %s,%s, %s,"%[@frag_statistics[i - 1][:residue_name], @frag_statistics[i - 1][:final_pdb_residue_name], 
                                                 @frag_statistics[i - 1][:chain], " "]
          elsif j == (@@opts[:fragment][0] + 1) then ### Residue number
            data_txt_label += " %5s |"%@frag_statistics[i - 1][:final_pdb_residue_num]
            data_csv_label += "%s,"%@frag_statistics[i - 1][:final_pdb_residue_num]
          elsif j == (@@opts[:fragment][1] + 1) then
#            dat_line += "%i %i %f\n\n"%[i - 1, j - 2, energy[j - 2][i]] if ((j - 2) < (i - 1))
            data_txt_label += " %22s |\n"%energy[j - 2][i]
            data_csv_label += " %22s\n"%energy[j - 2][i]
          else
            if ((j - 2) < (i - 1))
              plot_energy[energy_count] = energy[j - 2][i]
              energy_count += 1
              dat_line += "%i %i %f\n"%[i - 1, j - 2, energy[j - 2][i]]
            end
            dat_line += "\n" if ((j - 1) == (i - 1))
            data_txt_label += " %22s |"%energy[j - 2][i]
            data_csv_label += "%22s,"%energy[j - 2][i]
          end
        end
      end
      if (i == 0) then ### Write first line 
        Write_data.new.write_txt_data(data_txt_label, @@opts, 0, @@log)
        Write_data.new.write_csv_data(data_csv_label, @@opts, 0, @@log)
        Write_data.new.write_data(dat_line, @@opts, 0, @@log, @dat_file)
      else ### Write ohter line
        Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
        Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
        Write_data.new.write_data(dat_line, @@opts, 1, @@log, @dat_file)
      end
      ### Reset
      data_txt_label = ""
      data_csv_label = ""
      dat_line = ""
    end

    return plot_energy
  end

  def run(cmd_exist)
    work_dir = File.dirname(@@opts[:out]) ### Get the path of work dir
    get_gamess_scc
    acquire_gamess_data

    if (@@opts[:interaction] == 1) then ### Selected-pairs mode (User's selected target vs All fragments)
      cal_ave_data
      gamess_fmo_selectedpairs_output

      if cmd_exist[:gnuplot] and @@opts[:gnuplot] then ### Plot
        Dir.chdir(work_dir) do
          @@log.info "\n", "****************", "", @@opts[:text]
          @@log.info "", "* Plot Process *"  , "", @@opts[:text]
          @@log.info "", "****************", "\n", @@opts[:text]
          plot = Plot.new(@@opts, @frag_data, @dat_file, @@log)
          plot.extract_gamess_analysis_data(@ave_data, @frag_statistics)
          plot.make_one_d_plt("gamess-fmo")
          plot.plot_gnuplot
          if (cmd_exist[:ps2pdf] or cmd_exist[:gs])  then
            plot.convert_ps2pdf
          else
            @@log.warn "\n", "Warning: Do not convert PS file into PDF file because the Ghostscript (gs) program is not installed on your system!", "\n", @@opts[:text]
          end
        end
      elsif !(cmd_exist[:gnuplot]) and @@opts[:gnuplot]
        @@log.error "\n", "Error: Gnuplot program is not installed on your system!", "\n", @@opts[:text]
      else
        @@log.info "\n", "Process: All process finished \"without plot process\"!", "\n", @@opts[:text]
      end
    elsif (@@opts[:interaction] == 2) then ### All fragment interaction (All fragments vs All fragments)
      energy = Array.new(@frag_data[:max]).map{Array.new(@frag_data[:max], 0.0)}
      mode = [:e_es, :e_ex, :e_ct_mix, :e_disp, :g_sol, :e_total, :eij_ei_ej, :dij_vij]
      @two_body_fmo.each { |d|
        if (d[:r] == 0.00) then
          energy[d[:ifrag]][d[:jfrag]] = 0.000
        else
          energy[d[:ifrag]][d[:jfrag]] = d[mode[@@opts[:mode] - 1]]
        end
      }
      plot_energy = gamess_fmo_all_output(energy)
      plot = Plot.new(@@opts, @frag_data, @dat_file, @@log)
      plot.make_two_d_plt(plot_energy)
      Dir.chdir(work_dir) do
        if cmd_exist[:gnuplot] then
          @@log.info "\n", "****************", "", @@opts[:text]
          @@log.info "", "* Plot Process *"  , "", @@opts[:text]
          @@log.info "", "****************", "\n", @@opts[:text]
          plot.plot_gnuplot
          if cmd_exist[:ps2pdf] then
            plot.convert_ps2pdf
          end
        end
      end
    end
    
    if (@@xml_flag) then
      if @@opts[:xml] then
        @@log.info "\n", "Process: Output XML from Analysis GAMESS-FMO out data", "", @@opts[:text]
        xml = XML.new(@@opts, @@log)
        xml.xml_gamess_fmo(@frag_data, @gamess_header, @frag_statistics, @one_body_fmo, @fmo_property, 
                           @two_body_fmo, @ct, @three_body_fmo, @mulliken_charge, @total_energy)
      end
    end
  end

end


#******************************************************************************#
#***     Class for analysis of ABINIT_MP Out file (*.log or *.out, ...)     ***#
#******************************************************************************#
class ABINIT_MP < Analysis
  def initialize(frag_data ={}, abinitmp_header = {}, frag_statistics = [], out_data = [], mulliken_charge = [],
                 total_energy = {}, ifie_energy = [], pieda_energy = [], ave_data = [], ave_pieda_data = [],  
                 binding_affinity = 0.0, sum_total_e = 0.0, dat_file = "")
    super(@@opts, @@flags, @@log, @@pdb_all_data, @@cys_pdb_data, @@cb_pdb_data, @@h_pdb_data, @@his_pdb_name, @@xml_flag)
    @frag_data = frag_data
    @abinitmp_header = abinitmp_header
    @frag_statistics = frag_statistics
    @out_data = out_data
    @mulliken_charge = mulliken_charge
    @total_energy = total_energy
    @ifie_energy = ifie_energy
    @pieda_energy = pieda_energy
    @ave_data = ave_data
    @ave_pieda_data = ave_pieda_data
    @binding_affinity = binding_affinity
    @sum_total_e = sum_total_e
    @dat_file = dat_file
  end

  #*** Get the data of SCC (self consistent charge) calculation on ABINIT-MP ***#
  def get_abinitmp_scc
    line_count = 0
    flag = false
    scc_file = "scc_data.csv"

    begin 
      data_file = open(@@opts[:out], "r")
    rescue SystemCallError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
    rescue IOError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
    end
    line_data = data_file.readlines### Read line from opened file

    header_line = "%s,%s,%s,%s,%s,%s\n"%["Iteration", "Electronic energy [hartree]", "delta E [hartree]", "NSCF", "Threshold", "theta"]
    Write_data.new.write_data(header_line, @@opts, 0, @@log, scc_file)
    while line_count < line_data.size do  ### If not EOF (End Of File)
      data = line_data[line_count].split(/\s* \s*/)
      if (data[1] == "Iteration" and data[2] == "Electronic" and data[3] == "energy" and data[4] == "delta") then
        flag = true
        line_count += 1
      elsif (flag) then
        if (data.size > 1) then
          csv_line = "%s,%s,%s,%s,%s,%s\n"%[data[1], data[2], data[3], data[4], data[5], data[6].tr("\r\n|\r|\n", "")]
          Write_data.new.write_data(csv_line, @@opts, 1, @@log, scc_file)
        else
          flag = false
          break
        end
      end
      line_count += 1
    end
  end

  def split_namelist(data)
    if (data != nil) then
      data.split(/=/)[1].tr("\r\n|\r|\n", "").strip
    else
      ""
    end
  end

  #*** Acquire data for residues and energies, and so on, ... from ABINIT-MP Out file ***#
  def acquire_abinitmp_data
    work_dir = File.dirname(@@opts[:out])
    distance_zero_filename = "dist_AA_zero.txt"
    distance_zero_path = File.join(work_dir, distance_zero_filename)
    line_count = 0
    res_count = 0
#    sum_atom_pop = 0.0
    sum_net_charge = 0.0

    pdb_res_num = []  ### Array of residue number in PDB file
    @@pdb_all_data.each{ |d|
      pdb_res_num << d[:residue_num]
    }
    pdb_res_num.uniq! ### Returns a new array by removing duplicate values in self

    @frag_data = {
      max: 0,           ### Number of fragments (Max)
      particle: 1,      ### Number of particle fragments (ligands)
      frag_num: [],     ### Particle fragment numbers (ligands)
      charge_of_mol: 0, ### Charge of molecule (this system)
    }
    @abinitmp_header = {
      version: 0.0,            ### ABINIT-MP version
      method: "",              ### Calculation method (HF, MP2, MP2D, MP3, LMP2, CAFI)
      basis_set: "",           ### Basis set
      charge: 0,               ### Total charge of molecule (system)
      spin: 0,                 ### Total spin multiplicity
      memory: 0,               ### Memory per processor
      read_geom: "",           ### Path of input PDB file
      write_geom: "",          ### localtion of calculated output (*.cpf) 
      electronic_state: "S1",  ### S1, S2, S3, D1, D2, D3, T1, but free is "S1" only
      fmo_flag: "",            ### YES: FMO calculation, NO: Conventional MO
      n_body_fmo: 2,           ### N-body expansion of FMO method
      fmo3: "",
      fmo4: "",
      auto_fragmentation: "",  ### ON: auto fragmentation for molecule 
                               ### if FMO=ON and to set ReadGeom into PDB file path
      frag_size_residue: 0,    ### Number of partitions for fragment if AutoFrag=ON
      np: 1,                   ### Number of CPU each fragment
      cp_corr: "",             ### ON: calculate BSSE-CP for IFIE
      region: "",              ### fragment pair for calculation target 
      molecular_formula: "",   ### H: XXX, C: XXX, N: XXX, O: XXX, ... in the calculated system
      num_of_atoms: 0,         ### Number of atoms in this system
      num_of_electrons: 0,     ### Number of electrons in this sytem
      num_basis_func: 0,       ### Number of basis function in this calculation
      pieda: "",               ### PIEDA option, ABINIT-MP "Open" version or later
    }
    @total_energy = {
      hf_nuclear_repulsion: 0.0,              ### Nuclear repulsion (FMO2-HF)
      hf_electronic_energy: 0.0,              ### Electronic energy (FMO2-HF)
      hf_total_energy: 0.0,                   ### Total (HF) = Electronic energy (FMO2-HF) + Nuclear repulsion (FMO2-HF)
      fmo2_mp2_e: 0.0,                        ### E(FMO2-MP2)
      fmo2_mp2_electronic_energy: 0.0,        ### Electronic energy (FMO2-MP2)
      fmo2_mp2_total_energy: 0.0,             ### Total (MP2) = Electronic energy (FMO2-MP2) + Nuclear repulsion (FMO2-HF)
      grimme_fmo2_mp2_e: 0.0,                 ### E(FMO2-MP2) of Grimme SCS energy
      grimme_fmo2_mp2_electronic_energy: 0.0, ### Electronic energy (FMO2-MP2) of Grimme SCS energy
      grimme_fmo2_mp2_total_energy: 0.0,      ### Total (Grimme) = Electronic energy (FMO2-MP2 Grimme) + Nuclear repulsion (FMO2-HF)
      jung_fmo2_mp2_e: 0.0,                   ### E(FMO2-MP2) of Jung (Head-Gordon) SCS energy
      jung_fmo2_mp2_electronic_energy: 0.0,   ### Electronic energy (FMO2-MP2) of Jung (Head-Gordon) SCS energy
      jung_fmo2_mp2_total_energy: 0.0,        ### Total (Jung) = Electronic energy (FMO2-MP2 Jung) + Nuclear repulsion (FMO2-HF)
      hill_fmo2_mp2_e: 0.0,                   ### E(FMO2-MP2) of Hill SCS energy
      hille_fmo2_mp2_electronic_energy: 0.0,  ### Electronic energy (FMO2-MP2) of Hill SCS energy
      hill_fmo2_mp2_total_energy: 0.0,        ### Total (Hill) = Electronic energy (FMO2-MP2 Hill) + Nuclear repulsion (FMO2-HF)
    }

    begin 
      dist_file = open(distance_zero_path, "w")
    rescue SystemCallError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
    rescue IOError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
    end

    if @@opts[:interaction] == 1 then
      Write_data.new.write_txt_data("<File Name Path>\n", @@opts, 0, @@log)
      Write_data.new.write_txt_data(@@opts[:out], @@opts, 1, @@log)
      Write_data.new.write_txt_data("\n\n", @@opts, 1, @@log)
      Write_data.new.write_csv_data("\n\n,File Name Path,", @@opts, 0, @@log)
      Write_data.new.write_csv_data(@@opts[:out], @@opts, 1, @@log)
      Write_data.new.write_csv_data("\n\n", @@opts, 1, @@log)
    end

    @@log.info "\n", "Process: Acquire data for residue and energies from ABINIT-MP Out file", "", @@opts[:text]

    @abinitmp_header[:version] = File.readlines(@@opts[:out]).grep(/ABINIT-MP ver./)[0]
    if @abinitmp_header[:version] == nil then
      @abinitmp_header[:version] = File.readlines(@@opts[:out]).grep(/ABINIT-MP -/)[0].tr("\r\n|\r|\n", "").strip
    else
      @abinitmp_header[:version] = @abinitmp_header[:version].tr("\r\n|\r|\n", "").strip
    end
    ### Namelist (written down on the header data):
    ### READ NAMELIST "CNTRL"
    @abinitmp_header[:electronic_state] = split_namelist(File.readlines(@@opts[:out]).grep(/ElecState/)[0])
    @abinitmp_header[:method] = split_namelist(File.readlines(@@opts[:out]).grep(/Method                  =/)[0])
    @abinitmp_header[:memory] = split_namelist(File.readlines(@@opts[:out]).grep(/Memory per processor/)[0])
    @abinitmp_header[:charge] = split_namelist(File.readlines(@@opts[:out]).grep(/Charge \(Charge of mol\.\)/)[0])
    @abinitmp_header[:read_geom] = split_namelist(File.readlines(@@opts[:out]).grep(/ReadGeom/)[0])
    @abinitmp_header[:write_geom] = split_namelist(File.readlines(@@opts[:out]).grep(/WriteGeom/)[0])
    @abinitmp_header[:spin] = split_namelist(File.readlines(@@opts[:out]).grep(/MULT/)[0])
    ### READ NAMELIST "FMOCNTRL"
    @abinitmp_header[:fmo_flag] = split_namelist(File.readlines(@@opts[:out]).grep(/FMO                     =/)[0])
    @abinitmp_header[:n_body_fmo] = split_namelist(File.readlines(@@opts[:out]).grep(/NBody                   =/)[0])
    @abinitmp_header[:fmo3] = split_namelist(File.readlines(@@opts[:out]).grep(/FMO3                    =/)[0])
    @abinitmp_header[:fmo4] = split_namelist(File.readlines(@@opts[:out]).grep(/FMO4                    =/)[0])
    @abinitmp_header[:auto_fragmentation] = split_namelist(File.readlines(@@opts[:out]).grep(/AutoFrag                =/)[0])
    @abinitmp_header[:frag_size_residue] = split_namelist(File.readlines(@@opts[:out]).grep(/FragSizeResidue         =/)[0])
    @abinitmp_header[:np] = split_namelist(File.readlines(@@opts[:out]).grep(/np_monomer              =/)[0])
    ### READ NAMELIST "BASIS"
    @abinitmp_header[:basis_set] = split_namelist(File.readlines(@@opts[:out]).grep(/BasisSet                =/)[0])
    ### READ NAMELIST "BSSE"
    @abinitmp_header[:cp_corr] = split_namelist(File.readlines(@@opts[:out]).grep(/CP                      =/)[0])
    @abinitmp_header[:region] = split_namelist(File.readlines(@@opts[:out]).grep(/Region                  =/)[0])
    @abinitmp_header[:num_of_electrons] = split_namelist(File.readlines(@@opts[:out]).grep(/ALL ELECTRON =/)[0]).to_i
    @abinitmp_header[:num_of_atoms] = split_namelist(File.readlines(@@opts[:out]).grep(/ALL ATOM     =/)[0]).to_i
    @abinitmp_header[:num_basis_func] = split_namelist(File.readlines(@@opts[:out]).grep(/NUMBER OF BASIS FUNCTIONS =/)[0]).to_i
    @frag_data[:charge_of_mol] = split_namelist(File.readlines(@@opts[:out]).grep(/CHARGE OF MOLECULE =/)[0]).to_i
    @abinitmp_header[:pieda] = split_namelist(File.readlines(@@opts[:out]).grep(/PIEDA         =/)[0])
    @abinitmp_header[:pieda] = "NO" if @abinitmp_header[:pieda] == ""

    ### Number of fragment
    @frag_data[:max] = split_namelist(File.readlines(@@opts[:out]).grep(/NUMBER OF FRAGMENTS =/)[0]).to_i
    ################################################################################################
    ################################################################################################
    ################################################################################################
    ################################################################################################
    ################################################################################################
    ################################################################################################
    ###                                                                                          ###
    ### As of September, 2018, "partcile == 1 only" at ABINIT-MP or ABINIT-MP Open!!             ###
    ###                                                                                          ###
    ################################################################################################
    ################################################################################################
    ################################################################################################
    ################################################################################################
    ################################################################################################
    ################################################################################################
    @frag_data[:frag_num][0] = @frag_data[:max]
    @@opts[:fragment][1] = @frag_data[:max] if (@@opts[:fragment][1] == 0) ### Using -j all
    @frag_data[:particle] = 1

    @@log.info "\n", "  Number of fragments = #{@frag_data[:max]}", "", @@opts[:text]
    @@log.info "", "  Number of particle fragments (ligands):  #{@frag_data[:particle]}", "", @@opts[:text]
    if @frag_data[:particle] > 1 then
      @@log.info "", "  Ligand number:  #{@frag_data[:frag_num][0]}", "", @@opts[:text]
       ################################################################################################
       ################################################################################################
       ################################################################################################
       ################################################################################################
       ################################################################################################
       ################################################################################################
       ###                                                                                          ###
       ### As of September, 2018, "partcile == 1 only" at ABINIT-MP or ABINIT-MP Open!!             ###
       ###                                                                                          ###
       ################################################################################################
       ################################################################################################
       ################################################################################################
       ################################################################################################
       ################################################################################################
       ################################################################################################
    end

    begin
      data_file = open(@@opts[:out], "r")
    rescue SystemCallError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
    rescue IOError => e
      @@log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", @@opts[:text]
    end

    lines = data_file.readlines ### Read line from opened file
    while line_count < lines.size do ### If not EOF
      ### Atom data
      if lines[line_count].tr("\r\n|\r|\n", "") == "     ## MOLECULE AND FRAGMENT INFORMATION" then
        flag = "atom"
        line_count += 5
      end
      if flag == "atom" then
        line_data = lines[line_count].split(/\s* \s*/)
        if line_data.size >= 6 then
          data ={
            atom_num: 0,
            atom_name: "",
            x: 0.0,
            y: 0.0,
            z: 0.0,
          }
          data[:atom_num] = line_data[1].to_i
          data[:atom_name] = line_data[2]
          data[:x] = ("%.6f"%line_data[4]).to_f
          data[:y] = ("%.6f"%line_data[5]).to_f
          data[:z] = ("%.6f"%line_data[6].tr("\r\n|\r|\n", "")).to_f
          @out_data << data
        else
          flag = ""
        end
      end

      ### Molecular formula
      if lines[line_count].tr("\r\n|\r|\n", "") == "     ## Molecular formula" then
        flag = "formula"
        line_count += 2
      end
      if flag == "formula" then
        line_data = lines[line_count].split(/\s* \s*/)
        if line_data.size == 3 then
          @abinitmp_header[:molecular_formula] += "%s: %s, "%[line_data[1], line_data[2].tr("\r\n|\r|\n", "")]
#          @abinitmp_header[:num_of_atoms] += line_data[2].tr("\r\n|\r|\n", "").to_i
        else
          flag = ""
          @abinitmp_header[:molecular_formula].slice!(@abinitmp_header[:molecular_formula].size - 2, 
                                                      @abinitmp_header[:molecular_formula].size - 1)
        end
      end

      line_data = lines[line_count].split(/\s* \s*/)
      ### AUTOMATIC FRAGMENTATION
#      if !(line_data[1] == "##" and line_data[2] == "MANUAL" and line_data[3].tr("\r\n|\r|\n", "") == "FRAGMENTATION") then
      if (@abinitmp_header[:auto_fragmentation] == "ON") then
        if line_data[1] == "Seq." and line_data[2] == "Frag." and line_data[3] == "Residue" then
          flag = "frag"
          line_count += 1
        elsif flag == "frag" and lines[line_count].strip.tr("\r\n|\r|\n", "") == "" then
          flag = ""
        end
        if flag == "frag" then
          data ={
            ifrag: 0,                               ### Frag. (Fragment number): [5..11]
            residue_name: "",                       ### Residue (Residue name): [12..18]
            residue_num: 0,                         ### Seq. (Residue sequence number): [1..4] 
            charge: 0,                              ### Charge of fragment: [40..46]
            chain: "",                              ### Chain identifier: [0]
            n_term: "",                             ### N-term. (N-terminus) (True or False): [30]
            c_term: "",                             ### C-Term. (C-terminus) (True or False): [39] 
            ss: "",                                 ### S-S bond: [19..23]
            polarity: "",                           ### Type of polarity: [48..end]
            final_pdb_residue_name: "",             ### Final PDB residue name 
            final_pdb_residue_num: "",              ### Final PDB residue number
            num_of_elec: 0,                         ### Number of electrons in ith-fragment
            atom_num: [],                           ### Atom numbers contained in the fragment
            num_of_ao: 0,                           ### Number of AOs each fragment
            non_bonding_ifie: [0.0, 0.0, 0.0],      ### Non-bonding interfragment interaction energy
                                                    ### [0]: hartree, [1]: kcal/mol, [2]: kJ/mol
            bsse_non_bonding_ifie: [0.0, 0.0, 0.0], ### BSSE for non-bonding HF-IFIE or MP2-IFIE
                                                    ### [0]: hartree, [1]: kcal/mol, [2]: kJ/mol
          }
          data[:chain] = lines[line_count][0].strip
          data[:residue_num] = lines[line_count][1..4].strip.to_i
          data[:ifrag] = lines[line_count][5..11].strip.to_i
          data[:residue_name] = lines[line_count][12..18].strip
          data[:ss] = lines[line_count][19..23].strip
          data[:n_term] = lines[line_count][30].strip
          data[:c_term] = lines[line_count][39].strip
          data[:charge] = lines[line_count][40..46].strip.to_i
          data[:polarity] = lines[line_count][48..lines[line_count].size].strip.tr("\r\n|\r|\n", "")
          data[:final_pdb_residue_name] = @@pdb_all_data.select{|i| i[:residue_num] == pdb_res_num[res_count]}[0][:residue_name]
          data[:final_pdb_residue_num] = @@pdb_all_data.select{|i| i[:residue_num] == pdb_res_num[res_count]}[0][:residue_num].to_s
          res_count += 1
          @frag_statistics << data
        end
      end

      ### Atom number including each fragment
      if line_data[1] == "Frag." and line_data[2] ==  "Elec." and line_data[3].tr("\r\n|\r|\n", "") ==  "ATOM" then
        i = 0
        ile_leu_count = 0  ### Count ILE and LEU
        flag = "frag_atom"
        line_count += 1
      elsif flag == "frag_atom" and lines[line_count].strip.tr("\r\n|\r|\n", "") == "" then
        flag = ""
      end
      if flag == "frag_atom" then
        if (@abinitmp_header[:auto_fragmentation] == "OFF") ### MANUAL FRAGMENTATION
          if i <= (@frag_data[:max] - 1) then
            data ={
              ifrag: 0,                               ### Frag. (Fragment number): [5..11]
              residue_name: "",                       ### Residue (Residue name): [12..18]
              residue_num: 0,                         ### Seq. (Residue sequence number): [1..4] 
              charge: 0,                              ### Charge of fragment: [40..46]
              chain: "",                              ### Chain identifier: [0]
              n_term: "",                             ### N-term. (N-terminus) (True or False): [30]
              c_term: "",                             ### C-Term. (C-terminus) (True or False): [39] 
              ss: "",                                 ### S-S bond: [19..23]
              polarity: "",                           ### Type of polarity: [48..end]
              final_pdb_residue_name: "",             ### Final PDB residue name 
              final_pdb_residue_num: "",              ### Final PDB residue number
              num_of_elec: 0,                         ### Number of electrons in ith-fragment
              atom_num: [],                           ### Atom numbers contained in the fragment
              num_of_ao: 0,                           ### Number of AOs each fragment
              non_bonding_ifie: [0.0, 0.0, 0.0],      ### Non-bonding interfragment interaction energy
                                                      ### [0]: hartree, [1]: kcal/mol, [2]: kJ/mol
              bsse_non_bonding_ifie: [0.0, 0.0, 0.0], ### BSSE for non-bonding HF-IFIE or MP2-IFIE
                                                      ### [0]: hartree, [1]: kcal/mol, [2]: kJ/mol
            }
            data[:ifrag] = i + 1
            data[:residue_num] = i
            if (i == 0) then
              data[:n_term] = "T"
            else
              data[:n_term] = "F"
            end
            if (i == @frag_data[:max] - 1) then
              data[:c_term] = "T"
            else
              data[:c_term] = "F"
            end
            i += 1
            @frag_statistics << data
          end
        end
        if lines[line_count][0..12].strip != "" and lines[line_count][13..20].strip != "" then
          ifrag = lines[line_count][0..12].strip.to_i
          @frag_statistics[ifrag - 1][:num_of_elec] = lines[line_count][13..20].strip
          @frag_statistics[ifrag - 1][:chain] = @@pdb_all_data.select{|i| i[:residue_num] == pdb_res_num[ifrag - 1]}[0][:chain]
          @frag_statistics[ifrag - 1][:final_pdb_residue_name] = @@pdb_all_data.select{|i| i[:residue_num] == pdb_res_num[ifrag - 1]}[0][:residue_name]
          @frag_statistics[ifrag - 1][:final_pdb_residue_num] = @@pdb_all_data.select{|i| i[:residue_num] == pdb_res_num[ifrag - 1]}[0][:residue_num].to_s
          lines[line_count][21..lines[line_count].size - 1].split(/\s* \s*/).each { |d|
            if d != "" then
              @frag_statistics[ifrag - 1][:atom_num] << d.tr("\r\n|\r|\n", "").to_i
              if (@abinitmp_header[:auto_fragmentation] == "OFF") then
                (amino_data, ile_leu_count) = define_abinitmp_amino_acid([@frag_statistics[ifrag - 1][:num_of_elec], @frag_statistics[ifrag - 1][:atom_num].size, 
                                                                         @frag_statistics[ifrag - 1][:ifrag]], ile_leu_count)
                @frag_statistics[ifrag - 1][:residue_name] = amino_data[:residue_name]
              end
            end
           }
        else
          lines[line_count][21..lines[line_count].size - 1].split(/\s* \s*/).each { |d|
            if d != "" then
              @frag_statistics[ifrag - 1][:atom_num] << d.tr("\r\n|\r|\n", "").to_i
              if (@abinitmp_header[:auto_fragmentation] == "OFF") then
                (amino_data, ile_leu_count) = define_abinitmp_amino_acid([@frag_statistics[ifrag - 1][:num_of_elec], @frag_statistics[ifrag - 1][:atom_num].size, 
                                                                         @frag_statistics[ifrag - 1][:ifrag]], ile_leu_count)
                @frag_statistics[ifrag - 1][:residue_name] = amino_data[:residue_name]
              end
            end
           }
        end
      end

      ### Number of AOs (atomic orbitals) each fragment
      if line_data[1] == "Frag." and line_data[2] ==  "Number" and line_data[4].tr("\r\n|\r|\n", "") ==  "AOs" then
        flag = "AO"
        line_count += 1
      elsif flag == "AO" and lines[line_count].strip.tr("\r\n|\r|\n", "") == "" then
        flag = ""
      end
      if flag == "AO" then
        @frag_statistics[lines[line_count][0..12].to_i - 1][:num_of_ao] = lines[line_count][13..lines[line_count].size - 1].tr("\r\n|\r|\n", "").to_i
      end

      ### Non-bonding interfragment interaction energy
      if lines[line_count].tr("\r\n|\r|\n", "") == "     ## Non-bonding interfragment interaction energy" then
        flag = "non-bonding ifie"
        line_count += 4
      elsif flag == "non-bonding ifie" and lines[line_count].strip.tr("\r\n|\r|\n", "") == "" then
        flag = ""
      end
      if flag == "non-bonding ifie" then
        ifrag = lines[line_count].split(/\s* \s*/)[1].to_i
        @frag_statistics[ifrag - 1][:non_bonding_ifie][0] = ("%.10f"%lines[line_count].split(/\s* \s*/)[2]).to_f
        @frag_statistics[ifrag - 1][:non_bonding_ifie][1] = ("%.6f"%lines[line_count].split(/\s* \s*/)[3]).to_f
        @frag_statistics[ifrag - 1][:non_bonding_ifie][2] = ("%.6f"%lines[line_count].split(/\s* \s*/)[4].tr("\r\n|\r|\n", "")).to_f
      end

      ### BSSE for non-bonding HF-IFIE or MP2-IFIE
      if lines[line_count].tr("\r\n|\r|\n", "") == "     ## BSSE for non-bonding MP2-IFIE" \
         or lines[line_count].tr("\r\n|\r|\n", "") == "     ## BSSE for non-bonding HF-IFIE" then
        flag = "bsse non-bonding ifie"
        line_count += 4
      elsif flag == "bsse non-bonding ifie" and lines[line_count].strip.tr("\r\n|\r|\n", "") == "" then
        flag = ""
      end
      if flag == "bsse non-bonding ifie" then
        ifrag = lines[line_count].split(/\s* \s*/)[1].to_i
        @frag_statistics[ifrag - 1][:bsse_non_bonding_ifie][0] = ("%.10f"%lines[line_count].split(/\s* \s*/)[2]).to_f
        @frag_statistics[ifrag - 1][:bsse_non_bonding_ifie][1] = ("%.6f"%lines[line_count].split(/\s* \s*/)[3]).to_f
        @frag_statistics[ifrag - 1][:bsse_non_bonding_ifie][2] = ("%.6f"%lines[line_count].split(/\s* \s*/)[4].tr("\r\n|\r|\n", "")).to_f
      end

      ### Interfragment interaction energy (IFIE) analysis
      if (@abinitmp_header[:method] == "HF") then ### HF calculation
        if lines[line_count].tr("\r\n|\r|\n", "") == "     ## HF-IFIE" then
          flag = "hf ifie"
          line_count += 5
          dist_file.write("\n Summary of dimer scf and mp2.\n")
          dist_file.write(" ========================\n")
          dist_file.write(" Label of Dimmer-ES approximation: \"yes or no\" of target for dimer-es\n")
          dist_file.write("  - T: True, F: False, B: BSSE (basis set superposition error)\n")
          dist_file.write(" ========================\n\n")
          dist_file.write(" # HF-IFIE\n\n")
          dist_file.write("           IJ-PAIR    DIST     DIMER-ES   HF-IFIE        HF-IFIE        HF-IFIE\n")
          dist_file.write("                      / A      APPROX.   / Hartree      / kcal/mol     / kJ/mol\n")
          dist_file.write("        --------------------------------------------------------------------------\n")
        elsif flag == "hf ifie" and lines[line_count].strip.tr("\r\n|\r|\n", "") == "" then
          flag = ""
        end
        if flag == "hf ifie" then
          if lines[line_count][18..29].strip == "0.000000" then ### dist == 0.0
            dist_file.write("%13s%5s%s"%[lines[line_count][13..17].strip, lines[line_count][0..12].strip, lines[line_count][18..(lines[line_count].size - 1)]])
          end
          data = {
            ifrag: 0,          ### ith-fragment of dimer between ith and jth: J => i
            jfrag: 0,          ### jth-fragment of dimer between ith and jth: I => j
            distance: 0.0,     ### Distance of dimer between ith and jth fragments [A]
            d_label: "",       ### Flag of DIMER-ES APPROX. (T or F)
            d_cp_label: "",    ### Flag of DIMER-ES APPROX. for BSSE (T or F, B)
            hf: 0.0,           ### HF-IFIE (HF') [hartree]
            hfkcal: 0.0,       ### HF-IFIE (HF') [kcal/mol]
            hfkj: 0.0,         ### HF-IFIE (HF') [kJ/mol]
            hf_cp: 0.0,        ### HF-IFIE (HF') BSSE [hartree]
            hf_cpkcal: 0.0,    ### HF-IFIE (HF') BSSE [kcal/mol]
            hf_cpkj: 0.0,      ### HF-IFIE (HF') BSSE [kJ/mol]
            dmp2: 0.0,         ### MP2-IFIE (dMP2) [hartree]
            dmp2kcal: 0.0,     ### MP2-IFIE (dMP2) [kcal/mol]
            dmp2kj: 0.0,       ### MP2-IFIE (dMP2) [kJ/mol]
            dmp2_cp: 0.0,      ### MP2-IFIE (dMP2) BSSE [hartree]
            dmp2_cpkcal: 0.0,  ### MP2-IFIE (dMP2) BSSE [kcal/mol]
            dmp2_cpkj: 0.0,    ### MP2-IFIE (dMP2) BSSE [kJ/mol]
            mp2: 0.0,          ### MP2 = HF-IFIE (HF') + MP2-IFIE (dMP2) [hartree]
            mp2kcal: 0.0,      ### MP2 [kcal/mol]
            mp2kj: 0.0,        ### MP2 [kJ/mol]
            mp2_cp: 0.0,       ### MP2 (BSSE) = (HF-IFIE (HF') BSSE) + (MP2-IFIE (dMP2) BSSE) [hartree]
            mp2_cpkcal: 0.0,   ### MP2 (BSSE) [kcal/mol]
            mp2_cpkj: 0.0,     ### MP2 (BSSE) [kJ/mol]
            pr_type1: 0.0,     ### PR-TYPE1 [hartree]
            pr_type1_cp: 0.0,  ### PR-TYPE1 (BSSE) [hartree]
            grimme: 0.0,       ### GRIMME [hartree]
            grimme_cp: 0.0,    ### GRIMME (BSSE) [hartree]
            jung: 0.0,         ### Jung (Head-Gordon) SCS energy [hartree]
            jung_cp: 0.0,      ### Jung (Head-Gordon) SCS energy (BSSE) [hartree]
            hill_scs: 0.0,     ### Hill SCS energy [hartree]
            hill_scs_cp: 0.0,  ### Hill SCS energy (BSSE) [hartree]
          }
          data[:ifrag] = lines[line_count][13..17].strip.to_i
          data[:jfrag] = lines[line_count][0..12].strip.to_i
          data[:distance] = ("%.6f"%lines[line_count][18..29].strip).to_f
          data[:d_label] = lines[line_count][30..33].strip
          data[:hf] = ("%.6f"%lines[line_count][34..49].strip).to_f
          data[:hfkcal] = ("%.6f"%lines[line_count][50..64].strip).to_f
          data[:hfkj] = ("%.6f"%lines[line_count][65..79].strip).to_f
          @ifie_energy << data
        end
        ### HF-BSSE (Basis Set Superposition Error)
        if @abinitmp_header[:cp_corr] == "ON" then
          if lines[line_count].tr("\r\n|\r|\n", "") == "     ## BSSE for HF-IFIE" then
            flag = "bsse hf ifie"
            line_count += 5
            dist_file.write("\n\n # BSSE for HF-IFIE\n\n")
            dist_file.write("           IJ-PAIR    DIST     DIMER-ES   HF-IFIE        HF-IFIE        HF-IFIE\n")
            dist_file.write("                      / A      APPROX.   / Hartree      / kcal/mol     / kJ/mol\n")
            dist_file.write("        --------------------------------------------------------------------------\n")
          elsif flag == "bsse hf ifie" and lines[line_count].strip.tr("\r\n|\r|\n", "") == "" then
            flag = ""
          end
          if flag == "bsse hf ifie" then
            if lines[line_count][18..29].strip == "0.000000" then ### dist == 0.0
              dist_file.write("%13s%5s%s"%[lines[line_count][13..17].strip, lines[line_count][0..12].strip, lines[line_count][18..(lines[line_count].size - 1)]])
            end
            @ifie_energy.select{|t| t[:ifrag] == lines[line_count][13..17].strip.to_i && t[:jfrag] == lines[line_count][0..12].strip.to_i}.each { |d|
              d[:d_cp_label] = lines[line_count][30..33].strip
              d[:hf_cp] = ("%.6f"%lines[line_count][34..49].strip).to_f
              d[:hf_cpkcal] = ("%.6f"%lines[line_count][50..64].strip).to_f
              d[:hf_cpkj] = ("%.6f"%lines[line_count][65..79].strip).to_f
            }
          end
        end
      elsif (@abinitmp_header[:method] == "MP2") then ### MP2 calculation
        if lines[line_count].tr("\r\n|\r|\n", "") == "     ## MP2-IFIE" then
          flag = "mp2 ifie"
          line_count += 5
          dist_file.write("\n Summary of dimer scf and mp2.\n")
          dist_file.write(" ========================\n")
          dist_file.write(" Label of Dimmer-ES approximation: \"yes or no\" of target for dimer-es\n")
          dist_file.write("  - T: True, F: False, B: BSSE (basis set superposition error)\n")
          dist_file.write(" ========================\n\n")
          dist_file.write(" # MP2-IFIE\n\n")
          dist_file.write("           IJ-PAIR    DIST     DIMER-ES   HF-IFIE    MP2-IFIE   PR-TYPE1   GRIMME     JUNG       HILL\n")
          dist_file.write("                      / A      APPROX.   / Hartree  / Hartree  / Hartree  / Hartree  / Hartree  / Hartree\n")
          dist_file.write("        ----------------------------------------------------------------------------------------------------\n")
        elsif flag == "mp2 ifie" and lines[line_count].strip.tr("\r\n|\r|\n", "") == "" then
          flag = ""
        end
        if flag == "mp2 ifie" then
          if lines[line_count][18..29].strip == "0.000000" then ### dist == 0.0
            dist_file.write("%13s%5s%s"%[lines[line_count][13..17].strip, lines[line_count][0..12].strip, lines[line_count][18..(lines[line_count].size - 1)]])
          end
          data = {
            ifrag: 0,          ### ith-fragment of dimer between ith and jth: J => i
            jfrag: 0,          ### jth-fragment of dimer between ith and jth: I => j
            distance: 0.0,     ### Distance of dimer between ith and jth fragments [A]
            d_label: "",       ### Flag of DIMER-ES APPROX. (T or F)
            d_cp_label: "",    ### Flag of DIMER-ES APPROX. for BSSE (T or F, B)
            hf: 0.0,           ### HF-IFIE (HF') [hartree]
            hfkcal: 0.0,       ### HF-IFIE (HF') [kcal/mol]
            hfkj: 0.0,         ### HF-IFIE (HF') [kJ/mol]
            hf_cp: 0.0,        ### HF-IFIE (HF') BSSE [hartree]
            hf_cpkcal: 0.0,    ### HF-IFIE (HF') BSSE [kcal/mol]
            hf_cpkj: 0.0,      ### HF-IFIE (HF') BSSE [kJ/mol]
            dmp2: 0.0,         ### MP2-IFIE (dMP2) [hartree]
            dmp2kcal: 0.0,     ### MP2-IFIE (dMP2) [kcal/mol]
            dmp2kj: 0.0,       ### MP2-IFIE (dMP2) [kJ/mol]
            dmp2_cp: 0.0,      ### MP2-IFIE (dMP2) BSSE [hartree]
            dmp2_cpkcal: 0.0,  ### MP2-IFIE (dMP2) BSSE [kcal/mol]
            dmp2_cpkj: 0.0,    ### MP2-IFIE (dMP2) BSSE [kJ/mol]
            mp2: 0.0,          ### MP2 = HF-IFIE (HF') + MP2-IFIE (dMP2) [hartree]
            mp2kcal: 0.0,      ### MP2 [kcal/mol]
            mp2kj: 0.0,        ### MP2 [kJ/mol]
            mp2_cp: 0.0,       ### MP2 (BSSE) = (HF-IFIE (HF') BSSE) + (MP2-IFIE (dMP2) BSSE) [hartree]
            mp2_cpkcal: 0.0,   ### MP2 (BSSE) [kcal/mol]
            mp2_cpkj: 0.0,     ### MP2 (BSSE) [kJ/mol]
            pr_type1: 0.0,     ### PR-TYPE1 [hartree]
            pr_type1_cp: 0.0,  ### PR-TYPE1 (BSSE) [hartree]
            grimme: 0.0,       ### GRIMME [hartree]
            grimme_cp: 0.0,    ### GRIMME (BSSE) [hartree]
            jung: 0.0,         ### Jung (Head-Gordon) SCS energy [hartree]
            jung_cp: 0.0,      ### Jung (Head-Gordon) SCS energy (BSSE) [hartree]
            hill_scs: 0.0,     ### Hill SCS energy [hartree]
            hill_scs_cp: 0.0,  ### Hill SCS energy (BSSE) [hartree]
          }
          data[:ifrag] = lines[line_count][13..17].strip.to_i
          data[:jfrag] = lines[line_count][0..12].strip.to_i
          data[:distance] = ("%.6f"%lines[line_count][18..29].strip).to_f
          data[:d_label] = lines[line_count][30..33].strip
          data[:hf] = ("%.6f"%lines[line_count][34..49].strip).to_f
          data[:hfkcal] = (BigDecimal(data[:hf].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
          data[:hfkj] = (BigDecimal(data[:hf].to_s) * BigDecimal($h2kjmol.to_s)).to_f
          data[:dmp2] = ("%.6f"%lines[line_count][50..60].strip).to_f
          data[:dmp2kcal] = (BigDecimal(data[:dmp2].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
          data[:dmp2kj] = (BigDecimal(data[:dmp2].to_s) * BigDecimal($h2kjmol.to_s)).to_f
          data[:mp2] = (BigDecimal(data[:hf].to_s) + BigDecimal(data[:dmp2].to_s)).to_f
          data[:mp2kcal] = (BigDecimal(data[:hfkcal].to_s) + BigDecimal(data[:dmp2kcal].to_s)).to_f
          data[:mp2kj] = (BigDecimal(data[:hfkj].to_s) + BigDecimal(data[:dmp2kj].to_s)).to_f
          data[:pr_type1] = ("%.6f"%lines[line_count][61..71].strip).to_f
          data[:grimme] = ("%.6f"%lines[line_count][72..82].strip).to_f
          data[:jung] = ("%.6f"%lines[line_count][83..93].strip).to_f
          data[:hill_scs] = ("%.6f"%lines[line_count][94..104].strip).to_f
          @ifie_energy << data
        end
        ### MP2-BSSE (Basis Set Superposition Error)
        if @abinitmp_header[:cp_corr] == "ON" then
          if lines[line_count].tr("\r\n|\r|\n", "") == "     ## BSSE for MP2-IFIE" then
            flag = "bsse mp2 ifie"
            line_count += 5
            dist_file.write("\n\n # BSSE for MP2-IFIE\n\n")
            dist_file.write("           IJ-PAIR    DIST     DIMER-ES   HF-IFIE    MP2-IFIE   PR-TYPE1   GRIMME     JUNG       HILL\n")
            dist_file.write("                      / A      APPROX.   / Hartree  / Hartree  / Hartree  / Hartree  / Hartree  / Hartree\n")
            dist_file.write("        ----------------------------------------------------------------------------------------------------\n")
          elsif flag == "bsse mp2 ifie" and lines[line_count].strip.tr("\r\n|\r|\n", "") == "" then
            flag = ""
          end
          if flag == "bsse mp2 ifie" then
            if lines[line_count][18..29].strip == "0.000000" then ### dist == 0.0
              dist_file.write("%13s%5s%s"%[lines[line_count][13..17].strip, lines[line_count][0..12].strip, lines[line_count][18..(lines[line_count].size - 1)]])
            end
            @ifie_energy.select{|t| t[:ifrag] == lines[line_count][13..17].strip.to_i && t[:jfrag] == lines[line_count][0..12].strip.to_i}.each { |d|
              d[:d_cp_label] = lines[line_count][30..33].strip
              d[:hf_cp] = ("%.6f"%lines[line_count][34..49].strip).to_f
              d[:hf_cpkcal] = (BigDecimal(data[:hf].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
              d[:hf_cpkj] = (BigDecimal(data[:hf].to_s) * BigDecimal($h2kjmol.to_s)).to_f
              d[:dmp2_cp] = ("%.6f"%lines[line_count][50..60].stri268005p).to_f
              d[:dmp2_cpkcal] = (BigDecimal(data[:dmp2].to_s) * BigDecimal($h2kcalmol.to_s)).to_f
              d[:dmp2_cpkj] = (BigDecimal(data[:dmp2].to_s) * BigDecimal($h2kjmol.to_s)).to_f
              d[:mp2_cp] = (BigDecimal(data[:hf].to_s) + BigDecimal(data[:dmp2].to_s)).to_f
              d[:mp2_cpkcal] = (BigDecimal(data[:hfkcal].to_s) + BigDecimal(data[:dmp2kcal].to_s)).to_f
              d[:mp2_cpkj] = (BigDecimal(data[:hfkj].to_s) + BigDecimal(data[:dmp2kj].to_s)).to_f
              d[:pr_type1_cp] = ("%.6f"%lines[line_count][61..71].strip).to_f
              d[:grimme_cp] = ("%.6f"%lines[line_count][72..82].strip).to_f
              d[:jung_cp] = ("%.6f"%lines[line_count][83..93].strip).to_f
              d[:hill_scs_cp] = ("%.6f"%lines[line_count][94..104].strip).to_f
            }
          end
        end
      end
      
      ### Pair Interaction Energy Decomposition Analysis (PIEDA)
      if (@abinitmp_header[:pieda] == "YES") then
        if lines[line_count].tr("\r\n|\r|\n", "") == "     ## PIEDA" then
          flag = "pieda"
          line_count += 5
=begin
          dist_file.write("\n Pair Interaction Energy Decomposition Analysis (PIEDA).\n")
          dist_file.write(" =========================================================\n")
          dist_file.write(" E(total) = E(es) + E(ex) + E(CT+mix) + E(di) [kcal/mol]\n")
          dist_file.write("   E(total):  PIE (pair interaction energy) [kcal/mol]\n")
          dist_file.write("   E(es):     Electrostatic energy [kcal/mol]\n")
          dist_file.write("   E(ex):     Exchange repulsion energy [kcal/mol]\n")
          dist_file.write("   E(CT+mix): Energy for charge transfer + MIX [kcal/mol]\n")
          dist_file.write("   E(di):     Dispersion energy [kcal/mol]\n\n")
          dist_file.write(" q(I=>J) is the charge transfer amount, printed as zero if not available.\n")
          dist_file.write(" Positive values correspond to I in IJ having extra negative charge.")
          dist_file.write(" =========================================================\n\n")
          dist_file.write(" ## PIEDA\n\n")
          dist_file.write("           IJ-PAIR       ES             EX             CT+mix         DI(MP2)        q(I=>J)  \n")
          dist_file.write("                         / kcal/mol     / kcal/mol     / kcal/mol     / kcal/mol     / e\n")
          dist_file.write("        --------------------------------------------------------------------------------------\n")
=end
        elsif flag == "pieda" and lines[line_count].strip.tr("\r\n|\r|\n", "") == "" then
          flag = ""
        end
        if flag == "pieda" then
          data = {
            ifrag: 0,           ### ith-fragment of dimer between ith and jth
            jfrag: 0,           ### jth-fragment of dimer between ith and jth
            e_total: 0.0,       ### PIE (pair interaction energy) [kcal/mol] 
                                ### E(total) = E(es) + E(ex) + E(ct+mix) + E(di), as of Oct. 25th, 2018.
            e_total_frag: [],
            e_es: 0.0,          ### Electrostatic energy [kcal/mol]
            e_es_frag: [],
            e_ex: 0.0,          ### Exchange repulsion energy [kcal/mol]
            e_ex_frag: [],
            e_ct_mix: 0.0,      ### Energy for charge transfer + MIX [kcal/mol]
            e_ct_mix_frag: [],
            e_disp: 0.0,        ### Dispersion energy [kcal/mol]
            e_disp_frag: [],
            g_sol: 0.0,         ### Solvation free energy [kcal/mol]
            g_sol_frag: [],
            q_i_j: 0.0,         ### Q(i->j): Charge transfer amount from ith- to jth-fragment [e]
            q_i_j_frag: [],
          }
          data[:ifrag] = lines[line_count][13..17].strip.to_i
          data[:jfrag] = lines[line_count][0..12].strip.to_i
          data[:e_es] = ("%.6f"%lines[line_count][18..32].strip).to_f
          data[:e_ex] = ("%.6f"%lines[line_count][33..47].strip).to_f
          data[:e_ct_mix] = ("%.6f"%lines[line_count][48..62].strip).to_f
          data[:e_disp] = ("%.6f"%lines[line_count][63..77].strip).to_f
          data[:e_i_j] = ("%.6f"%lines[line_count][78..92].strip).to_f
          data[:e_total] = (BigDecimal(data[:e_es].to_s) + BigDecimal(data[:e_ex].to_s) + BigDecimal(data[:e_ct_mix].to_s) + BigDecimal(data[:e_disp].to_s)).to_f
          @pieda_energy << data
        end
      end

      ### Mulliken atomic population (FMO2)
      if line_data[1] == "No." and line_data[2] ==  "Atom" and line_data[3] ==  "Atomic" and line_data[4] ==  "pop." then
        flag = "mulliken"
        line_count += 2
      elsif flag == "mulliken" and lines[line_count].strip.tr("\r\n|\r|\n", "") == "" then
        flag = ""
      end
      if flag == "mulliken" then
        data = {
          atom_num: 0,     ### No.: atom number
          atom_name: "",   ### Atom name
          atom_pop: 0.0,   ### Atomic population (FMO2)
          net_charge: 0.0, ### Net charge (FMO2): the arithmetic sum of positive and negative charges.
                           ### if atomic pop. (FMO2) of N atom is 7.846506, net charge is calculated by -0.846506 (= 7 - 7.846506).
        }
        data[:atom_num] = lines[line_count][0..12].strip.to_i
        data[:atom_name] = lines[line_count][13..16].strip
        data[:atom_pop] = ("%.6f"%lines[line_count][17..30].strip).to_f
        data[:net_charge] = ("%.6f"%lines[line_count][31..43].strip).to_f
#        sum_atom_pop = (BigDecimal(sum_atom_pop.to_s) + BigDecimal(data[:atom_pop].to_s)).to_f
        sum_net_charge = (BigDecimal(sum_net_charge.to_s) + BigDecimal(data[:net_charge].to_s)).to_f
        @mulliken_charge << data
      end

      ### FMO TOTAL ENERGY
      if lines[line_count].tr("\r\n|\r|\n", "") == "     ## FMO TOTAL ENERGY" then
        total_fmo_energy = []
        flag = "total energy"
        line_count += 4
      elsif lines[line_count].tr("\r\n|\r|\n", "") == "     ## TIME PROFILE" then
        flag = ""
        break  ### Finish to extract data from ABINIT-MP Out file
      end
      if flag == "total energy" then
        if (lines[line_count].strip != "") and (lines[line_count].include?("=")) then
          if split_namelist(lines[line_count]) != "" then
            total_fmo_energy << split_namelist(lines[line_count])
          end
        end
      end
      line_count += 1
    end
    @total_energy[:hf_nuclear_repulsion] = ("%.10f"%total_fmo_energy[0]).to_f
    @total_energy[:hf_electronic_energy] = ("%.10f"%total_fmo_energy[1]).to_f
    @total_energy[:hf_total_energy] = ("%.10f"%total_fmo_energy[2]).to_f
    if (@abinitmp_header[:method] == "MP2") then ### MP2 calculation
      @total_energy[:fmo2_mp2_e] = ("%.10f"%total_fmo_energy[3]).to_f
      @total_energy[:fmo2_mp2_electronic_energy] = ("%.10f"%total_fmo_energy[4]).to_f
      @total_energy[:fmo2_mp2_total_energy] = ("%.10f"%total_fmo_energy[5]).to_f
      @total_energy[:grimme_fmo2_mp2_e] = ("%.10f"%total_fmo_energy[6]).to_f
      @total_energy[:grimme_fmo2_mp2_electronic_energy] = ("%.10f"%total_fmo_energy[7]).to_f
      @total_energy[:grimme_fmo2_mp2_total_energy] = ("%.10f"%total_fmo_energy[8]).to_f
      @total_energy[:jung_fmo2_mp2_e] = ("%.10f"%total_fmo_energy[9]).to_f
      @total_energy[:jung_fmo2_mp2_electronic_energy] = ("%.10f"%total_fmo_energy[10]).to_f
      @total_energy[:jung_fmo2_mp2_total_energy] = ("%.10f"%total_fmo_energy[11]).to_f
      @total_energy[:hill_fmo2_mp2_e] = ("%.10f"%total_fmo_energy[12]).to_f
      @total_energy[:hille_fmo2_mp2_electronic_energy] = ("%.10f"%total_fmo_energy[13]).to_f
      @total_energy[:hill_fmo2_mp2_total_energy] = ("%.10f"%total_fmo_energy[14]).to_f
    end

    @@log.info "\n", "  Charge on your system (input): #{@abinitmp_header[:charge]}", "" , @@opts[:text]
    @@log.info "", "  Charge of molecule in your system (checked by ABINIT-MP): #{@frag_data[:charge_of_mol]}", "" , @@opts[:text]
#    @@log.info "", "   - Sum of atom population: #{sum_atom_pop}", "" , @@opts[:text]
    @@log.info "", "   - Sum of net charge:      #{sum_net_charge}\n", "" , @@opts[:text]
    Write_data.new.make_pdb_charge(@mulliken_charge, @@opts)
  end

  #*** Define residue data from ABINIT-MP Out file (Using manual fragmentation) using sum of electrons and sum of atoms ***#
  def define_abinitmp_amino_acid(data, ile_leu_count)
    ### data[0]: sum_ele, data[1]: sum_atoms, data[2]: ifragdefine_abinitmp_amino_acid(data, ile_leu_count)
    amino_aicds = [
      {residue_name: "XXX", one_letter: "X", sum_ele: 0, sum_atoms: 0, ifrag: 0, atom_num: [], ss: ""},   ### [0] is unknown amino acid name (= "XXX" or "X")
      {residue_name: "ALA", one_letter: "A", sum_ele: 38, sum_atoms: 10, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "CYS", one_letter: "C", sum_ele: 54, sum_atoms: 11, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "CYX SS", one_letter: "C", sum_ele: 106, sum_atoms: "20", ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "ASP", one_letter: "D", sum_ele: 60, sum_atoms: 12, ifrag: 0, atom_num: [], ss: ""}, ### ASP (COO^{-})
      {residue_name: "ASU", one_letter: "D", sum_ele: 61, sum_atoms: 13, ifrag: 0, atom_num: [], ss: ""}, ### ASU (COOH) = ASP
      {residue_name: "GLU", one_letter: "E", sum_ele: 68, sum_atoms: 15, ifrag: 0, atom_num: [], ss: ""}, ### GLU (COO^{-})
      {residue_name: "GLP", one_letter: "E", sum_ele: 69, sum_atoms: 16, ifrag: 0, atom_num: [], ss: ""}, ### GLU (COOH) = GLP
      {residue_name: "PHE", one_letter: "F", sum_ele: 78, sum_atoms: 20, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "GLY", one_letter: "G", sum_ele: 30, sum_atoms: 7, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "HIS", one_letter: "H", sum_ele: 72, sum_atoms: 17, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "HIP", one_letter: "H", sum_ele: 72, sum_atoms: 18, ifrag: 0, atom_num: [], ss: ""}, ### HIS with hydrogens on both nitrogens, this is positively charged
      {residue_name: "ILE", one_letter: "I", sum_ele: 62, sum_atoms: 19, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "LYS", one_letter: "K", sum_ele: 70, sum_atoms: 22, ifrag: 0, atom_num: [], ss: ""}, ### LYS (NH_{3}^{+})
      {residue_name: "LYY", one_letter: "K", sum_ele: 69, sum_atoms: 21, ifrag: 0, atom_num: [], ss: ""}, ### LYS (NH_{2}) = LYY
      {residue_name: "LEU", one_letter: "L", sum_ele: 62, sum_atoms: 19, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "MET", one_letter: "M", sum_ele: 70, sum_atoms: 17, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "ASN", one_letter: "N", sum_ele: 60, sum_atoms: 14, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "PRO", one_letter: "P", sum_ele: 52, sum_atoms: 14, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "GLN", one_letter: "Q", sum_ele: 68, sum_atoms: 17, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "ARG", one_letter: "R", sum_ele: 84, sum_atoms: 24, ifrag: 0, atom_num: [], ss: ""}, ### ARG (NH_{3}^{+})
      {residue_name: "ARR", one_letter: "R", sum_ele: 83, sum_atoms: 23, ifrag: 0, atom_num: [], ss: ""}, ### ARG (NH_{2}) = ARR
      {residue_name: "SER", one_letter: "S", sum_ele: 46, sum_atoms: 11, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "THR", one_letter: "T", sum_ele: 54, sum_atoms: 14, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "VAL", one_letter: "V", sum_ele: 54, sum_atoms: 16, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "TRP", one_letter: "W", sum_ele: 98, sum_atoms: 24, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "TYR", one_letter: "Y", sum_ele: 86, sum_atoms: 21, ifrag: 0, atom_num: [], ss: ""},
      {residue_name: "HOH", one_letter: "o", sum_ele: 10, sum_atoms: 3, ifrag: 0, atom_num: [], ss: ""},  ### H_{2}O = HOH, 1 letter code is defined "o"
      {residue_name: "Na+", one_letter: "n", sum_ele: 10, sum_atoms: 1, ifrag: 0, atom_num: [], ss: ""},  ### Na+, 1 letter code is defined "n"
      {residue_name: "Ca2+", one_letter: "c", sum_ele: 18, sum_atoms: 1, ifrag: 0, atom_num: [], ss: ""}, ### Ca2+, 1 letter code is defined "c"
      {residue_name: "Mg2+", one_letter: "m", sum_ele: 10, sum_atoms: 1, ifrag: 0, atom_num: [], ss: ""}, ### Mg2+, 1 letter code is defined "m"
      {residue_name: "Cl-", one_letter: "l", sum_ele: 18, sum_atoms: 1, ifrag: 0, atom_num: [], ss: ""},  ### Cl-, 1 letter code is defined "l"
     ]

    if data[0] == "62" and data[1] == "19" then  ### ILE, LEU
      amino_acid_name = PAICS.new.define_ile_leu(ile_leu_count)
      ile_leu_count += 1
      tmp = amino_aicds.select{|i| i[:residue_name] == amino_acid_name}[0].dup
      if amino_acid_name == "XXX" then
        tmp[:sum_ele] = data[0].to_i
        tmp[:sum_atoms] = data[1].to_i
        tmp[:ifrag] = data[2].to_i
        [tmp, ile_leu_count]
      else
        tmp[:ifrag] = data[2].to_i
        [tmp, ile_leu_count]
      end
    elsif amino_aicds.map{|i| i[:sum_ele] == data[0].to_i && i[:sum_atoms] == data[1].to_i}.include?(true) then
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ###
       ###   When ("same" sum of electrons) and ("same" sum of atoms), 
       ###   what to do with process in this condition ...
       ###   (ex). amino_aicds.select{|i| i[:sum_ele].to_i == 10 && i[:sum_atoms].to_i == 1}
       ###        Counter ions, and so on...
       ###
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
       ####################################################################################################
      tmp = amino_aicds.select{|i| i[:sum_ele] == data[0].to_i && i[:sum_atoms] == data[1].to_i}[0].dup
      tmp[:ifrag] = data[2].to_i
      [tmp, ile_leu_count]
    else ### false (XXX)
      tmp = amino_aicds.select{|i| i[:sum_ele] == 0 && i[:sum_atoms] == 0}[0].dup
      tmp[:sum_ele] = data[0].to_i
      tmp[:sum_atoms] = data[1].to_i
      tmp[:ifrag] = data[2].to_i
      [tmp, ile_leu_count]
    end
  end

  #*** Calculate the average distance and energy data "every particles (ligand)" ***#
  def cal_ave_data
    i = 1
    if !(@@flags[:ligand_num]) then ### Without -n option
      if @frag_data[:particle] > 1 then
        while (i < @frag_data[:frag_num][0]) do
          j = 0
          data = {
            ifrag: 0,             ### ith-fragment of dimer between ith and jth: J => i
            jfrag: 0,             ### jth-fragment of dimer between ith and jth: I => j
            distance: 0.0,        ### Distance of dimer between ith and jth fragments [A]
            distance_frag: [],
            hf: 0.0,              ### HF-IFIE (HF') [hartree]
            hf_frag: [],
            hfkcal: 0.0,          ### HF-IFIE (HF') [kcal/mol]
            hfkcal_frag: [],
            hf_cp: 0.0,           ### HF-IFIE (HF') BSSE [hartree]
            hf_cp_frag: [],
            hf_cpkcal: 0.0,       ### HF-IFIE (HF') BSSE [kcal/mol]
            hf_cpkcal_frag: [],
            dmp2: 0.0,            ### MP2-IFIE (dMP2) [hartree]
            dmp2_frag: [],
            dmp2kcal: 0.0,        ### MP2-IFIE (dMP2) [kcal/mol]
            dmp2kcal_frag: [],
            dmp2_cp: 0.0,         ### MP2-IFIE (dMP2) BSSE [hartree]
            dmp2_cp_frag: [],
            dmp2_cpkcal: 0.0,     ### MP2-IFIE (dMP2) BSSE [kcal/mol]
            dmp2_cpkcal_frag: [],
            mp2: 0.0,             ### MP2 = HF-IFIE (HF') + MP2-IFIE (dMP2) [hartree]
            mp2_frag: [],
            mp2kcal: 0.0,         ### MP2 [kcal/mol]
            mp2kcal_frag: [],
            mp2_cp: 0.0,          ### MP2 (BSSE) = (HF-IFIE (HF') BSSE) + (MP2-IFIE (dMP2) BSSE) [hartree]
            mp2_cp_frag: [],
            mp2_cpkcal: 0.0,      ### MP2 (BSSE) [kcal/mol]
            mp2_cpkcal_frag: [],
            pr_type1: 0.0,        ### PR-TYPE1 [hartree]
            pr_type1_frag: [],
            pr_type1_cp: 0.0,     ### PR-TYPE1 (BSSE) [hartree]
            pr_type1_cp_frag: [],
            grimme: 0.0,          ### GRIMME [hartree]
            grimme_frag: [],
            grimme_cp: 0.0,       ### GRIMME (BSSE) [hartree]
            grimme_cp_frag: [],
            jung: 0.0,            ### Jung (Head-Gordon) SCS energy [hartree]
            jung_frag: [],
            jung_cp: 0.0,         ### Jung (Head-Gordon) SCS energy (BSSE) [hartree]
            jung_cp_frag: [],
            hill_scs: 0.0,        ### Hill SCS energy [hartree]
            hill_scs_frag: [],
            hill_scs_cp: 0.0,     ### Hill SCS energy (BSSE) [hartree]
            hill_scs_cp_frag: [],
          }
          pieda_data = {
            ifrag: 0,           ### ith-fragment of dimer between ith and jth
            jfrag: 0,           ### jth-fragment of dimer between ith and jth
            e_total: 0.0,       ### PIE (pair interaction energy) [kcal/mol] 
                                ### E(total) = E(es) + E(ex) + E(ct+mix) + E(di), as of Oct. 25th, 2018.
            e_total_frag: [],
            e_es: 0.0,          ### Electrostatic energy [kcal/mol]
            e_es_frag: [],
            e_ex: 0.0,          ### Exchange repulsion energy [kcal/mol]
            e_ex_frag: [],
            e_ct_mix: 0.0,      ### Energy for charge transfer + MIX [kcal/mol]
            e_ct_mix_frag: [],
            e_disp: 0.0,        ### Dispersion energy [kcal/mol]
            e_disp_frag: [],
            g_sol: 0.0,         ### Solvation free energy [kcal/mol]
            g_sol_frag: [],
            q_i_j: 0.0,         ### Q(i->j): Charge transfer amount from ith- to jth-fragment [e]
            q_i_j_frag: [],
          }
          @frag_data[:frag_num].each { |f|
            @ifie_energy.select{|t| t[:ifrag] == i && t[:jfrag] == f}.each { |d|
              data[:distance] = (BigDecimal(data[:distance].to_s) + BigDecimal(d[:distance].to_s)).to_f
              data[:distance_frag][j] = d[:distance]
              data[:hf] = (BigDecimal(data[:hf].to_s) + BigDecimal(d[:hf].to_s)).to_f
              data[:hf_frag][j] = d[:hf]
              data[:hfkcal] = (BigDecimal(data[:hfkcal].to_s) + BigDecimal(d[:hfkcal].to_s)).to_f
              data[:hfkcal_frag][j] = d[:hfkcal]
              data[:hf_cp] = (BigDecimal(data[:hf_cp].to_s) + BigDecimal(d[:hf_cp].to_s)).to_f
              data[:hf_cp_frag][j] = d[:hf_cp]
              data[:hf_cpkcal] = (BigDecimal(data[:hf_cpkcal].to_s) + BigDecimal(d[:hf_cpkcal].to_s)).to_f
              data[:hf_cpkcal_frag][j] = d[:hf_cpkcal]
              data[:dmp2] = (BigDecimal(data[:dmp2].to_s) + BigDecimal(d[:dmp2].to_s)).to_f
              data[:dmp2_frag][j] = d[:dmp2]
              data[:dmp2kcal] = (BigDecimal(data[:dmp2kcal].to_s) + BigDecimal(d[:dmp2kcal].to_s)).to_f
              data[:dmp2kcal_frag][j] = d[:dmp2kcal]
              data[:dmp2_cp] = (BigDecimal(data[:dmp2_cp].to_s) + BigDecimal(d[:dmp2_cp].to_s)).to_f
              data[:dmp2_cp_frag][j] = d[:dmp2_cp]
              data[:dmp2_cpkcal] = (BigDecimal(data[:dmp2_cpkcal].to_s) + BigDecimal(d[:dmp2_cpkcal].to_s)).to_f
              data[:dmp2_cpkcal_frag][j] = d[:dmp2_cp_kcal]
              data[:mp2] = (BigDecimal(data[:mp2].to_s) + BigDecimal(d[:mp2].to_s)).to_f
              data[:mp2_frag][j] = d[:mp2]
              data[:mp2kcal] = (BigDecimal(data[:mp2kcal].to_s) + BigDecimal(d[:mp2kcal].to_s)).to_f
              data[:mp2kcal_frag][j] = d[:mp2kcal]
              data[:mp2_cp] = (BigDecimal(data[:mp2_cp].to_s) + BigDecimal(d[:mp2_cp].to_s)).to_f
              data[:mp2_cp_frag][j] = d[:mp2_cp]
              data[:mp2_cpkcal] = (BigDecimal(data[:mp2_cpkcal].to_s) + BigDecimal(d[:mp2_cpkcal].to_s)).to_f
              data[:mp2_cpkcal_frag][j] = d[:mp2_cpkcal]
              data[:pr_type1] = (BigDecimal(data[:pr_type1].to_s) + BigDecimal(d[:pr_type1].to_s)).to_f
              data[:pr_type1_frag][j] = d[:pr_type1]
              data[:pr_type1_cp] = (BigDecimal(data[:pr_type1_cp].to_s) + BigDecimal(d[:pr_type1_cp].to_s)).to_f
              data[:pr_type1_cp_frag][j] = d[:pr_type1_cp]
              data[:grimme] = (BigDecimal(data[:grimme].to_s) + BigDecimal(d[:grimme].to_s)).to_f
              data[:grimme_frag][j] = d[:grimme]
              data[:grimme_cp] = (BigDecimal(data[:grimme_cp].to_s) + BigDecimal(d[:grimme_cp].to_s)).to_f
              data[:grimme_cp_frag][j] = d[:grimme_cp]
              data[:jung] = (BigDecimal(data[:jung].to_s) + BigDecimal(d[:jung].to_s)).to_f
              data[:jung_frag][j] = d[:jung]
              data[:jung_cp] = (BigDecimal(data[:jung_cp].to_s) + BigDecimal(d[:jung_cp].to_s)).to_f
              data[:jung_cp_frag][j] = d[:jung_cp]
              data[:hill_scs] = (BigDecimal(data[:hill_scs].to_s) + BigDecimal(d[:hill_scs].to_s)).to_f
              data[:hill_scs_frag][j] = d[:hill_scs]
              data[:hill_scs_cp] = (BigDecimal(data[:hill_scs_cp].to_s) + BigDecimal(d[:hill_scs_cp].to_s)).to_f
              data[:hill_scs_cp_frag][j] = d[:hill_scs_cp]
              j += 1
            }
            @pieda_energy.select{|t| t[:ifrag] == i && t[:jfrag] == f}.each { |d|
              data[:e_total] = (BigDecimal(data[:e_total].to_s) + BigDecimal(d[:e_total].to_s)).to_f
              data[:e_total_frag][j - 1] = d[:e_total]
              data[:e_es] = (BigDecimal(data[:e_es].to_s) + BigDecimal(d[:e_es].to_s)).to_f
              data[:e_es_frag][j - 1] = d[:e_es]
              data[:e_ex] = (BigDecimal(data[:e_ex].to_s) + BigDecimal(d[:e_ex].to_s)).to_f
              data[:e_ex_frag][j - 1] = d[:e_ex]
              data[:e_ct_mix] = (BigDecimal(data[:e_ct_mix].to_s) + BigDecimal(d[:e_ct_mix].to_s)).to_f
              data[:e_ct_mix_frag][j - 1] = d[:e_ct_mix]
              data[:e_disp] = (BigDecimal(data[:e_disp].to_s) + BigDecimal(d[:e_disp].to_s)).to_f
              data[:e_disp_frag][j - 1] = d[:e_disp]
              data[:g_sol] = (BigDecimal(data[:g_sol].to_s) + BigDecimal(d[:g_sol].to_s)).to_f
              data[:_frag][j - 1] = d[:g_sol]
              data[:q_i_j] = (BigDecimal(data[:q_i_j].to_s) + BigDecimal(d[:q_i_j].to_s)).to_f
              data[:q_i_j_frag][j - 1] = d[:q_i_j]
            }
          }
          data[:ifrag] = i
#          data[:jfrag] = "target"
          data[:jfrag] = @frag_data[:frag_num][0]
          data[:distance] /= @frag_data[:particle]
          pieda_data[:ifrag] = i
          pieda_data[:jfrag] = @frag_data[:frag_num][0]
          @ave_data << data
          @ave_pieda_data << pieda_data
          i += 1
        end
      elsif (@frag_data[:particle] == 1) then
        if (@frag_data[:max] == @ifie_energy.size) then
          @ave_data = @energy_data.dup
        else ### If data is All-pairs mode and opts[:interaction] == 1 (Ligand mode)
          if (@frag_data[:frag_num][0].to_i < @frag_data[:max]) then
            while (i <= @frag_data[:max]) do
              data = {
                ifrag: 0,          ### ith-fragment of dimer between ith and jth: J => i
                jfrag: 0,          ### jth-fragment of dimer between ith and jth: I => j
                distance: 0.0,     ### Distance of dimer between ith and jth fragments [A]
                hf: 0.0,           ### HF-IFIE (HF') [hartree]
                hfkcal: 0.0,       ### HF-IFIE (HF') [kcal/mol]
                hf_cp: 0.0,        ### HF-IFIE (HF') BSSE [hartree]
                hf_cpkcal: 0.0,    ### HF-IFIE (HF') BSSE [kcal/mol]
                dmp2: 0.0,         ### MP2-IFIE (dMP2) [hartree]
                dmp2kcal: 0.0,     ### MP2-IFIE (dMP2) [kcal/mol]
                dmp2_cp: 0.0,      ### MP2-IFIE (dMP2) BSSE [hartree]
                dmp2_cpkcal: 0.0,  ### MP2-IFIE (dMP2) BSSE [kcal/mol]
                mp2: 0.0,          ### MP2 = HF-IFIE (HF') + MP2-IFIE (dMP2) [hartree]
                mp2kcal: 0.0,      ### MP2 [kcal/mol]
                mp2_cp: 0.0,       ### MP2 (BSSE) = (HF-IFIE (HF') BSSE) + (MP2-IFIE (dMP2) BSSE) [hartree]
                mp2_cpkcal: 0.0,   ### MP2 (BSSE) [kcal/mol]
                pr_type1: 0.0,     ### PR-TYPE1 [hartree]
                pr_type1_cp: 0.0,  ### PR-TYPE1 (BSSE) [hartree]
                grimme: 0.0,       ### GRIMME [hartree]
                grimme_cp: 0.0,    ### GRIMME (BSSE) [hartree]
                jung: 0.0,         ### Jung (Head-Gordon) SCS energy [hartree]
                jung_cp: 0.0,      ### Jung (Head-Gordon) SCS energy (BSSE) [hartree]
                hill_scs: 0.0,     ### Hill SCS energy [hartree]
                hill_scs_cp: 0.0,  ### Hill SCS energy (BSSE) [hartree]
              }
              pieda_data = {
                ifrag: 0,           ### ith-fragment of dimer between ith and jth
                jfrag: 0,           ### jth-fragment of dimer between ith and jth
                e_total: 0.0,       ### PIE (pair interaction energy) [kcal/mol] 
                                    ### E(total) = E(es) + E(ex) + E(ct+mix) + E(di), as of Oct. 25th, 2018.
                e_es: 0.0,          ### Electrostatic energy [kcal/mol]
                e_ex: 0.0,          ### Exchange repulsion energy [kcal/mol]
                e_ct_mix: 0.0,      ### Energy for charge transfer + MIX [kcal/mol]
                e_disp: 0.0,        ### Dispersion energy [kcal/mol]
                g_sol: 0.0,         ### Solvation free energy [kcal/mol]
                q_i_j: 0.0,         ### Q(i->j): Charge transfer amount from ith- to jth-fragment [e]
              }
              @ifie_energy.select{|t| t[:ifrag] == i && t[:jfrag] == @frag_data[:frag_num][0]}.each { |d|
                data[:ifrag] = i
                data[:jfrag] = @frag_data[:frag_num][0]
                data[:distance] = d[:distance]
                data[:hf] = d[:hf]
                data[:hfkcal] = d[:hfkcal]
                data[:hf_cp] = d[:hf_cp]
                data[:hf_cpkcal] = d[:hf_cpkcal]
                data[:dmp2] = d[:dmp2]
                data[:dmp2kcal] = d[:dmp2kcal]
                data[:dmp2_cp] = d[:dmp2_cp]
                data[:dmp2_cpkcal] = d[:dmp2_cpkcal]
                data[:mp2] = d[:mp2]
                data[:mp2kcal] = d[:mp2kcal]
                data[:mp2_cp] = d[:mp2_cp]
                data[:mp2_cpkcal] = d[:mp2_cpkcal]
                data[:pr_type1] = d[:pr_type1]
                data[:pr_type1_cp] = d[:pr_type1_cp]
                data[:grimme] = d[:grimme]
                data[:grimme_cp] = d[:grimme_cp]
                data[:jung] = d[:jung]
                data[:jung_cp] = d[:jung_cp]
                data[:hill_scs] = d[:hill_scs]
                data[:hill_scs_cp] = d[:hill_scs_cp]
              }
              @pieda_energy.select{|t| t[:ifrag] == i && t[:jfrag] == @frag_data[:frag_num][0]}.each { |d|
                pieda_data[:ifrag] = i
                pieda_data[:jfrag] = @frag_data[:frag_num][0]
                pieda_data[:e_total] = d[:e_total]
                pieda_data[:e_es] = d[:e_es]
                pieda_data[:e_ex] = d[:e_ex]
                pieda_data[:e_ct_mix] = d[:e_ct_mix]
                pieda_data[:e_disp] = d[:e_disp]
                pieda_data[:g_sol] = d[:g_sol]
                pieda_data[:q_i_j] = d[:q_i_j]
              }
              if !(i == @frag_data[:frag_num][0].to_i) then
                @ave_data << data
                @ave_pieda_data << pieda_data
              end
              i += 1
            end
          elsif (@frag_data[:frag_num][0] == @frag_data[:max]) then
            while (i < @frag_data[:max]) do
              data = {
                ifrag: 0,          ### ith-fragment of dimer between ith and jth: J => i
                jfrag: 0,          ### jth-fragment of dimer between ith and jth: I => j
                distance: 0.0,     ### Distance of dimer between ith and jth fragments [A]
                hf: 0.0,           ### HF-IFIE (HF') [hartree]
                hfkcal: 0.0,       ### HF-IFIE (HF') [kcal/mol]
                hf_cp: 0.0,        ### HF-IFIE (HF') BSSE [hartree]
                hf_cpkcal: 0.0,    ### HF-IFIE (HF') BSSE [kcal/mol]
                dmp2: 0.0,         ### MP2-IFIE (dMP2) [hartree]
                dmp2kcal: 0.0,     ### MP2-IFIE (dMP2) [kcal/mol]
                dmp2_cp: 0.0,      ### MP2-IFIE (dMP2) BSSE [hartree]
                dmp2_cpkcal: 0.0,  ### MP2-IFIE (dMP2) BSSE [kcal/mol]
                mp2: 0.0,          ### MP2 = HF-IFIE (HF') + MP2-IFIE (dMP2) [hartree]
                mp2kcal: 0.0,      ### MP2 [kcal/mol]
                mp2_cp: 0.0,       ### MP2 (BSSE) = (HF-IFIE (HF') BSSE) + (MP2-IFIE (dMP2) BSSE) [hartree]
                mp2_cpkcal: 0.0,   ### MP2 (BSSE) [kcal/mol]
                pr_type1: 0.0,     ### PR-TYPE1 [hartree]
                pr_type1_cp: 0.0,  ### PR-TYPE1 (BSSE) [hartree]
                grimme: 0.0,       ### GRIMME [hartree]
                grimme_cp: 0.0,    ### GRIMME (BSSE) [hartree]
                jung: 0.0,         ### Jung (Head-Gordon) SCS energy [hartree]
                jung_cp: 0.0,      ### Jung (Head-Gordon) SCS energy (BSSE) [hartree]
                hill_scs: 0.0,     ### Hill SCS energy [hartree]
                hill_scs_cp: 0.0,  ### Hill SCS energy (BSSE) [hartree]
              }
              pieda_data = {
                ifrag: 0,           ### ith-fragment of dimer between ith and jth
                jfrag: 0,           ### jth-fragment of dimer between ith and jth
                e_total: 0.0,       ### PIE (pair interaction energy) [kcal/mol] 
                                    ### E(total) = E(es) + E(ex) + E(ct+mix) + E(di), as of Oct. 25th, 2018.
                e_es: 0.0,          ### Electrostatic energy [kcal/mol]
                e_ex: 0.0,          ### Exchange repulsion energy [kcal/mol]
                e_ct_mix: 0.0,      ### Energy for charge transfer + MIX [kcal/mol]
                e_disp: 0.0,        ### Dispersion energy [kcal/mol]
                g_sol: 0.0,         ### Solvation free energy [kcal/mol]
                q_i_j: 0.0,         ### Q(i->j): Charge transfer amount from ith- to jth-fragment [e]
              }
              @ifie_energy.select{|t| t[:ifrag] == i && t[:jfrag] == @frag_data[:frag_num][0]}.each { |d|
                data[:ifrag] = i
                data[:jfrag] = @frag_data[:frag_num][0]
                data[:distance] = d[:distance]
                data[:hf] = d[:hf]
                data[:hfkcal] = d[:hfkcal]
                data[:hf_cp] = d[:hf_cp]
                data[:hf_cpkcal] = d[:hf_cpkcal]
                data[:dmp2] = d[:dmp2]
                data[:dmp2kcal] = d[:dmp2kcal]
                data[:dmp2_cp] = d[:dmp2_cp]
                data[:dmp2_cpkcal] = d[:dmp2_cpkcal]
                data[:mp2] = d[:mp2]
                data[:mp2kcal] = d[:mp2kcal]
                data[:mp2_cp] = d[:mp2_cp]
                data[:mp2_cpkcal] = d[:mp2_cpkcal]
                data[:pr_type1] = d[:pr_type1]
                data[:pr_type1_cp] = d[:pr_type1_cp]
                data[:grimme] = d[:grimme]
                data[:grimme_cp] = d[:grimme_cp]
                data[:jung] = d[:jung]
                data[:jung_cp] = d[:jung_cp]
                data[:hill_scs] = d[:hill_scs]
                data[:hill_scs_cp] = d[:hill_scs_cp]
              }
              @pieda_energy.select{|t| t[:ifrag] == i && t[:jfrag] == @frag_data[:frag_num][0]}.each { |d|
                pieda_data[:ifrag] = i
                pieda_data[:jfrag] = @frag_data[:frag_num][0]
                pieda_data[:e_total] = d[:e_total]
                pieda_data[:e_es] = d[:e_es]
                pieda_data[:e_ex] = d[:e_ex]
                pieda_data[:e_ct_mix] = d[:e_ct_mix]
                pieda_data[:e_disp] = d[:e_disp]
                pieda_data[:g_sol] = d[:g_sol]
                pieda_data[:q_i_j] = d[:q_i_j]
              }
              @ave_data << data
              @ave_pieda_data << pieda_data
              i += 1
            end
          end
        end
      end
    else ### With -n option
      while (i <= @frag_data[:max]) do
        if !(i == @@opts[:ligand_num]) then
          data = {
            ifrag: 0,          ### ith-fragment of dimer between ith and jth: J => i
            jfrag: 0,          ### jth-fragment of dimer between ith and jth: I => j
            distance: 0.0,     ### Distance of dimer between ith and jth fragments [A]
            hf: 0.0,           ### HF-IFIE (HF') [hartree]
            hfkcal: 0.0,       ### HF-IFIE (HF') [kcal/mol]
            hf_cp: 0.0,        ### HF-IFIE (HF') BSSE [hartree]
            hf_cpkcal: 0.0,    ### HF-IFIE (HF') BSSE [kcal/mol]
            dmp2: 0.0,         ### MP2-IFIE (dMP2) [hartree]
            dmp2kcal: 0.0,     ### MP2-IFIE (dMP2) [kcal/mol]
            dmp2_cp: 0.0,      ### MP2-IFIE (dMP2) BSSE [hartree]
            dmp2_cpkcal: 0.0,  ### MP2-IFIE (dMP2) BSSE [kcal/mol]
            mp2: 0.0,          ### MP2 = HF-IFIE (HF') + MP2-IFIE (dMP2) [hartree]
            mp2kcal: 0.0,      ### MP2 [kcal/mol]
            mp2_cp: 0.0,       ### MP2 (BSSE) = (HF-IFIE (HF') BSSE) + (MP2-IFIE (dMP2) BSSE) [hartree]
            mp2_cpkcal: 0.0,   ### MP2 (BSSE) [kcal/mol]
            pr_type1: 0.0,     ### PR-TYPE1 [hartree]
            pr_type1_cp: 0.0,  ### PR-TYPE1 (BSSE) [hartree]
            grimme: 0.0,       ### GRIMME [hartree]
            grimme_cp: 0.0,    ### GRIMME (BSSE) [hartree]
            jung: 0.0,         ### Jung (Head-Gordon) SCS energy [hartree]
            jung_cp: 0.0,      ### Jung (Head-Gordon) SCS energy (BSSE) [hartree]
            hill_scs: 0.0,     ### Hill SCS energy [hartree]
            hill_scs_cp: 0.0,  ### Hill SCS energy (BSSE) [hartree]
          }
          pieda_data = {
            ifrag: 0,           ### ith-fragment of dimer between ith and jth
            jfrag: 0,           ### jth-fragment of dimer between ith and jth
            e_total: 0.0,       ### PIE (pair interaction energy) [kcal/mol] 
                                ### E(total) = E(es) + E(ex) + E(ct+mix) + E(di), as of Oct. 25th, 2018.
            e_es: 0.0,          ### Electrostatic energy [kcal/mol]
            e_ex: 0.0,          ### Exchange repulsion energy [kcal/mol]
            e_ct_mix: 0.0,      ### Energy for charge transfer + MIX [kcal/mol]
            e_disp: 0.0,        ### Dispersion energy [kcal/mol]
            g_sol: 0.0,         ### Solvation free energy [kcal/mol]
            q_i_j: 0.0,         ### Q(i->j): Charge transfer amount from ith- to jth-fragment [e]
          }
        end
        if (i < @@opts[:ligand_num]) then
          @ifie_energy.select{|t| t[:ifrag] == i && t[:jfrag] == @@opts[:ligand_num]}.each { |d|
            data[:ifrag] = i
            data[:jfrag] = @@opts[:ligand_num]
            data[:distance] = d[:distance]
            data[:hf] = d[:hf]
            data[:hfkcal] = d[:hfkcal]
            data[:hf_cp] = d[:hf_cp]
            data[:hf_cpkcal] = d[:hf_cpkcal]
            data[:dmp2] = d[:dmp2]
            data[:dmp2kcal] = d[:dmp2kcal]
            data[:dmp2_cp] = d[:dmp2_cp]
            data[:dmp2_cpkcal] = d[:dmp2_cpkcal]
            data[:mp2] = d[:mp2]
            data[:mp2kcal] = d[:mp2kcal]
            data[:mp2_cp] = d[:mp2_cp]
            data[:mp2_cpkcal] = d[:mp2_cpkcal]
            data[:pr_type1] = d[:pr_type1]
            data[:pr_type1_cp] = d[:pr_type1_cp]
            data[:grimme] = d[:grimme]
            data[:grimme_cp] = d[:grimme_cp]
            data[:jung] = d[:jung]
            data[:jung_cp] = d[:jung_cp]
            data[:hill_scs] = d[:hill_scs]
            data[:hill_scs_cp] = d[:hill_scs_cp]
           }
          @pieda_energy.select{|t| t[:ifrag] == i && t[:jfrag] == @@opts[:ligand_num]}.each { |d|
            pieda_data[:ifrag] = i
            pieda_data[:jfrag] = @@opts[:ligand_num]
            pieda_data[:e_total] = d[:e_total]
            pieda_data[:e_es] = d[:e_es]
            pieda_data[:e_ex] = d[:e_ex]
            pieda_data[:e_ct_mix] = d[:e_ct_mix]
            pieda_data[:e_disp] = d[:e_disp]
            pieda_data[:g_sol] = d[:g_sol]
            pieda_data[:q_i_j] = d[:q_i_j]
          }
        elsif (i > @@opts[:ligand_num]) then
          @ifie_energy.select{|t| t[:ifrag] == @@opts[:ligand_num] && t[:jfrag] == i}.each { |d|
            data[:ifrag] = i
            data[:jfrag] = @@opts[:ligand_num]
            data[:distance] = d[:distance]
            data[:hf] = d[:hf]
            data[:hfkcal] = d[:hfkcal]
            data[:hf_cp] = d[:hf_cp]
            data[:hf_cpkcal] = d[:hf_cpkcal]
            data[:dmp2] = d[:dmp2]
            data[:dmp2kcal] = d[:dmp2kcal]
            data[:dmp2_cp] = d[:dmp2_cp]
            data[:dmp2_cpkcal] = d[:dmp2_cpkcal]
            data[:mp2] = d[:mp2]
            data[:mp2kcal] = d[:mp2kcal]
            data[:mp2_cp] = d[:mp2_cp]
            data[:mp2_cpkcal] = d[:mp2_cpkcal]
            data[:pr_type1] = d[:pr_type1]
            data[:pr_type1_cp] = d[:pr_type1_cp]
            data[:grimme] = d[:grimme]
            data[:grimme_cp] = d[:grimme_cp]
            data[:jung] = d[:jung]
            data[:jung_cp] = d[:jung_cp]
            data[:hill_scs] = d[:hill_scs]
            data[:hill_scs_cp] = d[:hill_scs_cp]
           }
          @pieda_energy.select{|t| t[:ifrag] == @@opts[:ligand_num] && t[:jfrag] == i}.each { |d|
            pieda_data[:ifrag] = i
            pieda_data[:jfrag] = @@opts[:ligand_num]
            pieda_data[:e_total] = d[:e_total]
            pieda_data[:e_es] = d[:e_es]
            pieda_data[:e_ex] = d[:e_ex]
            pieda_data[:e_ct_mix] = d[:e_ct_mix]
            pieda_data[:e_disp] = d[:e_disp]
            pieda_data[:g_sol] = d[:g_sol]
            pieda_data[:q_i_j] = d[:q_i_j]
          }
        end
        @ave_data << data
        @ave_pieda_data << pieda_data
        i += 1
      end
    end
  end

  #*** Make data line for 1-dimensional table (Selected-pairs mode) from ABINIT-MP Out file ***#
  def abinitmp_selectedpairs_output
#    function_name = "abinitmp_selectedpairs_output"
    i = 0

    ### Decide target number of fragments (Ligands)
    if !(@@flags[:ligand_num]) then
      if @frag_data[:particle] == 1 then
        target = @frag_data[:frag_num][0].to_s
      else
#        target = "target"
        target = @frag_data[:frag_num][0].to_s
      end
    else
      target = @@opts[:ligand_num].to_s
    end

    @@log.info "\n", "Process: Write all energy data at one-dimensional table", "", @@opts[:text]

    if (@@opts[:abinitmp] == 1) then ### IFIE
      if @@opts[:mode] == 1 then ### HF
        @@log.info "", "Process: Write the HF (a.u.) or HF [kcal/mol]", "\n", @@opts[:text]
        write_line = "-" * 135 + "\n"
        data_txt_label = "   ij-frag   | %11s | %15s | %5s | %14s | %8s | %15s | % 9s  | % 20s |\n"%["Amino Acid" , "Amino Acid(PDB)", "Chain", 
                         "Residue Number".center(14), "S-S bond", "Distance [A]".center(15), "E(ij)^HF", "E(ij)^HF [kcal/mol]"]
        data_csv_label = ",,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n"%["Number", "Fragment Number", "Amino Acid" , "Amino Acid(PDB)", "Chain", 
                         "Residue Number", "S-S bond", "Distance", "E(ij)^HF", "E(ij)^HF [kcal/mol]"]
      elsif @@opts[:mode] == 2 then ### dMP2
        @@log.info "", "Process: Write the dMP2 (a.u.) or dMP2 [kcal/mol]", "\n", @@opts[:text]
        write_line = "-" * 150 + "\n"
        data_txt_label = "   ij-frag   | %11s | %15s | %5s | %14s | %8s | %15s | % 9s  | % 10s | %21s |\n"%["Amino Acid" , "Amino Acid(PDB)", "Chain", 
                         "Residue Number".center(14), "S-S bond", "Distance [A]".center(15), "E(ij)^HF", "E(ij)^dMP2", "E(ij)^dMP2 [kcal/mol]"]
        data_csv_label = ",,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n"%["Number", "Fragment Number", "Amino Acid", "Amino Acid(PDB)", "Chain", 
                         "Residue Number", "S-S bond", "Distance", "E(ij)^HF", "E(ij)^dMP2", "MP2", "E(ij)^dMP2 [kcal/mol]"]
      elsif @@opts[:mode] == 3 then ### MP2
        @@log.info "", "Process: Write the MP2 (a.u.) or MP2 [kcal/mol]", "\n", @@opts[:text]
        write_line = "-" * 153 + "\n"
        data_txt_label = "   ij-frag   | %11s | %15s | %5s | %14s | %8s | %15s | % 9s  | % 10s | %10s | %11s |\n"%["Amino Acid" , "Amino Acid(PDB)", "Chain", 
                         "Residue Number".center(14), "S-S bond", "Distance [A]".center(15), "E(ij)^HF", "E(ij)^dMP2", "MP2".center(9), "[kcal/mol]"]
        data_csv_label = ",,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n"%["Number", "Fragment Number", "Amino Acid" , "Amino Acid(PDB)", "Chain", 
                         "Residue Number", "S-S bond", "Distance", "E(ij)^HF", "E(ij)^dMP2","MP2", "MP2[kcal/mol]"]
      end
      ### Write header in output
      Write_data.new.write_txt_data("\n<Data>\n", @@opts, 1, @@log)
      Write_data.new.write_txt_data(write_line, @@opts, 1, @@log)
      Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
      Write_data.new.write_txt_data(write_line, @@opts, 1, @@log)
      Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)

      if (@@flags[:ligand_num]) then
        while (i < (@frag_data[:max] - 1)) do
          if @@opts[:mode] == 1 then ### HF
            if (@abinitmp_header[:cp_corr] == "ON") then ### BSSE-CP == ON
              if (i + 1 < @@opts[:ligand_num]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
              elsif (i + 1 >= @@opts[:ligand_num]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 2), target, 
                                 @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i + 1][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 2), target, 
                                 @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i + 1][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
              end
            else ### BSSE-CP == OFF
              if (i + 1 < @@opts[:ligand_num]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hfkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hfkcal]]
              elsif (i + 1 >= @@opts[:ligand_num]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 2), target, 
                                 @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i + 1][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hfkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 2), target, 
                                 @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i + 1][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hfkcal]]
              end
            end
          elsif @@opts[:mode] == 2 then ### dMP2
            if (@abinitmp_header[:cp_corr] == "ON") then ### BSSE-CP == ON
              if (i + 1 < @@opts[:ligand_num]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
              elsif (i + 1 >= @@opts[:ligand_num]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 2), target, 
                                 @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i + 1][:ss].center(8),
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 2), target, 
                                 @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i + 1][:ss].center(8),
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
              end
            else ### BSSE-CP == OFF
              if (i + 1 < @@opts[:ligand_num]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
              elsif (i + 1 >= @@opts[:ligand_num]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 2), target, 
                                 @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i + 1][:ss].center(8),
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 2), target, 
                                 @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i + 1][:ss].center(8),
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
              end
            end
          elsif @@opts[:mode] == 3 then ### MP2
            if (@abinitmp_header[:cp_corr] == "ON") then ### BSSE-CP == ON
              if (i + 1 < @@opts[:ligand_num]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
                @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal].to_s)).to_f
              elsif (i + 1 >= @@opts[:ligand_num]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 2), target, 
                                 @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i + 1][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 2), target, 
                                 @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i + 1][:ss].center(8),
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
                @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cpkcal].to_s)).to_f
              end
            else ### BSSE-CP == OFF
              if (i + 1 < @@opts[:ligand_num]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal]]
                @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal].to_s)).to_f
              elsif (i + 1 >= @@opts[:ligand_num]) then
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 2), target, 
                                 @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i + 1][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2kcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 2), target, 
                                 @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i + 1][:ss].center(8),
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2kcal]]
                @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2kcal].to_s)).to_f
              end
            end
          end
          Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
          Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
          i += 1
        end
      else ### without -n option
        if (@frag_data[:particle] == 1) then
          while (i < (@frag_data[:max] - 1)) do
            if @@opts[:mode] == 1 then ### HF
              if (@abinitmp_header[:cp_corr] == "ON") then ### BSSE-CP == ON
                if (i + 1 < @frag_data[:frag_num][0]) then
                  data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 1), target, 
                                   @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
                  data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 1), target, 
                                   @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
                elsif (i + 1 >= frag_data[:frag_num][0]) then
                  data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 2), target, 
                                   @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i + 1][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
                  data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 2), target, 
                                   @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
                end
              else ### BSSE-CP == OFF
                if (i + 1 < @frag_data[:frag_num][0]) then
                  data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 1), target, 
                                   @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hfkcal]]
                  data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 1), target, 
                                   @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hfkcal]]
                elsif (i + 1 >= frag_data[:frag_num][0]) then
                  data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 2), target, 
                                   @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i + 1][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hfkcal]]
                  data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 2), target, 
                                   @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i + 1][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hfkcal]]
                end
              end
            elsif @@opts[:mode] == 2 then ### dMP2
              if (@abinitmp_header[:cp_corr] == "ON") then ### BSSE-CP == ON
                if (i + 1 < @frag_data[:frag_num][0]) then
                  data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 1), target, 
                                   @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
                  data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                   @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
                elsif (i + 1 >= @frag_data[:frag_num][0]) then
                  data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 2), target, 
                                   @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i + 1][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
                  data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 2), target, 
                                   @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i + 1][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
                end
              else ### BSSE-CP == OFF
                if (i + 1 < @frag_data[:frag_num][0]) then
                  data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 1), target, 
                                   @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
                  data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                   @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
                elsif (i + 1 >= @frag_data[:frag_num][0]) then
                  data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 2), target, 
                                   @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i + 1][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
                  data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 2), target, 
                                   @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i + 1][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
                end
              end
            elsif @@opts[:mode] == 3 then ### MP2
              if (@abinitmp_header[:cp_corr] == "ON") then ### BSSE-CP == ON
                if (i + 1 < @frag_data[:frag_num][0]) then
                  data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 1), target, 
                                   @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
                  data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                   @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
                  @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal].to_s)).to_f
                elsif (i + 1 >= @frag_data[:frag_num][0]) then
                  data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 2), target, 
                                   @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i + 1][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
                  data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 2), target, 
                                   @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i + 1][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
                  @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2_cpkcal].to_s)).to_f
                end
              else ### BSSE-CP == OFF
                if (i + 1 < @frag_data[:frag_num][0]) then
                  data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 1), target, 
                                   @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal]]
                  data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                   @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal]]
                  @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal].to_s)).to_f
                elsif (i + 1 >= @frag_data[:frag_num][0]) then
                  data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 2), target, 
                                   @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i + 1][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2kcal]]
                  data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 2), target, 
                                   @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                                   @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                                   @frag_statistics[i + 1][:ss].center(8), 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:hf], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:dmp2], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2], 
                                   @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2kcal]]
                  @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:mp2kcal].to_s)).to_f
                end
              end
            end
            Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
            Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
            i += 1
          end
        elsif (@frag_data[:particle] > 1) then
           ###################################################################################
           ###################################################################################
           ###################################################################################
           ###################################################################################
           ###################################################################################
           ###################################################################################
           ###
           ###  Now, [1, 2 , ..., (100, 101, 102, ...), ..., max] is not able to analyze...
           ###   (* In this case, (100, 101, 102, ...) are particle fragments.)
           ###
           ###################################################################################
           ###################################################################################
           ###################################################################################
           ###################################################################################
           ###################################################################################
           ###################################################################################
          while (i < (@frag_data[:frag_num][0] - 1)) do
            if @@opts[:mode] == 1 then ### HF
              if (@abinitmp_header[:cp_corr] == "ON") then ### BSSE-CP == ON
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cpkcal]]
              else ### BSSE-CP == OFF
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#20.6f |\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hfkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hfkcal]]
              end
            elsif @@opts[:mode] == 2 then ### dMP2
              if (@abinitmp_header[:cp_corr] == "ON") then ### BSSE-CP == ON
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cpkcal]]
              else ### BSSE-CP == OFF
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#21.7f |\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2kcal]]
              end
            elsif @@opts[:mode] == 3 then ### MP2
              if (@abinitmp_header[:cp_corr] == "ON") then ### BSSE-CP == ON
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cp], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal]]
                @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2_cpkcal].to_s)).to_f
              else ### BSSE-CP == OFF
                data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#10.6f | %#10.7f | %#10.6f |  %#10.4f |\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal]]
                data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,\n"%[(i + 1), target, 
                                 @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                                 @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                                 @frag_statistics[i][:ss].center(8), 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s, 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:hf], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:dmp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2], 
                                 @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal]]
                @binding_affinity = (BigDecimal(@binding_affinity.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:mp2kcal].to_s)).to_f
              end
            end
            Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
            Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
            i += 1
          end
        end
      end
      Write_data.new.write_txt_data(write_line, @@opts, 1, @@log)
      
      if @@opts[:mode] == 3 then ### MP2
        ### Label for Binding Affinity
        data_txt_label = "Binding Affinity = % 9.4f [kcal/mol]"%@binding_affinity
        data_csv_label = "\n\n,,Binding Affinity,%9.4f [kcal/mol]"%@binding_affinity
        @@log.info "\n", "  #{data_txt_label}", "\n", @@opts[:text]
        Write_data.new.write_txt_data("\n", @@opts, 1, @@log)
        Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
        Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
      end
    elsif (@@opts[:abinitmp] == 2) then ### PIEDA
      write_line = "-" * 215 + "\n"
      data_txt_label = "   ij-frag   | %11s | %15s | %5s | %14s | %8s | %15s | % 18s  | % 18s | % 22s | % 20s | % 21s |\n"%["Amino Acid" , 
                       "Amino Acid(PDB)", "Chain", "Residue Number".center(14), "S-S bond", "Distance [%]".center(15), "E_{es} [kcal/mol]", "E_{ex} [kcal/mol]", 
                       "E_{ct+mix} [kcal/mol]", "E_{disp} [kcal/mol]", "E_{total} [kcal/mol]"]
      data_csv_label = ",,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n"%["Number", "Fragment Number", "Amino Acid" , "Amino Acid(PDB)", "Chain",
                       "Residue Number", "S-S bond", "Distance [%]", "E_{es} [kcal/mol]", "E_{ex} [kcal/mol]", "E_{ct+mix} [kcal/mol]", 
                       "E_{disp} [kcal/mol]", "E_{total} [kcal/mol]"]
      ### Write header in output
      Write_data.new.write_txt_data("\n<Data>\n", @@opts, 1, @@log)
      Write_data.new.write_txt_data(write_line, @@opts, 1, @@log)
      Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
      Write_data.new.write_txt_data(write_line, @@opts, 1, @@log)
      Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
      
      if !(@@flags[:ligand_num]) then ### Without -n option
        if (@frag_data[:particle] == 1) then
          while (i < (@frag_data[:max] - 1)) do
            if (i + 1 < @frag_data[:frag_num][0]) then
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#19.3f | %#18.3f | %#22.3f | %#20.3f | %#21.3f |\n"%[
                               (i + 1), target, @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                               @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                               " ".center(8), @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:r].to_s.rjust(14),
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_es], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ex], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_disp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%f\n"%[
                               (i + 1), target, @frag_statistics[i][:residue_name], @frag_statistics[i][:final_pdb_residue_name], @frag_statistics[i][:chain], 
                               @frag_statistics[i][:final_pdb_residue_num], " ", 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:r].to_s,
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_es], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ex], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_disp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total]]
              @sum_total_e = (BigDecimal(@sum_total_e.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total].to_s)).to_f
            elsif (i + 1 >= @frag_data[:frag_num][0]) then
              data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#19.3f | %#18.3f | %#22.3f | %#20.3f | %#21.3f |\n"%[
                               (i + 2), target, @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                               @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                               " ".center(8), @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:r].to_s.rjust(14),
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_es], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ex], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_disp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_total]]
              data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%f\n"%[
                               (i + 2), target, @frag_statistics[i + 1][:residue_name], @frag_statistics[i + 1][:final_pdb_residue_name], @frag_statistics[i + 1][:chain], 
                               @frag_statistics[i + 1][:final_pdb_residue_num], " ", 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:r].to_s,
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_es], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ex], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_disp], 
                               @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_total]]
              @sum_total_e = (BigDecimal(@sum_total_e.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_total].to_s)).to_f
            end
            Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
            Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
            i += 1
          end
        elsif (@frag_data[:particle] > 1) then
          while (i < (@frag_data[:frag_num][0] - 1)) do
            data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#19.3f | %#18.3f | %#22.3f | %#20.3f | %#21.3f|\n"%[
                             (i + 1), target, @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                             @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                             " ".center(8), @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s.rjust(14),
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_es], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ex], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_disp], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total]]
            data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%f\n"%[
                             (i + 1), target, @frag_statistics[i][:residue_name], @frag_statistics[i][:final_pdb_residue_name], @frag_statistics[i][:chain], 
                             @frag_statistics[i][:final_pdb_residue_num], " ", 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:distance].to_s,
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_es], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ex], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_disp], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total]]
            @sum_total_e = (BigDecimal(@sum_total_e.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total].to_s)).to_f
            Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
            Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
            i += 1
          end
        end
      else ### With -n option
        while (i < (@frag_data[:max] - 1)) do
          if (i + 1 < @@opts[:ligand_num]) then
            data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#19.3f | %#18.3f | %#22.3f | %#20.3f | %#21.3f |\n"%[
                             (i + 1), target, @frag_statistics[i][:residue_name].center(11), @frag_statistics[i][:final_pdb_residue_name].center(15), 
                             @frag_statistics[i][:chain].center(5), @frag_statistics[i][:final_pdb_residue_num].to_s.center(14), 
                             " ".center(8), @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:r].to_s.rjust(14),
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_es], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ex], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_disp],
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total]]
            data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%f\n"%[
                             (i + 1), target, @frag_statistics[i][:residue_name], @frag_statistics[i][:final_pdb_residue_name], @frag_statistics[i][:chain], 
                             @frag_statistics[i][:final_pdb_residue_num], " ", 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:r].to_s,
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_es], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ex], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_disp], 
                             @ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total]]
            @sum_total_e = (BigDecimal(@sum_total_e.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 1) && j[:jfrag].to_s == target}[0][:e_total].to_s)).to_f
          elsif (i + 1 >= @@opts[:ligand_num]) then
            data_txt_label = "%4d %6s  | %11s | %15s | %5s | %14s | %8s |  %#14.4f | %#19.3f | %#18.3f | %#22.3f | %#20.3f | %#21.3f |\n"%[
                             (i + 2), target, @frag_statistics[i + 1][:residue_name].center(11), @frag_statistics[i + 1][:final_pdb_residue_name].center(15), 
                             @frag_statistics[i + 1][:chain].center(5), @frag_statistics[i + 1][:final_pdb_residue_num].to_s.center(14), 
                             " ".center(8), @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:r].to_s.rjust(14),
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_es], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ex], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_disp], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_total]]
            data_csv_label = ",,%d,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%f\n"%[
                             (i + 2), target, @frag_statistics[i + 1][:residue_name], @frag_statistics[i + 1][:final_pdb_residue_name], @frag_statistics[i + 1][:chain], 
                             @frag_statistics[i + 1][:final_pdb_residue_num], " ", 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:r].to_s,
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_es], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ex], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_ct_mix], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_disp], 
                             @ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_total]]
            @sum_total_e = (BigDecimal(@sum_total_e.to_s) + BigDecimal(@ave_data.select{|j| j[:ifrag] == (i + 2) && j[:jfrag].to_s == target}[0][:e_total].to_s)).to_f
          end
          Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
          Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
          i += 1
        end
      end
      Write_data.new.write_txt_data(write_line, @@opts, 1, @@log)
      ### Label for Binding Affinity
      data_txt_label = "Sum of E(total) = % 9.3f [kcal/mol]"%@sum_total_e
      data_csv_label = "\n\n,,Sum of E(total),%9.3f [kcal/mol]"%@sum_total_e
      @@log.info "\n", "  #{data_txt_label}", "\n", @@opts[:text]
      Write_data.new.write_txt_data("\n", @@opts, 1, @@log)
      Write_data.new.write_txt_data(data_txt_label, @@opts, 1, @@log)
      Write_data.new.write_csv_data(data_csv_label, @@opts, 1, @@log)
    end
  end
  
  
  #*** Make data line for 2-dimensional table (All fragment interaction mode) from ABINIT-MP Out file ***#
  def abinitmp_all_output(energy)
#    function_name = "abinitmp_all_output"
    data_txt_label = ""
    data_csv_label = ""
    dat_line = ""
    @dat_file = "2d_energy.dat"
    plot_energy = []
    energy_count = 0
    
    if (@@opts[:abinitmp] == 1) then ### IFIE
      if File.extname(@@opts[:output]) == "" then
        csv_file_name = File.basename(@@opts[:output]) + ".csv"
      else
        csv_file_name = File.basename(@@opts[:output]).gsub(File.extname(@@opts[:output]), ".csv")
      end
      csv_file_path = File.join(File.dirname(@@opts[:output]), csv_file_name)
      output_path = @@opts[:output]
    elsif (@@opts[:abinitmp] == 2) then ### PIEDA
      if File.extname(@@opts[:output]) == "" then
        csv_file_name = File.basename(@@opts[:output]) + "_pieda.csv"
        pieda_output = File.basename(@@opts[:output]) + "_pieda"
      else
        csv_file_name = File.basename(@@opts[:output]).gsub(File.extname(@@opts[:output]), "_pieda.csv")
        pieda_output = File.basename(@@opts[:output]).gsub(File.extname(@@opts[:output]), "_pieda.txt")
      end
      csv_file_path = File.join(File.dirname(@@opts[:output]), csv_file_name)
      output_path = File.join(File.dirname(@@opts[:output]), pieda_output)
    end
    
    @@log.info "\n", "Process: Write energy data at two-dimensional table", "\n", @@opts[:text]
    
    for i in (@@opts[:fragment][0] - 1)..@@opts[:fragment][1]
      for j in (@@opts[:fragment][0] - 1)..(@@opts[:fragment][1] + 1)
        if i == (@@opts[:fragment][0] - 1) then ### First line
          if j == (@@opts[:fragment][0] - 1) then
            data_txt_label += "| %16s "%""
            data_csv_label += ",,,,"
          elsif j == (@@opts[:fragment][0]) or j == (@@opts[:fragment][0] + 1) then
            data_txt_label += " %12s "%""
            data_csv_label += "%s,"%""
          elsif j == (@@opts[:fragment][1] + 1) then
            data_txt_label += "%25s |\n"%(j - 2).to_s
            data_csv_label += ",%s\n"%(j - 2).to_s
          else
            data_txt_label += "%24s "%(j - 2).to_s
            data_csv_label += ",%s"%(j - 2).to_s
          end 
        else ### Other line (2rd, 3rd, 4th,... Nth line)
          if j == (@@opts[:fragment][0] - 1) then
            data_txt_label += "| %5s |"%i.to_s
            data_csv_label += ",%s,"%i.to_s
          elsif j == @@opts[:fragment][0] then
            data_txt_label += " %6s | %6s | %s | %6s |"%[@frag_statistics[i - 1][:residue_name], @frag_statistics[i - 1][:final_pdb_residue_name], 
                                                         @frag_statistics[i - 1][:chain], @frag_statistics[i - 1][:ss]]
            data_csv_label += " %s, %s,%s, %s,"%[@frag_statistics[i - 1][:residue_name], @frag_statistics[i - 1][:final_pdb_residue_name], 
                                                 @frag_statistics[i - 1][:chain], @frag_statistics[i - 1][:ss]]
          elsif j == (@@opts[:fragment][0] + 1) then ### Residue number
            data_txt_label += " %5s |"%@frag_statistics[i - 1][:final_pdb_residue_num]
            data_csv_label += "%s,"%@frag_statistics[i - 1][:final_pdb_residue_num]
          elsif j == (@@opts[:fragment][1] + 1) then
#            dat_line += "%i %i %f\n\n"%[i - 1, j - 2, energy[j - 2][i]] if ((j - 2) < (i - 1))
            data_txt_label += " %22s |\n"%energy[j - 2][i]
            data_csv_label += " %22s\n"%energy[j - 2][i]
          else
            if ((j - 2) < (i - 1))
              plot_energy[energy_count] = energy[j - 2][i]
              energy_count += 1
              dat_line += "%i %i %f\n"%[i - 1, j - 2, energy[j - 2][i]]
            end 
            dat_line += "\n" if ((j - 1) == (i - 1))
            data_txt_label += " %22s |"%energy[j - 2][i]
            data_csv_label += "%22s,"%energy[j - 2][i]
          end
        end
      end
      if (i == 0) then ### Write first line 
        Write_data.new.write_txt_data(data_txt_label, @@opts, 0, output_path)
        Write_data.new.write_csv_data(data_csv_label, @@opts, 0, csv_file_path)
        Write_data.new.write_data(dat_line, @@opts, 0, @@log, @dat_file)
      else ### Write ohter line
        Write_data.new.write_txt_data(data_txt_label, @@opts, 1, output_path)
        Write_data.new.write_csv_data(data_csv_label, @@opts, 1, csv_file_path)
        Write_data.new.write_data(dat_line, @@opts, 1, @@log, @dat_file)
      end
      ### Reset
      data_txt_label = ""
      data_csv_label = ""
      dat_line = ""
    end
    
    return plot_energy
  end
  
  
  def run(cmd_exist)
    i = 0
    work_dir = File.dirname(@@opts[:out]) ### Get the path of work dir
    get_abinitmp_scc
    acquire_abinitmp_data
    
    if (@@opts[:interaction] == 1) then ### Selected-pairs mode (User's selected target vs All fragments)
      if (@abinitmp_header[:cp_corr] == "ON") then ### BSSE-CP == ON
        mode = [:hf_cpkcal, :dmp2_cpkcal, :mp2_cpkcal]
      else
        mode = [:hfkcal, :dmp2kcal, :mp2kcal]
      end
      cal_ave_data
      abinitmp_selectedpairs_output
      
      if cmd_exist[:gnuplot] and @@opts[:gnuplot] then ### Plot
        Dir.chdir(work_dir) do
          @@log.info "\n", "****************", "", @@opts[:text]
          @@log.info "", "* Plot Process *"  , "", @@opts[:text]
          @@log.info "", "****************", "", @@opts[:text]
          plot = Plot.new(@@opts, @frag_data, @dat_file, @@log)
          if (@@opts[:abinitmp] == 1) then ### IFIE 
            plot.extract_abinitmp_analysis_data(@ave_data, @ave_pieda_data, @frag_statistics, mode[@@opts[:mode] - 1], @@opts[:abinitmp])
          elsif (@@opts[:abinitmp] == 2) then ### PIEDA
            plot.extract_abinitmp_analysis_data(@ave_data, @ave_pieda_data, @frag_statistics, :e_total, @@opts[:abinitmp])
          end
          plot.make_one_d_plt("abinit-mp")
          plot.plot_gnuplot
          if (cmd_exist[:ps2pdf] or cmd_exist[:gs]) then
            plot.convert_ps2pdf
          else
            @@log.warn "\n", "Warning: Do not convert PS file into PDF file because the Ghostscript (gs) program is not installed on your system!", "\n", @@opts[:text]
          end
        end
      elsif !(cmd_exist[:gnuplot]) and @@opts[:gnuplot]
        @@log.error "\n", "Error: Gnuplot program is not installed on your system!", "\n", @@opts[:text]
      else
        @@log.info "\n", "Process: All process finished \"without plot process\"!", "\n", @@opts[:text]
      end
    elsif (@@opts[:interaction] == 2) then ### All fragment interaction (All fragments vs All fragments)
      ifie_energy = Array.new(@frag_data[:max]).map{Array.new(@frag_data[:max], 0.0)}
      pieda_energy = Array.new(@frag_data[:max]).map{Array.new(@frag_data[:max], 0.0)} if (@abinitmp_header[:pieda] == "YES")
      if (@abinitmp_header[:cp_corr] == "ON") then ### BSSE-CP == ON
        mode = [:hf_cp, :hf_cpkcal, :dmp2_cp, :dmp2_cpkcal, :mp2_cp, :mp2_cpkcal]
      else
        mode = [:hf, :hfkcal, :dmp2, :dmp2kcal, :mp2, :mp2kcal]
      end
      pieda_mode = [:e_es, :e_ex, :e_ct_mix, :e_disp, :e_total] if (@abinitmp_header[:pieda] == "YES")
      @ifie_energy.each { |d|
        if (d[:distance] == 0.000000) then
          ifie_energy[d[:ifrag]][d[:jfrag]] = 0.0
          pieda_energy[d[:ifrag]][d[:jfrag]] = 0.0 if (@abinitmp_header[:pieda] == "YES")
        else
          if (@abinitmp_header[:pieda] == "YES") then
            ifie_energy[d[:ifrag]][d[:jfrag]] = d[:mp2kcal]
            pieda_energy[d[:ifrag]][d[:jfrag]] = @pieda_energy[i][pieda_mode[@@opts[:mode] - 1]]
            i += 1
          else
            ifie_energy[d[:ifrag]][d[:jfrag]] = d[mode[@@opts[:mode] - 1]]
          end
        end
      }
      plot_energy = abinitmp_all_output(ifie_energy)
      plot_energy = abinitmp_all_output(pieda_energy) if (@@opts[:abinitmp] == 2)
      plot = Plot.new(@@opts, @frag_data, @dat_file, @@log)
      plot.make_two_d_plt(plot_energy)
      Dir.chdir(work_dir) do
        if cmd_exist[:gnuplot] then
          @@log.info "\n", "****************", "", @@opts[:text]
          @@log.info "", "* Plot Process *"  , "", @@opts[:text]
          @@log.info "", "****************", "", @@opts[:text]
          plot.plot_gnuplot
          if cmd_exist[:ps2pdf] then
            plot.convert_ps2pdf
          end
        end
      end
    end
    
    if (@@xml_flag) then
      if @@opts[:xml] then
        @@log.info "\n", "Process: Output XML from Analysis ABINIT-MP out data", "", @@opts[:text]
        xml = XML.new(@@opts, @@log)
        xml.xml_abinitmp(@frag_data, @abinitmp_header, @frag_statistics, @out_data, @mulliken_charge, 
                         @total_energy, @ifie_energy, @ave_data, @binding_affinity)
      end
    end
#    print_array
  end
  
  
  #*** Print analysis data including array ***#
  def print_array
    pp @abinitmp_header
    pp @total_energy
    pp @mulliken_charge
    pp @frag_statistics
    pp @out_data
    pp @ifie_energy
    pp @ave_data
  end
end


#*************************************************************************************************#
#***     Class for writing analyzed output file (*.output: text format, *.csv: CSV format)     ***#
#*************************************************************************************************#
class Write_data
  #*** Write analyzed output file (*.output: text format) ***#
  def write_txt_data(data, opts, write_flag, log)
    if write_flag == 0 then ### New file or overwrite
      begin 
        output = open(opts[:output], "w")
      rescue SystemCallError => e
        log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
      rescue IOError => e
        log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
      end
    elsif write_flag == 1 then ### Add data to output file
      begin 
        output = open(opts[:output], "a")
      rescue SystemCallError => e
        log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
      rescue IOError => e
        log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
      end
    end
    output.write(data) ### Write data
    output.close       ### File close
  end
  
  
  #*** Write analyzed output file (*.csv: CSV format) ***#
  def write_csv_data(data, opts, write_flag, log)
    ### Make the csv file name and path
    if File.extname(opts[:output]) == "" then
      csv_file_name = File.basename(opts[:output]) + ".csv"
    else
      csv_file_name = File.basename(opts[:output]).gsub(File.extname(opts[:output]), ".csv")
    end
    csv_file_path = File.join(File.dirname(opts[:output]), csv_file_name)
    
    if write_flag == 0 then ### New file or overwrite
      begin 
        output = open(csv_file_path, "w")
      rescue SystemCallError => e
        log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
      rescue IOError => e
        log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
      end
    elsif write_flag == 1 then ### Add data to output file
      begin 
        output = open(csv_file_path, "a")
      rescue SystemCallError => e
        log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
      rescue IOError => e
        log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
      end
    end
    output.write(data) ### Write data
    output.close       ### File close
  end
  
  
  #*** Write data into other file (*.dat, *.plt, ...) ***#
  def write_data(data, opts, write_flag, log, file_name)
    file_path = File.join(File.dirname(opts[:output]), file_name) ### Make the csv file name and path
    
    if write_flag == 0 then ### New file or overwrite
      begin 
        output = open(file_path, "w")
      rescue SystemCallError => e
        log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
      rescue IOError => e
        log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
      end
    elsif write_flag == 1 then ### Add data to output file
      begin 
        output = open(file_path, "a")
      rescue SystemCallError => e
        log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
      rescue IOError => e
        log.error "\n", "class=[#{e.class}] message=[#{e.message}]", "", opts[:text]
      end
    end
    output.write(data) ### Write data
    output.close       ### File close
  end
  
  
  #*** Mak new PDB file replacing B-factor (temperature factor) with mulliken charge of RHF-FMO2 ***#
  def make_pdb_charge(mulliken_charge, opts)
    atom_count = 0
    
    new_pdb_file_name = opts[:pdb].gsub(File.extname(opts[:pdb]), "_Bfactor2charge.pdb")
    data_file = open(opts[:pdb], "r")
    new_pdb_file = open(new_pdb_file_name, "w")
    
    data_file.each do |line|
      record_name = line[0..5].strip
      if !(record_name == "TER") then 
        if record_name == "ATOM" or record_name == "HETATM" then
          atom_name = (line[12..15].strip)[0] ### first character of atom name
          if (mulliken_charge[atom_count][:atom_name] == atom_name) then
            line[6..10] = "%5d"%atom_count
            if line.size < 60 then
              line = line.tr("\r\n|\r|\n", "") + "                          \n"
              if (opts[:fmo] == 1) then ### PAICS
                line[60..65] = "%6.3f"%mulliken_charge[atom_count][:charge]
              elsif (opts[:fmo] == 2) then ### GAMESS-FMO
                line[60..65] = "%6.3f"%mulliken_charge[atom_count][:q2]
              elsif (opts[:fmo] == 3) then ### ABINIT-MP
                line[60..65] = "%6.3f"%mulliken_charge[atom_count][:net_charge]
              end
            else
              if (opts[:fmo] == 1) then ### PAICS
                line[60..65] = "%6.3f"%mulliken_charge[atom_count][:charge]
              elsif (opts[:fmo] == 2) then ### GAMESS-FMO
                line[60..65] = "%6.3f"%mulliken_charge[atom_count][:q2]
              elsif (opts[:fmo] == 3) then ### ABINIT-MP
                line[60..65] = "%6.3f"%mulliken_charge[atom_count][:net_charge]
              end
            end
          else  ### i-th atom name of Out file is not equal to i-th atom name of PDB file!!
            if line.size < 60 then
              line = line.tr("\r\n|\r|\n", "") + "                          \n"
            end
            line[60..65] = "%6.3f"%0.000
          end
          atom_count += 1
        end
        new_pdb_file.write(line)
      end
    end
    data_file.close    ### Old PDB file close
    new_pdb_file.close ### New PDB file close
  end
end


#*******************************************************************************#
#***              Class for XML (Extensible Markup Language) file            ***#
#  (Ref.)                                                                       #
#    http://www.rubydoc.info/github/sparklemotion/nokogiri/Nokogiri/XML/Builder #
#    http://blog.goo.ne.jp/the_simple_1500/e/2c62a0e4ce81f3692bb6a40c8f7a4295   #
#    http://d.hatena.ne.jp/fre_oik/20110609/1307628189                          #
#    http://d.hatena.ne.jp/fre_oik/20110609/1307627018                          #
#*******************************************************************************#
class XML
  def initialize(opts, log)
   @header_data = Hash.new
   @header_data["Title"] = ""
   @header_data["Date"] = (Time.now).strftime("%Y/%m/%d %H:%M:%S")
   @opts = opts
   @log = log
  end

  #*** Output XML file from PDB data ***#
  def xml_pdb(pdb_all_data)
   @header_data["Title"] = "XML for PDB data"

    xml_file_name = "pdb.xml"
    xml_file_path = File.join(File.dirname(@opts[:output]), xml_file_name)

    xml_object = Nokogiri::XML::Builder.new do |xml|
      xml.doc.create_internal_subset(
        'html',
        "-//W3C//DTD HTML 4.01 Transitional//EN",
        "http://www.w3.org/TR/html4/loose.dtd"
      )
      xml.data {
        xml.header { 
          @header_data.each { |k, v|
            eval("xml.#{k} { xml.text v }")
          }
          xml.options("comment" => "Options on this analysis ruby program (RbAnalysisFMO.rb)") {
            xml.comment "PDB file name (/path/.../*.pdb)"
            xml.pdb_ @opts[:pdb]
          }
        }
        xml.comment "PDB format (for Ruby program)"
        xml.comment " (ex.) XXXXXXX: (*-*), [*..*], %**"
        xml.comment " * Parentheses is PDB format as column number"
        xml.comment " * Bracketss is Ruby's array number"
        xml.comment " * Format (%) is Ruby format"
        xml.comment "<Data list>"
        xml.comment " - Atom serial number: (5-9), [6..10], %5d"
        xml.comment " - Atom name: (11-14), [12..15], %4s"
        xml.comment " - Residue name: (16-18), [17..19], %3s"
        xml.comment " - Chain identifier: (20), [21], %1s"
        xml.comment " - Residue sequence number: (21-24), [22..25], %4d"
        xml.comment " - Orthogonal coordinates for X: (29-36), [30..37], %8.3f"
        xml.comment " - Orthogonal coordinates for Y: (37-44), [38..45], %8.3f"
        xml.comment " - Orthogonal coordinates for Z: (45-52), [46..53], %8.3f"
        xml.comment " - Occupancy: (53-58), [54..59], %6.3f"
        xml.comment " - Temperature factor: (59-64), [60..65], %6.3f"
        xml.comment " - Element symbol: (75-76), [76..77], %2s"
        xml.comment " - Charge on the atom: (77-78), [78..79], %2s"
        xml.comment "(Ref.): http://www2.rikkyo.ac.jp/~tokiwa/menu/bioLib/memo/other/PDBformat.html"
        pdb_all_data.each { |d|
          xml.pdb_data(:atom_number => d[:atom_num], :atom_name => d[:atom_name], :residue_name => d[:residue_name],
                      :chain => d[:chain], :residue_number => d[:residue_num], :x => d[:x], :y => d[:y], :z => d[:z],
                      :occupancy => d[:occupancy], :temperature_factor => d[:temperature_factor],
                      :element_symbol => d[:element_symbol], :atom_charge => d[:charge])
        }
      }
    end

    File.open(xml_file_path, "w") do |file|
      file.puts Nokogiri::XML(xml_object.to_xml, nil, 'utf-8').to_xml.toutf8
    end
  end

  #*** Output XML file from Analysed PAICS data ***#
  def xml_paics(frag_data, cp_corr, out_data, amino_acid_letter, final_pdb_res, energy_data, ave_data, mulliken_charge, cmp2_data, energy_cal, binding_affinity)
    @header_data["Title"] = "XML for analysed PAICS data"

    xml_file_name = "paics_out.xml"
    xml_file_path = File.join(File.dirname(@opts[:output]), xml_file_name)

    xml_object = Nokogiri::XML::Builder.new do |xml|
      xml.doc.create_internal_subset(
        'html',
        "-//W3C//DTD HTML 4.01 Transitional//EN",
        "http://www.w3.org/TR/html4/loose.dtd"
      )
      xml.data {
        xml.header { 
          @header_data.each { |k, v|
            eval("xml.#{k} { xml.text v }")
          }
          xml.options("comment" => "Options on this analysis ruby program (RbAnalysisFMO.rb)") {
            if @opts[:text] then
              xml.text_ "Show text on terminal with \"-t\""
            else
              xml.text_ "Don\'t show text on terminal with \"-t\""
            end
            xml.fmo_program_ "PAICS"
            if @opts[:paics] == 1 then 
              xml.paics_ver_ "Older versions than PAICS 2012/01/17"
            elsif @opts[:paics] == 2 then 
              xml.paics_ver_ "PAICS 2012/05/13 version or later"
            end
            xml.comment "Calculated PAICS Out file name (/path/.../*.out or ...)"
            xml.out_ @opts[:out]
            xml.comment "PDB file name (/path/.../*.pdb)"
            xml.pdb_ @opts[:pdb]
            xml.comment "Analysed output file name (/path/.../*.[extansion (:TEXT format)])"
            xml.output_ @opts[:output]
            if @opts[:add_chain] == 1 then
              xml.add_chain_ "To continue normally (this process is nothing)"
            elsif @opts[:add_chain] == 2 then
              xml.add_chain_ "Output a new PDB file replacing raw identifier to \"A\""
            end
            if @opts[:interaction] == 1 then
              xml.interaction_ "Selected-pairs mode in \"one-dimensional\" table"
              mode = ["HF   (a.u.) and HF   [kcal/mol]", "dMP2 (a.u.) and dMP2 [kcal/mol]", "MP2  (a.u.) and MP2  [kcal/mol] (All data)'"]
              xml.energy_type_ mode[@opts[:mode] - 1]
              if !(@opts[:gnuplot]) then
                xml.gnuplot_ "Not plot using Gnuplot program"
              else
                xml.gnuplot_ "Plot bar graph using Guplot program"
                xml.distance_ "[#{@opts[:distance][0]}, #{@opts[:distance][1]}]"
                if @opts[:aaletter] == 1 then
                  xml.amino_acid_leter_code_ "Amino Acid 1 letter code on plot"
                elsif @opts[:aaletter] == 2 then
                  xml.amino_acid_leter_code_ "Amino Aicd 3 letter code on plot"
                end
              end
            elsif @opts[:interaction] == 2 then
              xml.interaction_ "All-pairs mode in \"two-dimensional\" table'"
              mode = ["HF (a.u.)", "HF [kcal/mol]", "dMP2 (a.u.)", "dMP2 [kcal/mol]", "MP2  (a.u.)", "MP2  [kcal/mol]"]
              xml.energy_type_ mode[@opts[:mode] - 1]
              xml.comment "Extract data range between i and j fragment [fragment number]"
              xml.fragment_range_ "[#{@opts[:fragment][0]}, #{@opts[:fragment][1]}]"
            end
          }

          xml.fragment_data {
            i = 0
            comment = ["Number of fragments (Max)", "Number of particle fragments (ligands)", "Particle fragment numbers (ligands)"] 
            frag_data.each { |k, v|
              xml.comment comment[i]
              eval("xml.#{k} { xml.text v }")
              i += 1
            }
            xml.comment "rhf, cmp2: canonical mp2 (= MP2), canonical mp2 ( resolution of the identity ) = ri-mp2, local mp2"
            xml.rhf_ energy_cal[0]
            xml.canonical_mp2_ energy_cal[1]
            xml.ri_cmp2_ energy_cal[2]
            xml.local_mp2_ energy_cal[3]
            xml.comment "BSSE correction with the counter-poise method by PAICS using cp_corr (yes or no?)"
            xml.comment "  <Ref.>: Chapter 2. INPUT, P. 13 in PAICS manual (URL: http://www.paics.net/pdf/manual.pdf)"
            if cp_corr then
              xml.cp_corr_ "Yes"
            else
              xml.cp_corr_ "No"
            end
          }
        }
        xml.paics_data {
          xml.comment "input coordinate of nucleus charge"
          xml.comment " * (x,y,z) is [Angstrom]"
          xml.atom_data {
            out_data.each { |d|
              xml.input_coordinate(:atom_num => d[:atom_num], :atom_name => d[:atom_name], :x => d[:x], :y => d[:y], :z => d[:z])
            } 
          }

          xml.comment "input fragment (fragment data of amino acid, ligand, and so on...)"
          xml.comment " * atom_numbers: atom number including ith-fragment (ifrag)"
          xml.input_fragment {
            amino_acid_letter.each { |d|
              xml.fragment(:ifrag => d[:ifrag], :residue_name => d[:residue_name], :sum_electron => d[:sum_ele], 
                           :sum_atoms => d[:sum_atoms], :atom_numbers => d[:atom_num], :SS_bond => d[:ss])
            }
          }

          xml.comment "The final amino acid data in comparison between input fragment in PAICS out file and residue data of PDB file"
          xml.final_residue { 
            i = 1
            final_pdb_res.each { |d|
              xml.residue_data(:ifrag => i, :residue_number => d[:residue_num], :residue_name => d[:residue_name],
                               :one_letter_code => d[:one_letter], :chain => d[:chain])
              i += 1
            }
          }

          xml.comment "FMO-2 result (rhf ifie and ri-cmp2 ifie)"
          xml.comment " - (*_cp = 0.0 is no BSSE correction)"
          xml.comment " - Distance: Calculated distance between ifrag and jfrag amino acids [A]"
          xml.comment "   * If number of particle fragments (ligands) is > 1, distance is average and energy is the sum"
          xml.comment " - \"*_frag\" data is each particle fragments (ligands)"
          xml.comment " - 1 [hartree] = 627.50948 [kcal/mol]"
          xml.comment "<Data list>"
          xml.comment " - ifrag: ith-fragment of dimer between ith and jth"
          xml.comment " - jfrag: jth-fragment of dimer between ith and jth"
          xml.comment " - hf*: HF (HF') [hartree], [kcal/mol]"
          xml.comment " - hf_cp*: HF (HF') BSSE [hartree], [kcal/mol]"
          xml.comment " - dmp2*: dMP2 [hartree], [kcal/mol]"
          xml.comment " - dmp2_cp*: dMP2 BSSE [hartree], [kcal/mol]"
          xml.comment " - mp2*: MP2 = HF (HF') + dMP2 [hartree], [kcal/mol]"
          xml.comment " - mp2_cp*: MP2 (BSSE) = (HF (HF') BSSE) + (dMP2 BSSE) [hartree], [kcal/mol]"
          xml.energy_data {
            if frag_data[:particle] == 1 then
              energy_data.each { |d|
                xml.ifie(:ifrag => d[:ifrag], :jfrag => d[:jfrag], :distance => d[:distance], :hf => d[:hf], :hf_cp => d[:hf_cp], 
                         :hfkcal => d[:hfkcal], :hf_cpkcal => d[:hf_cpkcal], :dmp2 => d[:dmp2], :dmp2_cp => d[:dmp2_cp],
                         :dmp2kcal => d[:dmp2kcal], :dmp2_cpkcal => d[:dmp2_cpkcal], :mp2 => d[:mp2], :mp2_cp => d[:mp2_cp], 
                         :mp2kcal => d[:mp2kcal], :mp2_cpkcal => d[:mp2_cpkcal])
              }
            elsif frag_data[:particle] > 1  then
              ave_data.each { |d|
                xml.ifie(:ifrag => d[:ifrag], :jfrag => d[:jfrag], :distance => d[:distance], :distance_frag => d[:distance_frag], 
                         :hf => d[:hf], :hf_frag => d[:hf_frag], :hf_cp => d[:hf_cp], :hf_cp_frag => d[:hf_cp_frag], 
                         :hfkcal => d[:hfkcal], :hfkcal_frag => d[:hfkcal_frag], :hf_cpkcal => d[:hf_cpkcal], 
                         :hf_cpkcal_frag => d[:hf_cpkcal_frag], :dmp2 => d[:dmp2], :dmp2_frag => d[:dmp2_frag], 
                         :dmp2_cp => d[:dmp2_cp], :dmp2_cp_frag => d[:dmp2_cp_frag], :dmp2kcal => d[:dmp2kcal], 
                         :dmp2kcal_frag => d[:dmp2kcal_frag], :dmp2_cpkcal => d[:dmp2_cpkcal], 
                         :dmp2_cpkcal_frag => d[:dmp2_cpkcal_frag], :mp2 => d[:mp2], :mp2_frag => d[:mp2_frag], 
                         :mp2_cp => d[:mp2_cp], :mp2_cp_frag => d[:mp2_cp_frag], :mp2kcal => d[:mp2kcal], 
                         :mp2kcal_frag => d[:mp2kcal_frag], :mp2_cpkcal => d[:mp2_cpkcal], :mp2_cpkcal_frag => d[:mp2_cpkcal_frag])
              }
            end
          }

          xml.binding_affinity_ "%f [kcal/mol]"%binding_affinity if (@opts[:interaction] == 1)

          if (energy_cal[2] == "yes") then ### cmp2
            xml.comment "FMO-2 result (cmp2: canonical mp2 (= MP2) ifie)"
            xml.comment " - (*_cp = 0.0 is no BSSE correction)"
            xml.comment " - 1 [hartree] = 627.50948 [kcal/mol]"
            xml.comment "<Data list>"
            xml.comment " - normal not scs: cmp2 ifie for normal ( not scs ) [hartree], [kcal/mol]"
            xml.comment " - normal not scs_cp: cmp2 ifie for normal ( not scs ) BSSE [hartree], [kcal/mol]"
            xml.comment " - grimme: cmp2 ifie for Grimme's scs [hartree], [kcal/mol]"
            xml.comment " - grimme_cp: cmp2 ifie for Grimme's scs (BSSE) [hartree], [kcal/mol]"
            xml.comment " - jung: cmp2 ifie for Jung's (Head-Gordon) SCS energy [hartree], [kcal/mol]"
            xml.comment " - jung_cp: cmp2 ifie for Jung's (Head-Gordon) SCS energy (BSSE) [hartree], [kcal/mol]"
            xml.comment " - hill_scs: cmp2 ifie for Hill's scs energy [hartree], [kcal/mol]"
            xml.comment " - hill_scs_cp: cmp2 ifie for Hill's scs energy (BSSE) [hartree], [kcal/mol]"
            xml.cmp2_data {
              cmp2_data.each { |d|
                xml.ifie(:ifrag => d[:ifrag], :jfrag => d[:jfrag], :normal_not_scs => d[:normal_not_scs], :normal_not_scskcal => d[:normal_not_scskcal], 
                         :normal_not_scs_cp => d[:normal_not_scs_cp], :normal_not_scs_cpkcal => d[:normal_not_scs_cpkcal], 
                         :grimme_scs => d[:grimme_scs], :grimme_scskcal => d[:grimme_scskcal], :grimme_scs_cp => d[:grimme_scs_cp], 
                         :grimme_scs_cpkcal => d[:grimme_scs_cpkcal], :jung_scs => d[:jung_scs], :jung_scskcal => d[:jung_scskcal], 
                         :jung_scs_cp => d[:jung_scs_cp], :jung_scs_cpkcal => d[:jung_scs_cpkcal], :hill_scs => d[:hill_scs], 
                         :hill_scskcal => d[:hill_scskcal], :hill_scs_cp => d[:hill_scs_cp], :hill_scs_cpkcal => d[:hill_scs_cpkcal])
              }
            }
          elsif (energy_cal[4] == "yes") then ### local mp2
            xml.comment "FMO-2 result (local mp2 ifie)"
            xml.comment " * 1 [hartree] = 627.50948 [kcal/mol]"
            xml.comment "<Data list>"
            xml.comment " - "
              ############################################################
              ############################################################
              ############################################################
              ############################################################
              ############################################################
              ############################################################
              ###
              ### add "local mp2 ifie" data
              ###
              ############################################################
              ############################################################
              ############################################################
              ############################################################
              ############################################################
              ############################################################
          end

          if @opts[:interaction] == 2 then
            xml.comment "rhf mulliken population and charge ( fmo-2 )"
            xml.comment "<Data list>"
            xml.comment " - Atom number"
            xml.comment " - Atom name"
            xml.comment " - Pop: Mullikne population"
            xml.comment " - Charge: Mulliken charge"
            xml.mulliken_data {
              mulliken_charge.each { |d|
                xml.mulliken(:atom_number => d[:atom_num], :atom_name => d[:atom_name], :population => d[:population], :charge => d[:charge])
              }
            }
          end
        }
      }
    end

    File.open(xml_file_path, "w") do |file|
      file.puts Nokogiri::XML(xml_object.to_xml, nil, 'utf-8').to_xml.toutf8
    end
  end

  #*** Output XML file from Analysed GAMESS-FMO data ***#
  def xml_gamess_fmo(frag_data, gamess_header, frag_statistics, one_body_fmo, fmo_property, two_body_fmo, ct, three_body_fmo, mulliken_charge, total_energy)
    @header_data["Title"] = "XML for analysed GAMESS-FMO out data"

    xml_file_name = "gamess-fmo_out.xml"
    xml_file_path = File.join(File.dirname(@opts[:output]), xml_file_name)

    xml_object = Nokogiri::XML::Builder.new do |xml|
      xml.doc.create_internal_subset(
        'html',
        "-//W3C//DTD HTML 4.01 Transitional//EN",
        "http://www.w3.org/TR/html4/loose.dtd"
      )
      xml.data {
        xml.header { 
          @header_data.each { |k, v|
            eval("xml.#{k} { xml.text v }")
          }
          xml.options("comment" => "Options on this analysis ruby program (RbAnalysisFMO.rb)") {
            if @opts[:text] then
              xml.text_ "Show text on terminal with \"-t\""
            else
              xml.text_ "Don\'t show text on terminal with \"-t\""
            end
            xml.fmo_program_ "PAICS"
            xml.comment "Calculated GAMESS-FMO Out file name (/path/.../*.out or ...)"
            xml.out_ @opts[:out]
            xml.comment "PDB file name (/path/.../*.pdb)"
            xml.pdb_ @opts[:pdb]
            xml.comment "Analysed output file name (/path/.../*.[extansion (:TEXT format)])"
            xml.output_ @opts[:output]
            if @opts[:add_chain] == 1 then
              xml.add_chain_ "To continue normally (this process is nothing)"
            elsif @opts[:add_chain] == 2 then
              xml.add_chain_ "Output a new PDB file replacing raw identifier to \"A\""
            end
            if @opts[:interaction] == 1 then
              xml.interaction_ "Selected-pairs mode in \"one-dimensional\" table"
              xml.energy_type_ "All energy data: E(es), E(ex), E(ct+mix), E(disp), G(sol), E(total), (E_{ij}-E_{i}-E_{j}), Tr(dD^{ij}*V^{ij})"
              if !(@opts[:gnuplot]) then
                xml.gnuplot_ "Not plot using Gnuplot program"
              else
                xml.gnuplot_ "Plot bar graph using Guplot program"
                xml.distance_ "[#{@opts[:distance][0]}, #{@opts[:distance][1]}]"
                if @opts[:aaletter] == 1 then
                  xml.amino_acid_leter_code_ "Amino Acid 1 letter code on plot"
                elsif @opts[:aaletter] == 2 then
                  xml.amino_acid_leter_code_ "Amino Aicd 3 letter code on plot"
                end
              end
            elsif @opts[:interaction] == 2 then
              xml.interaction_ "All-pairs mode in \"two-dimensional\" table'"
              mode = ["E(es) [kcal/mol]", "E(ex) [kcal/mol]", "E(ct+mix) [kcal/mol]", "E(disp) [kcal/mol]", 
                      "G(sol) [kcal/mol]", "E(total [kcal/mol])", "(E_{ij}-E_{i}-E_{j}) [kcal/mol]", "Tr(dD^{ij}*V^{ij}) [kcal/mol]"]
              xml.energy_type_ mode[@opts[:mode] - 1]
              xml.comment "Extract data range between i and j fragment [fragment number]"
              xml.fragment_range_ "[#{@opts[:fragment][0]}, #{@opts[:fragment][1]}]"
            end
          }

          xml.fragment_data {
            i = 0
            comment = ["Number of fragments (Max)", "Number of particle fragments (ligands)", "Particle fragment numbers (ligands)"] 
            frag_data.each { |k, v|
              xml.comment comment[i]
              eval("xml.#{k} { xml.text v }")
              i += 1
            }
          }
          xml.comment "Header of GAMESS-FMO for initialized data"
          xml.gamess {
            xml.gamess_version_ gamess_header[:version]
            xml.total_charge_ gamess_header[:charge]
            xml.total_spin_multiplicity_ gamess_header[:spin]
            xml.n_body_fmo_ gamess_header[:n_body_fmo]
            xml.n_body_fmo_label_ gamess_header[:n_body_fmo_label]
            xml.fmo_method_ gamess_header[:fmo_method]
            xml.num_of_atoms_ gamess_header[:num_of_atoms]
          }
        }
        xml.gamess_fmo_data {
          xml.comment "Fragment statistics"
          xml.comment "<Data list>"
          xml.comment " - residue_name and number from GAMESS-FMO out data"
          xml.comment " - final_pdb_residue_name and number from:"
          xml.comment "   * The final amino acid data in comparison between input fragment in GAMESS-FMO out file and residue data of PDB file"
          xml.fragment_statistics {
            frag_statistics.each { |d|
              xml.frag_data(:ifrag => d[:ifrag], :residue_name => d[:residue_name], :q => d[:q], :num_of_atoms => d[:num_of_atoms],
                            :final_pdb_residue_name => d[:final_pdb_residue_name], :final_pdb_residue_number => d[:final_pdb_residue_num], 
                            :chain => d[:chain])
            }
          }

          xml.comment "One-body FMO properties."
          xml.comment "<Data list>"
          xml.comment " - E\"corr (E^{''}_{I}): Correlated energy of monomer (FMO1) [Hartree]"
          xml.comment " - E\"uncorr (Eun^{''}_{I}): Uncorrelated energy of monomer (FMO1) [Hartree]"
          xml.comment " - DX: Dipole moment of x component for monomar (FMO1) [Debye]"
          xml.comment " - DY: Dipole moment of y component for monomar (FMO1) [Debye]"
          xml.comment " - DZ: Dipole moment of z component for monomar (FMO1) [Debye]"
          xml.one_body_fmo {
            one_body_fmo.each { |d|
              xml.one_body_data(:ifrag => d[:ifrag], :residue_name => d[:residue_name], :residue_number => d[:residue_number], 
                                :correlated_energy => d[:correlated_energy], :uncorrelated_energy => d[:uncorrelated_energy],
                                :dx => d[:dipole_moment_x], :dy => d[:dipole_moment_y], :dz => d[:dipole_moment_z])
            }
          }

          xml.comment "Frontier molecular orbital (FMO!) properties based on Koopmans' theorem."
          xml.comment "<Data list>"
          xml.comment " - IP: ionization potential [eV]"
          xml.comment " - EA: electron affinity [eV]"
          xml.comment " - Electronegativity = - chemical potential [eV]"
          xml.comment " - global hardness [eV]"
          xml.comment " - global softness [eV]"
          xml.comment " - electrophilicity index [eV]"
          xml.fmo_property {
            fmo_property.each { |d|
              xml.data(:ifrag => d[:ifrag], :ip => d[:ionization_potential], :ea => d[:electron_affinity], 
                       :chemical_potential => d[:chemical_potential], :global_hardness => d[:global_hardness],
                       :global_softness => d[:global_softness], :electrophilicity_index => d[:electrophilicity_index])
            }
          }

          xml.comment "================================================="
          xml.comment "Two-body FMO properties."
          xml.comment "<Data list>"
          xml.comment " - ith-fragment of dimer between ith and jth: (replace J with i by this script)"
          xml.comment " - jth-fragment of dimer between ith and jth: (replace I with j by this script)"
          xml.comment " - D label in DL: Calculation method"
          xml.comment "   - D = C: Dynamically correlated method (MP2,CI)"
          xml.comment "   - D = N (No): Not dynamically correlated method (RHF,DFT) "
          xml.comment "   - D = S: Separated dimer: semiclassical interaction (ES)"
          xml.comment "   - D = M: MCSCF method"
          xml.comment " - d_label: Label of D for calculation method"
          xml.comment " - L label in DL: Layer number of multi-layer"
          xml.comment " - z: Monomer charge product between ith- and jth-fragment (value: 0, -1, 1)"
          xml.comment "      (ex.) ith-fragment (charge = 0) * jth-fragment (charge = 0) = 0"
          xml.comment " - r: Interfragment distance relative to van-der-Waals radii between ith- and jth-fragment [%]"
          xml.comment "      It show how many times distance from value which sum of van-der-Waals radii of each atom is 1."
          xml.comment "      -1.00 is printed if distances are not computed."
          xml.comment "      Therefore, if covalent bond between fragments is lost, its distance is 0.0."
          xml.comment "      (Ref.): \"RESPAP\" on http://myweb.liu.edu/~nmatsuna/gamess/input/FMO.html"
          xml.comment "        the distance is relative to van der Waals radii; "
          xml.comment "        e.g. two atoms A and B separated by R are defined to have the distance equal to R/(RA+RB),"
          xml.comment "        where RA and RB are van der Waals radii of A and B)."
          xml.comment " - Q(i->j): Charge transfer amount from ith- to jth-fragment, printed as 0.0000 (Zero) if without Mulliken option"
          xml.comment " - E_{ij} - E_{i} - E_{j} [kcal/mol]: "
          xml.comment "   - E_{ij}: Internal energy of dimer (ij)"
          xml.comment "   - E_{i}: Internal energy of monomer (i)"
          xml.comment "   - E_{j}: Internal energy of monomer (j)"
          xml.comment " - Tr(dD^{ij}*V^{ij}): Explicit embedded charge transfer energy [kcal/mol]"
          xml.comment " - E(total) is PIE (pair interaction energy):"
          xml.comment "     total = (EIJ-EI-EJ) + dDIJ*VIJ = Ees + Eex + Ect+mix + Edisp + Gsol [kcal/mol]"
          xml.comment " - Ees: Electrostatic energy [kcal/mol]"
          xml.comment " - Eex: Exchange repulsion energy [kcal/mol]"
          xml.comment " - Ect+mix: Energy for charge transfer + MIX [kcal/mol]"
          xml.comment " - Edisp: Dispersion energy [kcal/mol]"
          xml.comment " - Gsol: Solvation free energy [kcal/mol]"
          xml.two_body_fmo {
            two_body_fmo.each { |d|
              xml.two_body_fmo_data(:ifrag => d[:ifrag], :jfrag => d[:jfrag], :d => d[:d], :d_label => d[:d_label], 
                                    :l => d[:l], :z => d[:z], :r => d[:r], :qij => d[:q_i_j], :eij_ei_ej => d[:eij_ei_ej], 
                                    :dij_vij => d[:dij_vij], :e_total => d[:e_total], :e_es => d[:e_es], :e_ex => d[:e_ex], 
                                    :e_ct_mix => d[:e_ct_mix], :e_disp => d[:e_disp], :g_sol => d[:g_sol])
            }
          }

          xml.comment "Charge transfer for each fragment"
          xml.comment "<Data list>"
          xml.comment " - dfg: (Value: 0, 1, -1)"
          xml.comment " - delta_q: Contains the number of electrons lost by ith-fragment: "
          xml.comment "   delta_q = Q(j1 -> i) + Q(j2 -> i) + ... + Q(jn -> i)"
          xml.comment " - jfrag1 (j1): jth-fragment number of Q(j1 -> i)"
          xml.comment " - q1: Number of electrons lost at j1 by ith-fragment"
          xml.comment "   * Same condition: j1, j2, j3, j4, ..."
          xml.comment "   * Same condition: q1, q2, q3, q4, ..."
          xml.charge_transfer {
            ct.each { |d|
              xml.ct_data(:ifrag => d[:ifrag], :qfg => d[:qfg], :delta_q => d[:delta_q], :jfrag1 => d[:jfrag1], :q1 => d[:q1], 
                          :jfrag2 => d[:jfrag2], :q2 => d[:q2], :jfrag3 => d[:jfrag3], :q3 => d[:q3], 
                          :jfrag4 => d[:jfrag4], :q4 => d[:q4])
            }
          }

          if !(three_body_fmo == []) then
            xml.comment "================================================="
            xml.comment "Three-body FMO properties."
            xml.comment "<Data list>"
            xml.comment " - :"
            xml.comment " - :"
              ###########################################################
              ###########################################################
              ###########################################################
              ###########################################################
              ###########################################################
              ###########################################################
              ###
              ### add "Three-body FMO" comment
              ###
              ###########################################################
              ###########################################################
              ###########################################################
              ###########################################################
              ###########################################################
              ###########################################################
            xml.three_body_fmo {
              three_body_fmo.each { |d|
                xml.three_body_fmo_data(:ifrag => d[:ifrag], :jfrag => d[:jfrag], :kfrag => d[:kfrag], :d => d[:d], 
                                        :d_label => d[:d_label], :l => d[:l])
                  ###########################################################
                  ###########################################################
                  ###########################################################
                  ###########################################################
                  ###########################################################
                  ###########################################################
                  ###
                  ### add "Three-body FMO" data
                  ###
                  ###########################################################
                  ###########################################################
                  ###########################################################
                  ###########################################################
                  ###########################################################
                  ###########################################################
              }
            }
          end
         
          if !(mulliken_charge == []) then
            xml.comment "n-body Mulliken  atomic charges Q(n)"
            xml.comment "<Data list>"
            xml.comment " - IAT: Atom sequence number"
            xml.comment " - IFG: Residue number"
            xml.comment " - Z: Atomic number (%.1f in Out file => int in this program)"
            xml.comment " - Atom name: Symbol defined by Z(Atomic number)"
            xml.comment " - Q(1): 1-body Mulliken atomic charges"
            xml.comment " - Q(2): 2-body Mulliken atomic charges, exact value from the FMO calculation"
            xml.comment " - Q(3): 3-body Mulliken atomic charges"
            xml.mulliken_charge {
              mulliken_charge.each { |d|
                xml.data(:atom_number => d[:atom_num], :residue_number => d[:residue_num], :z => d[:z],
                         :atom_name => d[:atom_name], :q1 => d[:q1], :q2 => d[:q2], :q3 => d[:q3])
              }
            }
          end

          xml.comment "Sum of energy data"
          xml.sum_energy_data {
            xml.comment "Ecorr(1): Total correlated energy of monomer (FMO1-MP2)"
            xml.comment "  E^{FMO1-MP2} = Sigma_{I} E^{''}_{I} [hartree]"
            xml.correlated_energy1_ total_energy[:correlated_energy1]
            xml.comment "Euncorr(1): Total uncorrelated energy of monomer (FMO1-MP2)"
            xml.comment "  Eun^{FMO1-MP2} = Sigma_{I} Eun^{''}_{I} [hartree]"
            xml.uncorrelated_energy1_ total_energy[:uncorrelated_energy1]
            xml.comment "Edelta(1): [hartree]"
            xml.energy_delta1_ total_energy[:energy_delta1]
            xml.comment "D(x) of FMO1 = dx, D(y) = dy, D(z) = dz [Debye]"
            xml.dipole_moment1(:dx => total_energy[:dipole_moment_x1], :dy => total_energy[:dipole_moment_y1], 
                               :dz => total_energy[:dipole_moment_z1])
            xml.comment "DA1: Norm of FMO1 as d_total = (dx**2 + dy**2 + dz**2)**0.5 = D^{FMO1-RHF} [Debye]"
            xml.da1_ total_energy[:norm_da1]
            xml.comment "Ecorr(2): Total correlated energy of monomer (FMO2-MP2), E^{FMO2-MP2} [hartree]"
            xml.correlated_energy2_ total_energy[:correlated_energy2]
            xml.comment "Euncorr(2): Total uncorrelated energy of monomer (FMO2-MP2), Eun^{FMO2-MP2} [hartree]"
            xml.uncorrelated_energy2_ total_energy[:uncorrelated_energy2]
            xml.comment "Edelta(2): [hartree]"
            xml.energy_delta2_ total_energy[:energy_delta2]
            xml.comment "D(x) of FMO2 = dx, D(y) = dy, D(z) = dz [Debye]"
            xml.dipole_moment2(:dx => total_energy[:dipole_moment_x2], :dy => total_energy[:dipole_moment_y2], 
                               :dz => total_energy[:dipole_moment_z2])
            xml.comment "DA2: Norm of FMO2 as d_total = (dx**2 + dy**2 + dz**2)**0.5 = D^{FMO2-RHF} [Debye]"
            xml.da2_ total_energy[:norm_da2]
            xml.comment "Ecorr(3): Total correlated energy of monomer (FMO3-MP2), E^{FMO3-MP2} [hartree]"
            xml.correlated_energy3_ total_energy[:correlated_energy3]
            xml.comment "Euncorr(3): Total uncorrelated energy of monomer (FMO3-MP2), Eun^{FMO3-MP2} [hartree]"
            xml.uncorrelated_energy3_ total_energy[:uncorrelated_energy3]
            xml.comment "Edelta(3): [hartree]"
            xml.energy_delta3_ total_energy[:energy_delta3]
            xml.comment "D(x) of FMO3 = dx, D(y) = dy, D(z) = dz [Debye]"
            xml.dipole_moment3(:dx => total_energy[:dipole_moment_x3], :dy => total_energy[:dipole_moment_y3], 
                               :dz => total_energy[:dipole_moment_z3])
            xml.comment "DA3: Norm of FMO3 as d_total = (dx**2 + dy**2 + dz**2)**0.5 = D^{FMO3-RHF} [Debye]"
            xml.da3_ total_energy[:norm_da3]
            xml.comment "The backbone energy EBB (corrected): EBBcorr(2) [hartree]"
            xml.corrected_ebb2_ total_energy[:corrected_ebb]
            xml.comment "The backbone energy EBB (uncorrected): EBBuncorr(2) [hartree]"
            xml.uncorrected_ebb2_ total_energy[:uncorrected_ebb]
            xml.comment "Total interaction (PL state): "
            xml.comment "  Eint = Sigma_{I>J} Delta_E^{int}_{IJ} = EES + EEX + E(CT+mix) + EDI [kcal/mol]"
            xml.e_int_ total_energy[:e_int]
            xml.comment "Electrostatic (PL state, incl. EPLs): "
            xml.comment "  EES = Sigma_{I>J} Delta_E^{ES}_{IJ} [kcal/mol]"
            xml.e_es_ total_energy[:e_es]
            xml.comment "Exchange (PL state): "
            xml.comment "  EEX = Sigma_{I>J} Delta_E^{EX}_{IJ} [kcal/mol]"
            xml.e_ex_ total_energy[:e_ex]
            xml.comment "Charge transfer (PL state): "
            xml.comment "  E(CT+mix) = Sigma_{I>J} Delta_E^{CT+mix}_{IJ} [kcal/mol]"
            xml.e_ct_mix_ total_energy[:e_ct_mix]
            xml.comment "Dispersion (PL state): "
            xml.comment "  EDI = Sigma_{I>J} Delta_E^{DI}_{IJ} [kcal/mol]"
            xml.e_di_ total_energy[:e_di]
            xml.comment "Total unconnected interaction (PL state):"
            xml.comment "  E'int = E'ES + E'EX + E'(CT+mix) + E'DI [kcal/mol]"
            xml.e_dash_int_ total_energy[:e_dash_int]
            xml.comment "Unconnected electrostatic (PL state, incl. EPLs): E'ES [kcal/mol]"
            xml.e_dash_es_ total_energy[:e_dash_es]
            xml.comment "Unconnected exchange (PL state): E'EX [kcal/mol]"
            xml.e_dash_ex_ total_energy[:e_dash_ex]
            xml.comment "Unconnected charge transfer (PL state): E'(CT+mix) [kcal/mol]"
            xml.e_dash_ct_mix_ total_energy[:e_dash_ct_mix]
            xml.comment "Unconnected dispersion (PL state): E'DI [kcal/mol]"
            xml.e_dash_di_ total_energy[:e_dash_di]
            xml.comment "Total interaction (BDA: Bond-Detached Atom): EintBDA [kcal/mol]"
            xml.e_int_bda_ total_energy[:e_int_bda]
            xml.comment "Electrostatic (BDA): EESBDA [kcal/mol]"
            xml.e_es_bda_ total_energy[:e_es_bda]
            xml.comment "Exchange (BDA): EEXBDA [kcal/mol]"
            xml.e_ex_bda_ total_energy[:e_ex_bda]
            xml.comment "Charge transfer (BDA): E(CT+mix)BDA [kcal/mol]"
            xml.e_ct_mix_bda_ total_energy[:e_ct_mix_bda]
            xml.comment "Dispersion (BDA): EDIBDA [kcal/mol]"
            xml.e_di_bda_ total_energy[:e_di_bda]
          }
        }
      }
    end
    
    File.open(xml_file_path, "w") do |file|
      file.puts Nokogiri::XML(xml_object.to_xml, nil, 'utf-8').to_xml.toutf8
    end
  end
  
  
  #*** Output XML file from Analysed ABINIT-MP data ***#
  def xml_abinitmp(frag_data, abinitmp_header, frag_statistics, out_data, mulliken_charge, total_energy, ifie_energy, ave_data, binding_affinity)
    @header_data["Title"] = "XML for analysed ABINIT-MP data"
    
    xml_file_name = "abinitmp_out.xml"
    xml_file_path = File.join(File.dirname(@opts[:output]), xml_file_name)
    xml_object = Nokogiri::XML::Builder.new do |xml|
      xml.doc.create_internal_subset(
        'html',
        "-//W3C//DTD HTML 4.01 Transitional//EN",
        "http://www.w3.org/TR/html4/loose.dtd"
      )
      xml.data {
        xml.header { 
          @header_data.each { |k, v|
            eval("xml.#{k} { xml.text v }")
          }
          xml.options("comment" => "Options on this analysis ruby program (RbAnalysisFMO.rb)") {
            if @opts[:text] then
              xml.text_ "Show text on terminal with \"-t\""
            else
              xml.text_ "Don\'t show text on terminal with \"-t\""
            end
            xml.fmo_program_ "PAICS"
            if @opts[:paics] == 1 then 
              xml.paics_ver_ "Older versions than PAICS 2012/01/17"
            elsif @opts[:paics] == 2 then 
              xml.paics_ver_ "PAICS 2012/05/13 version or later"
            end
            xml.comment "Calculated PAICS Out file name (/path/.../*.out or ...)"
            xml.out_ @opts[:out]
            xml.comment "PDB file name (/path/.../*.pdb)"
            xml.pdb_ @opts[:pdb]
            xml.comment "Analysed output file name (/path/.../*.[extansion (:TEXT format)])"
            xml.output_ @opts[:output]
            if @opts[:add_chain] == 1 then
              xml.add_chain_ "To continue normally (this process is nothing)"
            elsif @opts[:add_chain] == 2 then
              xml.add_chain_ "Output a new PDB file replacing raw identifier to \"A\""
            end
            if @opts[:interaction] == 1 then
              xml.interaction_ "Selected-pairs mode in \"one-dimensional\" table"
              mode = ["HF   (a.u.) and HF   [kcal/mol]", "dMP2 (a.u.) and dMP2 [kcal/mol]", "MP2  (a.u.) and MP2  [kcal/mol] (All data)'"]
              xml.energy_type_ mode[@opts[:mode] - 1]
              if !(@opts[:gnuplot]) then
                xml.gnuplot_ "Not plot using Gnuplot program"
              else
                xml.gnuplot_ "Plot bar graph using Guplot program"
                xml.distance_ "[#{@opts[:distance][0]}, #{@opts[:distance][1]}]"
                if @opts[:aaletter] == 1 then
                  xml.amino_acid_leter_code_ "Amino Acid 1 letter code on plot"
                elsif @opts[:aaletter] == 2 then
                  xml.amino_acid_leter_code_ "Amino Aicd 3 letter code on plot"
                end
              end
            elsif @opts[:interaction] == 2 then
              xml.interaction_ "All-pairs mode in \"two-dimensional\" table'"
              mode = ["HF (a.u.)", "HF [kcal/mol]", "dMP2 (a.u.)", "dMP2 [kcal/mol]", "MP2  (a.u.)", "MP2  [kcal/mol]"]
              xml.energy_type_ mode[@opts[:mode] - 1]
              xml.comment "Extract data range between i and j fragment [fragment number]"
              xml.fragment_range_ "[#{@opts[:fragment][0]}, #{@opts[:fragment][1]}]"
            end
          }

          xml.fragment_data {
            i = 0
            comment = ["Number of fragments (Max)", "Number of particle fragments (ligands)", 
                       "Particle fragment numbers (ligands)", "Charge of molecule"] 
            frag_data.each { |k, v|
              xml.comment comment[i]
              eval("xml.#{k} { xml.text v }")
              i += 1
            }
          }

          xml.comment "Header of ABINIT-MP for initialized data"
          xml.abinitmp {
            xml.abinitmp_version_ abinitmp_header[:version]
            xml.calculation_method_ abinitmp_header[:method]
            xml.basis_sett_ abinitmp_header[:basis_set]
            xml.total_charge_ abinitmp_header[:charge]
            xml.total_spin_multiplicity_ abinitmp_header[:spin]
            xml.memory_per_processor_ abinitmp_header[:memory]
            xml.read_geometry_ abinitmp_header[:read_geom]
            xml.write_geometry_ abinitmp_header[:write_geom]
            xml.electronic_state_ abinitmp_header[:electronic_state]
            xml.comment "FMO flag => YES: FMO calculation, NO: Conventional MO"
            xml.fmo_flag_ abinitmp_header[:fmo_flag]
            xml.comment "N-body expansion of FMO method"
            xml.n_body_fmo_ abinitmp_header[:n_body_fmo]
            xml.fmo3_ abinitmp_header[:fmo3]
            xml.fmo4_ abinitmp_header[:fmo4]
            xml.comment "ON: auto fragmentation for molecule. if FMO=ON and to set ReadGeom into PDB file path"
            xml.auto_fragmentation_ abinitmp_header[:auto_fragmentation]
            xml.comment "Number of partitions for fragment if AutoFrag=ON"
            xml.frag_size_residue_ abinitmp_header[:frag_size_residue]
            xml.comment "Number of CPU each fragment"
            xml.num_of_cpu_ abinitmp_header[:np]
            xml.comment "ON: calculate BSSE-CP for IFIE"
            xml.cp_corr_ abinitmp_header[:cp_corr]
            xml.comment "fragment pair for calculation target"
            xml.region_ abinitmp_header[:region]
            xml.molecular_formula_ abinitmp_header[:molecular_formula]
            xml.num_of_atoms_ abinitmp_header[:num_of_atoms]
            xml.num_of_electrons_ abinitmp_header[:num_of_electrons]
            xml.num_of_basis_function_ abinitmp_header[:num_basis_func]
          }
        }

        xml.abinitmp_fmo_data {
          xml.comment "Fragment statistics"
          xml.comment " - residue_name and number from ABINIT-MP out data"
          xml.comment " - final_pdb_residue_name and number from:"
          xml.comment "   * The final amino acid data in comparison between input fragment in ABINIT-MP out file and residue data of PDB file"
          xml.comment "<Data list>"
          xml.comment " - Frag. (Fragment number): [5..11]"
          xml.comment " - Residue (Residue name): [12..18]"
          xml.comment " - Seq. (Residue sequence number): [1..4]"
          xml.comment " - Charge of fragment: [40..46]"
          xml.comment " - Chain identifier: [0]"
          xml.comment " - N-term. (N-terminus) (True or False): [30]"
          xml.comment " - C-Term. (C-terminus) (True or False): [39]"
          xml.comment " - S-S bond: [19..23]"
          xml.comment " - Type of polarity: [48..end]"
          xml.comment " - Final PDB residue name"
          xml.comment " - Final PDB residue number"
          xml.comment " - num_of_electrons: Number of electrons in ith-fragment"
          xml.comment " - atom_numbers: Atom numbers contained in the fragment"
          xml.comment " - num_of_ao: Number of AOs each fragment"
          xml.comment " - Non-bonding interfragment interaction energy" 
          xml.comment "   [0]: hartree, [1]: kcal/mol, [2]: kJ/mol"
          xml.comment " - BSSE for non-bonding HF-IFIE or MP2-IFIE" 
          xml.comment "   [0]: hartree, [1]: kcal/mol, [2]: kJ/mol"
          xml.fragment_statistics {
            frag_statistics.each { |d|
              xml.frag_data(:ifrag => d[:ifrag], :residue_name => d[:residue_name], :residue_num => d[:residue_num], 
                            :charge_of_frag => d[:charge], :chain => d[:chain], :final_pdb_residue_name => d[:final_pdb_residue_name], 
                            :final_pdb_residue_number => d[:final_pdb_residue_num], :n_term => d[:n_term], :c_term => d[:c_term],
                            :ss => d[:ss], :tyep_of_polarity => d[:polarity], :num_of_electrons => d[:num_of_elec], 
                            :atom_numbers => d[:atom_num], :num_of_ao => d[:num_of_ao], :non_bonding_ifie=> d[:non_bonding_ifie],
                            :bsse_non_bonding_ifie => d[:bsse_non_bonding_ifie])
            }
          }
 
          xml.atom_data {
            xml.comment "input coordinate of nucleus charge"
            xml.comment " * (x,y,z) is [Angstrom]"
            out_data.each { |d|
              xml.atom_data(:atom_num => d[:atom_num], :atom_name => d[:atom_name], :x => d[:x], :y => d[:y], :z => d[:z])
            }
          }

          xml.comment "FMO energy result"
          xml.comment " - (*_cp = 0.0 is no BSSE correction)"
          xml.comment " - Distance: Calculated distance between ifrag and jfrag amino acids [A]"
          xml.comment "   * If number of particle fragments (ligands) is > 1, distance is average and energy is the sum"
          xml.comment " - \"*_frag\" data is each particle fragments (ligands)"
          xml.comment " - 1 [hartree] = 627.50948 [kcal/mol]"
          xml.comment "<Data list>"
          xml.comment " - ifrag: ith-fragment of dimer between ith and jth: J => i"
          xml.comment " - jfrag: jth-fragment of dimer between ith and jth: I => j"
          xml.comment " - d_label: Flag of DIMER-ES APPROX. (T or F)"
          xml.comment " - d_cp_label: Flag of DIMER-ES APPROX. for BSSE (T or F, B)"
          xml.comment " - hf*: HF-IFIE (HF') [hartree], [kcal/mol], [kJ/mol]"
          xml.comment " - hf_cp*: HF-IFIE (HF') BSSE [hartree], [kcal/mol], [kJ/mol]"
          xml.comment " - dmp2*: MP2-IFIE (dMP2) [hartree], [kcal/mol], [kJ/mol]"
          xml.comment " - dmp2_cp*: MP2-IFIE (dMP2) BSSE [hartree], [kcal/mol], [kJ/mol]"
          xml.comment " - mp2*: MP2 = HF-IFIE (HF') + MP2-IFIE (dMP2) [hartree], [kcal/mol], [kJ/mol]"
          xml.comment " - mp2_cp*: MP2 (BSSE) = (HF-IFIE (HF') BSSE) + (MP2-IFIE (dMP2) BSSE) [hartree], [kcal/mol], [kJ/mol]"
          xml.comment " - pr_type1: PR-TYPE1 [hartree]"
          xml.comment " - pr_type1_cp: PR-TYPE1 (BSSE) [hartree]"
          xml.comment " - grimme: GRIMME [hartree]"
          xml.comment " - grimme_cp: GRIMME (BSSE) [hartree]"
          xml.comment " - jung: Jung (Head-Gordon) SCS energy [hartree]"
          xml.comment " - jung_cp: Jung (Head-Gordon) SCS energy (BSSE) [hartree]"
          xml.comment " - hill_scs: Hill SCS energy [hartree]"
          xml.comment " - hill_scs_cp: Hill SCS energy (BSSE) [hartree]"
          xml.energy_data {
            if frag_data[:particle] == 1 then
              ifie_energy.each { |d|
                xml.ifie(:ifrag => d[:ifrag], :jfrag => d[:jfrag], :distance => d[:distance], :d_label => d[:d_label],
                         :d_cp_label => d[:d_cp_label], :hf => d[:hf], :hfkcal => d[:hfkcal], :hfkj => d[:hfkj], :hf_cp => d[:hf_cp],
                         :hf_cpkcal => d[:hf_cpkcal], :hf_cpkj => d[:hf_cpkj], :dmp2 => d[:dmp2], :dmp2kcal => d[:dmp2kcal],
                         :dmp2kj => d[:dmp2kj], :dmp2_cp => d[:dmp2_cp], :dmp2_cpkcal => d[:dmp2_cpkcal], :dmp2_cpkj => d[:dmp2_cpkj],
                         :mp2 => d[:mp2], :mp2kcal => d[:mp2kcal], :mp2kj => d[:mp2kj], :mp2_cp => d[:mp2_cp], :mp2_cpkcal => d[:mp2_cpkcal],
                         :mp2_cpkj => d[:mp2_cpkj], :pr_type1 => d[:pr_type1], :pr_type1_cp => d[:pr_type1_cp], :grimme => d[:grimme],
                         :grimme_cp => d[:grimme_cp], :jung => d[:jung], :jung_cp => d[:jung_cp], :hill_scs => d[:hill_scs], 
                         :hill_scs_cp => d[:hill_scs_cp])
              }
            elsif frag_data[:particle] > 1  then
              ave_data.each { |d|
                xml.ifie(:ifrag => d[:ifrag], :jfrag => d[:jfrag], :distance => d[:distance], :distance_frag => d[:distance_frag], 
                         :hf => d[:hf], :hf_frag => d[:hf_frag], :hfkcal => d[:hfkcal], :hfkcal_frag => d[:hfkcal_frag], :hfkj => d[:hfkj], 
                         :hfkj_frag => d[:hfkj_frag], :hf_cp => d[:hf_cp], :hf_cp_frag => d[:hf_cp_frag], :hf_cpkcal => d[:hf_cpkcal], 
                         :hf_cpkcal_frag => d[:hf_cpkcal_frag], :hf_cpkj => d[:hf_cpkj], :hf_cpkj_frag => d[:hf_cpkj_frag], :dmp2 => d[:dmp2], 
                         :dmp2_frag => d[:dmp2_frag], :dmp2kcal => d[:dmp2kcal], :dmp2kcal_frag => d[:dmp2kcal_frag], :dmp2kj => d[:dmp2kj], 
                         :dmp2kj_frag => d[:dmp2kj_frag], :dmp2_cp => d[:dmp2_cp], :dmp2_cp_frag => d[:dmp2_cp_frag], :dmp2_cpkcal => d[:dmp2_cpkcal], 
                         :dmp2_cpkcal_frag => d[:dmp2_cpkcal_frag], :dmp2_cpkj => d[:dmp2_cpkj], :dmp2_cpkj_frag => d[:dmp2_cpkj_frag], 
                         :mp2 => d[:mp2], :mp2_frag => d[:mp2_frag], :mp2kcal => d[:mp2kcal], :mp2kcal_frag => d[:mp2kcal_frag], :mp2kj => d[:mp2kj], 
                         :mp2kj_frag => d[:mp2kj_frag], :mp2_cp => d[:mp2_cp], :mp2_cp_frag => d[:mp2_cp_frag], :mp2_cpkcal => d[:mp2_cpkcal], 
                         :mp2_cpkcal_frag => d[:mp2_cpkcal_frag], :mp2_cpkj => d[:mp2_cpkj], :mp2_cpkj_frag => d[:mp2_cpkj_frag], 
                         :pr_type1 => d[:pr_type1], :pr_type1_frag => d[:pr_type1_frag], :pr_type1_cp => d[:pr_type1_cp], 
                         :pr_type1_cp_frag => d[:pr_type1_cp_frag], :grimme => d[:grimme], :grimme_frag => d[:grimme_frag], :grimme_cp => d[:grimme_cp], 
                         :grimme_cp_frag => d[:grimme_cp_frag], :jung => d[:jung], :jung_frag => d[:jung_frag], :jung_cp => d[:jung_cp], 
                         :jung_cp_frag => d[:jung_cp_frag], :hill_scs => d[:hill_scs], :hill_scs_frag => d[:hill_scs_frag], :hill_scs_cp => d[:hill_scs_cp],
                         :hill_scs_cp_frag => d[:hill_scs_cp_frag])
              }
            end
          }

          xml.binding_affinity_ "%f [kcal/mol]"%binding_affinity

          xml.comment "FMO total energy"
          xml.fmo_total_energy {
            xml.comment " - Nuclear repulsion (FMO2-HF)"
            xml.hf_nuclear_repulsion_ total_energy[:hf_nuclear_repulsion]
            xml.comment " - Electronic energy (FMO2-HF)"
            xml.hf_electronic_energy_ total_energy[:hf_electronic_energy]
            xml.comment " - Total (HF) = Electronic energy (FMO2-HF) + Nuclear repulsion (FMO2-HF)"
            xml.hf_total_energy_ total_energy[:hf_total_energy]
            xml.comment " - E(FMO2-MP2)"
            xml.fmo2_mp2_e_ total_energy[:fmo2_mp2_e]
            xml.comment " - Electronic energy (FMO2-MP2)"
            xml.fmo2_mp2_electronic_energy_ total_energy[:fmo2_mp2_electronic_energy]
            xml.comment " - Total (MP2) = Electronic energy (FMO2-MP2) + Nuclear repulsion (FMO2-HF)"
            xml.fmo2_mp2_total_energy_ total_energy[:fmo2_mp2_total_energy]
            xml.comment " - E(FMO2-MP2) of Grimme SCS energy"
            xml.grimme_fmo2_mp2_e_ total_energy[:grimme_fmo2_mp2_e]
            xml.comment " - Electronic energy (FMO2-MP2) of Grimme SCS energy"
            xml.grimme_fmo2_mp2_electronic_energy_ total_energy[:grimme_fmo2_mp2_electronic_energy]
            xml.comment " - Total (Grimme) = Electronic energy (FMO2-MP2 Grimme) + Nuclear repulsion (FMO2-HF)"
            xml.grimme_fmo2_mp2_total_energy_ total_energy[:grimme_fmo2_mp2_total_energy]
            xml.comment " - E(FMO2-MP2) of Jung (Head-Gordon) SCS energy"
            xml.jung_fmo2_mp2_e_ total_energy[:jung_fmo2_mp2_e]
            xml.comment " - Electronic energy (FMO2-MP2) of Jung (Head-Gordon) SCS energy"
            xml.jung_fmo2_mp2_electronic_energy_ total_energy[:jung_fmo2_mp2_electronic_energy]
            xml.comment " - Total (Jung) = Electronic energy (FMO2-MP2 Jung) + Nuclear repulsion (FMO2-HF)"
            xml.jung_fmo2_mp2_total_energy_ total_energy[:jung_fmo2_mp2_total_energy]
            xml.comment " - E(FMO2-MP2) of Hill SCS energy"
            xml.hill_fmo2_mp2_e_ total_energy[:hill_fmo2_mp2_e]
            xml.comment " - Electronic energy (FMO2-MP2) of Hill SCS energy"
            xml.hille_fmo2_mp2_electronic_energy_ total_energy[:hille_fmo2_mp2_electronic_energy]
            xml.comment " - Total (Hill) = Electronic energy (FMO2-MP2 Hill) + Nuclear repulsion (FMO2-HF)"
            xml.hill_fmo2_mp2_total_energy_ total_energy[:hill_fmo2_mp2_total_energy]
          }

          xml.comment "Mulliken atomic population"
          xml.comment "<Data list>"
          xml.comment " - No.: atom number"
          xml.comment " - Atom name"
          xml.comment " - atom_pop: Atomic population (FMO2)"
          xml.comment " - Net charge (FMO2): the arithmetic sum of positive and negative charges"
          xml.comment "   If atomic pop. (FMO2) of N atom is 7.846506, net charge is calculated by -0.846506 (= 7 - 7.846506)."
          xml.mulliken_data {
            mulliken_charge.each { |d|
              xml.mulliken(:atom_num => d[:atom_num], :atom_name => d[:atom_name], :atom_pop => d[:atom_pop], :net_charge => d[:net_charge])
            }
          }
        }
      }
    end

    File.open(xml_file_path, "w") do |file|
      file.puts Nokogiri::XML(xml_object.to_xml, nil, 'utf-8').to_xml.toutf8
    end
  end

end


#**************************************************************************#
#***     Class for plot using gnuplot, convert ps into pdf using gs     ***#
#**************************************************************************#
class Plot
  def initialize(opts, frag_data, dat_file, log)
    @opts = opts
    @frag_data = frag_data
    @dat_file = dat_file
    @log = log
    @plot_data = []
    @ps_files = []
    @plt_files = []
    @ifie_mode = ["HF", "dMP2", "MP2"]
    @gamess_pieda_mode = ["E(es)", "E(ex)", "E(ct+mix)", "E(disp)", "G(sol)", "E(total)", "E_{ij}-E_{i}-E_{j}", "Tr(dD^{ij}*V^{ij})"]
    @abinitmp_pieda_mode = ["E(es)", "E(ex)", "E(ct+mix)", "E(disp)", "E(total)", "G(sol)"]
    @color_palette = ["red", "green", "blue", "purple", "cyan", "yellow", "orange", "light-green", "black"]

    if (@opts[:fmo] == 1) then ### PAICS
      @opts[:distance][0] = 0.0001 if (@opts[:distance][0] == 0.0000)
    elsif (@opts[:fmo] == 2) then ### GAMESS-FMO
      @opts[:distance][0] = 0.01 if (@opts[:distance][0] == 0.00)
    elsif (@opts[:fmo] == 3) then ### ABINIT-MP
      @opts[:distance][0] = 0.000001 if (@opts[:distance][0] == 0.000000)
    end
  end
  
  
  #*** Extract data from analysis data of PDB and PAICS Out using distance at Selected-pairs mode ***#
  def extract_paics_analysis_data(ave_data, final_pdb_res, amino_acid_letter, mode_type, cp_corr)
    i = 0
    k = 0 ### 0 is create new or overwrite ("w"), >= 1 is additional writing ("a")
    data_line = ""
    @dat_file = "1d_energy.dat"
    extract_fragment = []

    if @frag_data[:particle] == 1 then
      while (i < @frag_data[:frag_num][0].to_i - 1) do
        if (ave_data[i][:distance] >= @opts[:distance][0]) and (ave_data[i][:distance] <= @opts[:distance][1]) then
          plot = {
            energy: 0.0,           ### Energy extracted between min distance and max distance
            residue_name: "",      ### Residue name extracted between min distance and max distance
            residue_num: 0,        ### Residue num extracted between min distance and max distance
            chain: "",             ### Chain identifier extracted between min distance and max distance
            energy_component: [],  ### In the case of MP2, [0] => HF [kcal/mol], [1] => dMP2 [kcal/mol]
            frag_energy: [],       ### Energy of fragments extracted between min distance and max distance
           }
          plot[:energy] = ave_data[i][mode_type]
          plot[:residue_num] = final_pdb_res[i][:residue_num]
          plot[:chain] = final_pdb_res[i][:chain]
          if (cp_corr) then
            plot[:energy_component] = [ave_data[i][:hf_cpkcal], ave_data[i][:dmp2_cpkcal]]
          else
            plot[:energy_component] = [ave_data[i][:hfkcal], ave_data[i][:dmp2kcal]]
          end
          plot[:frag_energy][0] = ave_data[i][mode_type]
          if @opts[:aaletter] == 1 then ### One letter code
            plot[:residue_name] = final_pdb_res[i][:one_letter]
          elsif @opts[:aaletter] == 2 then ### Three letter code
            plot[:residue_name] = final_pdb_res[i][:residue_name]
          end
          if (@opts[:mode] == 3) then ### MP2
            ### data line (1d_energy.dat):
            ###  "Num E(MP2) E(HF) E(dMP2)"
            data_line = "%i %f"%[k + 1, plot[:energy]]
            plot[:energy_component].each { |e|
              data_line += " %f"%e
            }
            data_line += "\n"
          else ### Other
            ### data line (1d_energy.dat):
            ###  "Num E(you selected)"
            data_line = "%i %f\n"%[k + 1, plot[:energy]]
          end
          if k == 0 then ### 0 is create new or overwrite ("w")
            Write_data.new.write_data(data_line, @opts, 0, @log, @dat_file)
          else ### >= 1 is additional writing ("a")
            Write_data.new.write_data(data_line, @opts, 1, @log, @dat_file)
          end
          @plot_data << plot
          k += 1
        end
        i += 1
      end
    else ### Particles of Fragment (Ligand) are not 1, therefore more than two particles
      for i in 0..(@frag_data[:frag_num][0] - 2)
        for j in 0..(@frag_data[:particle] - 1)
          if (ave_data[i][:distance_frag][j] >= @opts[:distance][0]) and (ave_data[i][:distance_frag][j] <= @opts[:distance][1]) then
             extract_fragment << i + 1
          end
        end
      end
      extract_fragment.uniq!.sort

      mode_frag_type = (mode_type.to_s + "_frag").to_sym ### Convert string to symbol
      for i in 0..(extract_fragment.size - 1)
        plot = {
          energy: 0.0,           ### Energy extracted between min distance and max distance
          res_name: "",          ### Residue name extracted between min distance and max distance
          res_num: "",           ### Residue num extracted between min distance and max distance
          chain: "",             ### Chain identifier extracted between min distance and max distance
          energy_component: [],  ### 
          frag_energy: [],       ### Energy of fragments extracted between min distance and max distance
        }
        plot[:energy] = ave_data[extract_fragment[i] - 1][mode_type]
        plot[:residue_num] = final_pdb_res[extract_fragment[i] - 1][:residue_num]
        plot[:chain] = final_pdb_res[extract_fragment[i] - 1][:chain]
######################################
######################################
######################################
######################################
######################################
########plot[:energy_component]#######
######################################
######################################
######################################
######################################
######################################
######################################
        plot[:frag_energy] = ave_data[extract_fragment[i] - 1][mode_frag_type]
        if @opts[:aaletter] == 1 then ### One letter code
          plot[:residue_name] = final_pdb_res[extract_fragment[i] - 1][:one_letter]
        elsif @opts[:aaletter] == 2 then ### Three letter code
          plot[:residue_name] = final_pdb_res[extract_fragment[i] - 1][:residue_name]
        end
        ### data line (1d_energy.dat):
        ###  "Num E(total) E(frag(1)) E(frag(2)) ... E(frag(n))"
        ###    * E(total) = E(frag(1)) + E(frag(2)) + ... + E(frag(n))
        data_line = "%i %f"%[k + 1, plot[:energy]]
        plot[:frag_energy].each { |e|
          data_line += " %f"%e
         }
        data_line += "\n"
        if k == 0 then ### 0 is create new or overwrite ("w")
          Write_data.new.write_data(data_line, @opts, 0, @log, @dat_file)
        else ### >= 1 is additional writing ("a")
          Write_data.new.write_data(data_line, @opts, 1, @log, @dat_file)
        end
        @plot_data << plot
        k += 1
      end
    end
  end
  
  
  #*** Extract data from analysis data of PDB and GAMESS-FMO Out using distance at Selected-pairs mode ***#
  def extract_gamess_analysis_data(ave_data, frag_statistics)
    i = 0
    k = 0 ### 0 is create new or overwrite ("w"), >= 1 is additional writing ("a")
    data_line = ""
    @dat_file = "1d_energy.dat"
    
    ### Extract "E_{tot}" data only for ploting using Gnuplot!!
    if @frag_data[:particle] == 1 then
      while (i < @frag_data[:frag_num][0].to_i - 1) do
        if (ave_data[i][:r] >= @opts[:distance][0]) and (ave_data[i][:r] <= @opts[:distance][1]) then
          plot = {
            energy: 0.0,           ### Energy (E_{tot}) extracted between min distance and max distance
            residue_name: "",      ### Residue name extracted between min distance and max distance
            residue_num: 0,        ### Residue num extracted between min distance and max distance
            chain: "",             ### Chain identifier extracted between min distance and max distance
            energy_component: [],  ### [0] => E_{es}, [1] => E_{ex}, [2] => E_{ct+mix}, [3] => E_{disp}, [4] => G_{sol}
                                   ###   * E_{es} + E_{ex} + E_{ct+mix} + E_{disp} + G_{sol} = E_{tot}
            frag_energy: [],       ### Energy (E_{tot}) of fragments extracted between min distance and max distance
           }
          plot[:energy] = ave_data[i][:e_total]
          plot[:residue_num] = frag_statistics[i][:final_pdb_residue_num]
          plot[:chain] = frag_statistics[i][:chain]
          plot[:energy_component] = [ave_data[i][:e_es], ave_data[i][:e_ex], ave_data[i][:e_ct_mix], ave_data[i][:e_disp], ave_data[i][:g_sol]]
          plot[:frag_energy][0] = ave_data[i][:e_total]
          if @opts[:aaletter] == 1 then ### One letter code
            plot[:residue_name] = convert_amino_acide_letter_code(frag_statistics[i][:final_pdb_residue_name])
          elsif @opts[:aaletter] == 2 then ### Three letter code
            plot[:residue_name] = frag_statistics[i][:final_pdb_residue_name]
          end
          ### data line (1d_energy.dat):
          ###   "Num E_{tot} E_{es} E_{ex} E_{ct+mix} E_{disp} G_{sol}"
          data_line = "%i %f"%[k + 1, plot[:energy]]
          plot[:energy_component].each { |e|
            data_line += " %f"%e
          }
          data_line += "\n"
          if k == 0 then
            Write_data.new.write_data(data_line, @opts, 0, @log, @dat_file)
          else
            Write_data.new.write_data(data_line, @opts, 1, @log, @dat_file)
          end
          @plot_data << plot
          k += 1
        end
        i += 1
      end
    else ### Particles of Fragment (Ligand) are not 1, therefore more than two particles
      for i in 0..(@frag_data[:frag_num][0] - 2)
        for j in 0..(@frag_data[:particle] - 1)
          if (ave_data[i][:distance_frag][j] >= @opts[:distance][0]) and (ave_data[i][:distance_frag][j] <= @opts[:distance][1]) then
             extract_fragment << i + 1
          end
        end
      end
      extract_fragment.uniq!.sort

      for i in 0..(extract_fragment.size - 1)
        plot = {
          energy: 0.0,           ### Energy (E_{tot}) extracted between min distance and max distance
          residue_name: "",      ### Residue name extracted between min distance and max distance
          residue_num: 0,        ### Residue num extracted between min distance and max distance
          chain: "",             ### Chain identifier extracted between min distance and max distance
          energy_component: [],  ### [0] => E_{es}, [1] => E_{ex}, [2] => E_{ct+mix}, [3] => E_{disp}, [4] => G_{sol}
                                 ###   * E_{es} + E_{ex} + E_{ct+mix} + E_{disp} + G_{sol} = E_{tot}
          frag_energy: [],       ### Energy of fragments extracted between min distance and max distance
         }
        plot[:energy] = ave_data[extract_fragment[i] - 1][:e_total]
        plot[:residue_num] = frag_statistics[extract_fragment[i] - 1][:final_pdb_residue_num]
        plot[:chain] = frag_statistics[extract_fragment[i] - 1][:chain]
######################################
######################################
######################################
######################################
######################################
########plot[:energy_component]#######
######################################
######################################
######################################
######################################
######################################
######################################
        plot[:frag_energy] = ave_data[extract_fragment[i] - 1][:e_total_frag]
        if @opts[:aaletter] == 1 then ### One letter code
          if letter_code.select{|x| x[:name] == frag_statistics[extract_fragment[i] - 1][:final_pdb_residue_name]}[0] == nil then
            plot[:residue_name] = "X"
          else
            plot[:residue_name] = letter_code.select{|x| x[:name] == frag_statistics[extract_fragment[i] - 1][:final_pdb_residue_name]}[0][:one_letter]
          end
        elsif @opts[:aaletter] == 2 then ### Three letter code
          plot[:residue_name] = frag_statistics[extract_fragment[i] - 1][:final_pdb_residue_name]
        end
        ### data line (1d_energy.dat):
        ###  "Num E_{tot}(total) E_{tot}(frag(1)) E_{tot}(frag(2)) ... E_{tot}(frag(n))"
        ###    * E_{tot}(total) = E_{tot}(frag(1)) + E_{tot}(frag(2)) + ... + E_{tot}(frag(n))
        data_line = "%i %f"%[k + 1, plot[:energy]]
        plot[:frag_energy].each {|e|
          data_line += " %f"%e
        }
        data_line += "\n"
        if k == 0 then
          Write_data.new.write_data(data_line, @opts, 0, @log, @dat_file)
        else
          Write_data.new.write_data(data_line, @opts, 1, @log, @dat_file)
        end
        @plot_data << plot
        k += 1
      end
    end
  end
  
  
  #*** Extract data from analysis data of PDB and ABINIT-MP Out using distance at Selected-pairs mode ***#
  def extract_abinitmp_analysis_data(ave_data, ave_pieda_data, frag_statistics, mode_type, abinitmp_e)
    i = 0
    k = 0 ### 0 is create new or overwrite ("w"), >= 1 is additional writing ("a")
    data_line = ""
    @dat_file = "1d_energy.dat"
    extract_fragment = []

    if @frag_data[:particle] == 1 then
      while (i < @frag_data[:frag_num][0].to_i - 1) do
        if (ave_data[i][:distance] >= @opts[:distance][0]) and (ave_data[i][:distance] <= @opts[:distance][1]) then
          plot = {
            energy: 0.0,           ### Energy extracted between min distance and max distance
            residue_name: "",      ### Residue name extracted between min distance and max distance
            residue_num: 0,        ### Residue num extracted between min distance and max distance
            chain: "",             ### Chain identifier extracted between min distance and max distance
            energy_component: [],  ### IFIE: [0] => HF [kcal/mol], [1] => dMP2 [kcal/mol]
                                   ### PIEDA: [0] => E_{es}, [1] => E_{ex}, [2] => E_{ct+mix}, [3] => E_{disp}, [4] => G_{sol}
            frag_energy: [],       ### Energy of fragments extracted between min distance and max distance
           }
          if abinitmp_e == 1 then ### IFIE
            plot[:energy] = ave_data[i][mode_type]
            plot[:frag_energy][0] = ave_data[i][mode_type]
            plot[:energy_component] = [ave_data[i][:hfkcal], ave_data[i][:dmp2kcal]]
          elsif abinitmp_e == 2 then ### PIEDA
            plot[:energy] = ave_pieda_data[i][mode_type]
            plot[:frag_energy][0] = ave_pieda_data[i][mode_type]
            plot[:energy_component] = [ave_data[i][:e_es], ave_data[i][:e_ex], ave_data[i][:e_ct_mix], ave_data[i][:e_disp], ave_data[i][:g_sol]]
          end
          plot[:residue_num] = frag_statistics[i][:final_pdb_residue_num]
          plot[:chain] = frag_statistics[i][:chain]
          if @opts[:aaletter] == 1 then ### One letter code
            plot[:residue_name] = convert_amino_acide_letter_code(frag_statistics[i][:final_pdb_residue_name])
          elsif @opts[:aaletter] == 2 then ### Three letter code
            plot[:residue_name] = frag_statistics[i][:final_pdb_residue_name]
          end
          ### data line (1d_energy.dat):
          ###  "Num E(you selected), ..."
          data_line = "%i %f"%[k + 1, plot[:energy]]
          plot[:energy_component].each { |e|
            data_line += " %f"%e
          }
          data_line += "\n"
          if k == 0 then ### 0 is create new or overwrite ("w")
            Write_data.new.write_data(data_line, @opts, 0, @log, @dat_file)
          else ### >= 1 is additional writing ("a")
            Write_data.new.write_data(data_line, @opts, 1, @log, @dat_file)
          end
          @plot_data << plot
          k += 1
        end
        i += 1
      end
    else ### Particles of Fragment (Ligand) are not 1, therefore more than two particles
      for i in 0..(@frag_data[:frag_num][0] - 2)
        for j in 0..(@frag_data[:particle] - 1)
          if (ave_data[i][:distance_frag][j] >= @opts[:distance][0]) and (ave_data[i][:distance_frag][j] <= @opts[:distance][1]) then
             extract_fragment << i + 1
          end
        end
      end
      extract_fragment.uniq!.sort
      mode_frag_type = (mode_type.to_s + "_frag").to_sym ### Convert string to symbol
      for i in 0..(extract_fragment.size - 1)
        plot = {
          energy: 0.0,           ### Energy extracted between min distance and max distance
          res_name: "",          ### Residue name extracted between min distance and max distance
          res_num: "",           ### Residue num extracted between min distance and max distance
          chain: "",             ### Chain identifier extracted between min distance and max distance
          energy_component: [],  ###
          frag_energy: [],       ### Energy of fragments extracted between min distance and max distance
        }
        if abinitmp_e == 1 then ### IFIE
          plot[:energy] = ave_data[extract_fragment[i] - 1][mode_type]
          plot[:frag_energy] = ave_data[extract_fragment[i] - 1][mode_frag_type]
        elsif abinitmp_e == 2 then ### PIEDA
          plot[:energy] = ave_pieda_data[extract_fragment[i] - 1][mode_type]
          plot[:frag_energy][0] = ave_pieda_data[extract_fragment[i] - 1][mode_frag_type]
        end

        plot[:residue_num] = frag_statistics[extract_fragment[i] - 1][:final_pdb_residue_num]
        plot[:chain] = frag_statistics[extract_fragment[i] - 1][:chain]
######################################
######################################
######################################
######################################
######################################
########plot[:energy_component]#######
######################################
######################################
######################################
######################################
######################################
######################################
        if @opts[:aaletter] == 1 then ### One letter code
          plot[:residue_name] = convert_amino_acide_letter_code(frag_statistics[i][:final_pdb_residue_name])
        elsif @opts[:aaletter] == 2 then ### Three letter code
          plot[:residue_name] = frag_statistics[extract_fragment[i] - 1][:final_pdb_residue_name]
        end
        ### data line (1d_energy.dat):
        ###  "Num E(total) E(frag(1)) E(frag(2)) ... E(frag(n))"
        ###    * E(total) = E(frag(1)) + E(frag(2)) + ... + E(frag(n))
        data_line = "%i %f"%[k + 1, plot[:energy]]
        plot[:frag_energy].each {|e|
          data_line += " %f"%e
        }
        data_line += "\n"
        if k == 0 then ### 0 is create new or overwrite ("w")
          Write_data.new.write_data(data_line, @opts, 0, @log, @dat_file)
        else ### >= 1 is additional writing ("a")
          Write_data.new.write_data(data_line, @opts, 1, @log, @dat_file)
        end
        @plot_data << plot
        k += 1
      end
    end
  end
  
  
  #*** Make plt file for 1-dimensional table ***#
  def make_one_d_plt(program)
    ### 1. "1d_pharmacophores"
    ###   "Sum" interaction energy by adding the interaction energy of each particle ligands, which Illustrated in histogram
    ###   (ex.) 
    ###      Due to the large number of molecules of the ligand, this ligand is divided into particles (= particle ligands).
    ###      (In PAICS,) the internal energy (E(frag)) is calculated by FMO for each divided (particle) ligand.
    ###        * E(total) = E(frag(1)) + E(frag(2)) + ... + E(frag(n))
    ###      "1d_pharmacophores.ps" is illustrated with histogram of E(frag(1)), E(frag(2)), ..., and E(frag(n)) stacked.
    ###
    ### 2. "1d_histogram"
    ###   Histogram of energy components divided by the energy division method.
    ###   - PAICS: 
    ###            Two energy componets based on IFIE (HF, dMP2)
    ###   - GAMESS: 
    ###            Five energy componets based on PIE (E_{es}, E_{ex}, E_{ct+mix}, E_{disp}, G_{sol})
    ###   - ABINIT-MP:
    ###            Two energy componets based on IFIE (HF, dMP2)
    ###            Four energy componets based on PIEDA (E_{es}, E_{ex}, E_{ct+mix}, E_{disp})
    ### 
    @ps_files = ["1d_total.ps", "1d_pharmacophores.ps", "1d_histogram.ps"]
    @plt_files = ["setting_1d_total.plt", "setting_1d_pharmacophores.plt", "setting_1d_histogram.plt"]
    
    ### 1D total
    write_one_d_total_plt(program)
    
    ### 1D pharmacophores
    if !(@plot_data[0][:frag_energy].size == 1) then
      write_one_d_pharmacophores_plt(program)
    else  ### particle == 1
      @plt_files[1] = ""
      @ps_files[1] = ""
    end
    
    ### 1D stacked histogram
    if (program == "paics" and @opts[:mode] == 3) or (program == "gamess-fmo") or 
       (program == "abinit-mp" and (@opts[:abinitmp] == 2 or (@opts[:abinitmp] == 1 and @opts[:mode] == 3))) then
      if (@plot_data[0][:frag_energy].size == 1) then ### No pharmacophores
        write_one_d_histogram_plt(program)
      else ### Pharmacophores
        @plt_files[2] = ""
        @ps_files[2] = ""
      end
    else
      @plt_files[2] = ""
      @ps_files[2] = ""
    end
  end
  
  
  #*** Write plt file for 1D total ***#
  def write_one_d_total_plt(program)
    data_line = "reset\nunset key\n"
    data_line += "set key font \"Times-Roman\"\n" ### Set font to "Times new roman"
    
    ########################################################################
    ### This setting operation (set label 1 at screen ...) does not work ###
    ### in the version less than gnuplot4.4!                             ###
    ########################################################################
    if program == "paics" then
      fig_title_total = "Fig.  Total interfragment interaction energies (IFIEs) at the #{@ifie_mode[@opts[:mode].to_i - 1]} level [kcal/mol]"
#      data_line += "set title \"#{fig_title_total}\" center at screen\n"
      data_line += "set label 1 at screen  0.15, -0.03 \"#{fig_title_total}\" \n"
    elsif program == "gamess-fmo" then
      fig_title_total = "Fig.  Total pair interaction energy (PIE) at the #{@gamess_pieda_mode[@opts[:mode].to_i - 1]} level [kcal/mol]"
#      data_line += "set title \"#{fig_title_total}\" center at screen\n"
      data_line += "set label 1 at screen  0.30, -0.03 \"#{fig_title_total}\" \n"
    elsif program == "abinit-mp" then
      if (@opts[:abinitmp] == 1) then ### IFIE
        fig_title_total = "Fig.  Total interfragment interaction energies (IFIEs) at the #{@ifie_mode[@opts[:mode].to_i - 1]} level [kcal/mol]"
#        data_line += "set title \"#{fig_title_total}\" center at screen\n"
        data_line += "set label 1 at screen  0.15, -0.03 \"#{fig_title_total}\" \n"
      elsif (@opts[:abinitmp] == 2) then ### PIEDA
        fig_title_total = "Fig.  Total pair interaction energy (PIE) at the #{@abinitmp_pieda_mode[@opts[:mode].to_i - 1]} level [kcal/mol]"
#        data_line += "set title \"#{fig_title_total}\" center at screen\n"
        data_line += "set label 1 at screen  0.30, -0.03 \"#{fig_title_total}\" \n"
      end
    end
    
    energy_min = @plot_data.min{|x, y| x[:energy] <=> y[:energy]}[:energy]
    energy_max = @plot_data.max{|x, y| x[:energy] <=> y[:energy]}[:energy]
    
    (y_min, y_max, y_label_position) = cal_yrange(energy_min, energy_max)
    
#    data_line += "set xlabel \"Residue number\"\n"
    data_line += "set ylabel \"Interaction energy [kcal/mol]\"\n"
    data_line += "set xrange [-2.0 : %s]\n"%(@plot_data.size + 2.0)
    data_line += "set yrange [ %s : %s ]\n"%[y_min, y_max]
    data_line += "set xtics -10, 999999\n"
    data_line += "set xzeroaxis lt -1\n"
    Write_data.new.write_data(data_line, @opts, 0, @log, @plt_files[0])
    
    for i in 0..(@plot_data.size - 1)
      res_name = "%s%s %s"%[@plot_data[i][:residue_name], @plot_data[i][:residue_num], @plot_data[i][:chain]]
      data_line = "set label \"%s\" at %s, %f rotate by 90\n"%[res_name, i, y_label_position]
      Write_data.new.write_data(data_line, @opts, 1, @log, @plt_files[0])
    end
    
    data_line = "set style fill solid border lc rgb \"black\"\n"
    
    data_line += "#" ### Don't plot in GUI window for using this comment "#"
    data_line += "plot '#{@dat_file}' using 2 w boxes lw 1 lc rgb \"#{@color_palette[0]}\" notitle\n"
    data_line += "set term post c\n"
    data_line += "set output '#{@ps_files[0]}'\n"  ### For ps file
#    data_line += "set output '#{ps_files[0].tr(".ps", ".eps")}'\n" ### For eps file
    data_line += "set boxwidth 0.7\n"
    data_line += "plot '#{@dat_file}' using 2 w boxes lw 1 lc rgb \"#{@color_palette[0]}\" notitle\n"
    data_line += "unset output\n"
    data_line += "exit\n"
    Write_data.new.write_data(data_line, @opts, 1, @log, @plt_files[0])
  end
  
  
  #*** Write plt file for 1D pharmacophores ***#
  def write_one_d_pharmacophores_plt(program)
    negative_val_sum = []
    positive_val_sum = []
    data_line = "reset\nunset key\n"
    data_line += "set key font \"Times-Roman\"\n"  ### Set font to "Times new roman"
    
    ########################################################################
    ### This setting operation (set label 1 at screen ...) does not work ###
    ### in the version less than gnuplot4.4!                             ###
    ########################################################################
    if program == "paics" then
      fig_title_total = "Fig.  Total interfragment interaction energies (IFIEs) of pharmacophores at the #{@ifie_mode[@opts[:mode].to_i - 1]} level [kcal/mol]"
#      data_line += "set title \"#{fig_title_total}\" center at screen\n"
      data_line += "set label 1 at screen  0.15, -0.03 \"#{fig_title_total}\" \n"
    elsif program == "gamess-fmo" then
      fig_title_total = "Fig.  Total pair interaction energy (PIE) of pharmacophores at the #{@gamess_pieda_mode[@opts[:mode].to_i - 1]} level [kcal/mol]"
#      data_line += "set title \"#{fig_title_total}\" center at screen\n"
#      data_line += "set label 1 at screen  0.30, -0.03 \"#{fig_title_total}\" \n"
      data_line += "set label 1 at screen  0.15, -0.03 \"#{fig_title_total}\" \n"
    elsif program == "abinit-mp" then
      if (@opts[:abinitmp] == 2) then ### PIEDA
        fig_title_total = "Fig.  Total pair interaction energy (PIE) of pharmacophores at the #{@abinitmp_pieda_mode[@opts[:mode].to_i - 1]} level [kcal/mol]"
      elsif (@opts[:abinitmp] == 1) then ### IFIE
        fig_title_total = "Fig.  Total interfragment interaction energies (IFIEs) of pharmacophores at the #{@ifie_mode[@opts[:mode].to_i - 1]} level [kcal/mol]"
      end
#      data_line += "set title \"#{fig_title_total}\" center at screen\n"
#      data_line += "set label 1 at screen  0.30, -0.03 \"#{fig_title_total}\" \n"
      data_line += "set label 1 at screen  0.15, -0.03 \"#{fig_title_total}\" \n"
    end
    
    for i in 0..(@plot_data.size - 1)
      n_val = 0
      p_val = 0
      @plot_data[i][:frag_energy].each { |val|
        if (val.negative?) then ### negative number
          n_val += val
        else ### positive number
          p_val += val
        end
#        negative_val_sum << val.select{|num| num.negative?}.inject(:+)
#        positive_val_sum << val.select{|num| num.positive?}.inject(:+)
      }
      negative_val_sum << n_val
      positive_val_sum << p_val
    end
    (y_min, y_max, y_label_position) = cal_yrange(negative_val_sum.min, positive_val_sum.max)
    
#    data_line += "set xlabel \"Residue number\"\n"
    data_line += "set ylabel \"Interaction energy [kcal/mol]\"\n"
    data_line += "set xrange [-2.0 : %s]\n"%(@plot_data.size + 8.0)
#    energy_pharm_min = @plot_data.min{|x, y| x[:frag_energy].flat_map {|i| i} <=> y[:frag_energy].flat_map {|i| i}}[:frag_energy].min.to_f
#    energy_pharm_max = @plot_data.min{|x, y| x[:frag_energy].flat_map {|i| i} <=> y[:frag_energy].flat_map {|i| i}}[:frag_energy].max.to_f
#    data_line += "set yrange [ %s : %s ]\n"%[energy_pharm_min - 5.0, energy_pharm_max + 28.0]
    data_line += "set yrange [%s : %s]\n"%[y_min, y_max]
    data_line += "set xtics -10, 999999\n"
    data_line += "set xzeroaxis lt -1\n"
    
    Write_data.new.write_data(data_line, @opts, 0, @log, @plt_files[1])
    for i in 0..(@plot_data.size - 1)
      res_name = "%s%s %s"%[@plot_data[i][:residue_name], @plot_data[i][:residue_num], @plot_data[i][:chain]]
      data_line = "set label \"%s\" at %s, %f rotate by 90\n"%[res_name, i, y_label_position]
      Write_data.new.write_data(data_line, @opts, 1, @log, @plt_files[1])
    end
    
    data_line = "set style histogram rowstacked\n"  ### Plot style: Histogram
    data_line += "set style fill solid border lc rgb \"black\"\n"
    data_line += "#"
    for i in (0..@frag_data[:particle] - 1)
      if i < @color_palette.size then
        palette = @color_palette[i]
      else 
        palette = @color_palette[i - @color_palette.size]
      end
      if (i == 0) then
        data_line += "plot '#{@dat_file}' using #{i + 3} w histogram lw 1 lc rgb \"#{palette}\" title \"#{@frag_data[:frag_num][i]}\", \\\n"
      elsif (i == @frag_data[:particle] - 1) then
        data_line += "     '#{@dat_file}' using #{i + 3} w histogram lw 1 lc rgb \"#{palette}\" title \"#{@frag_data[:frag_num][i]}\"\n"
      else
        data_line += "     '#{@dat_file}' using #{i + 3} w histogram lw 1 lc rgb \"#{palette}\" title \"#{@frag_data[:frag_num][i]}\", \\\n"
      end
    end
    data_line += "set term post c\n"
    data_line += "set output '#{@ps_files[1]}'\n"
#    data_line += "set output '#{@ps_files[0].tr(".ps", ".eps")}'\n"
    data_line += "set boxwidth 0.7\n"
    for i in (0..@frag_data[:particle] - 1)
      if i < @color_palette.size then
        palette = @color_palette[i]
      else 
        palette = @color_palette[i - @color_palette.size]
      end
      if (i == 0) then
        data_line += "plot '#{@dat_file}' using #{i + 3} w histogram lw 1 lc rgb \"#{palette}\" title \"#{@frag_data[:frag_num][i]}\", \\\n"
      elsif (i == @frag_data[:particle] - 1) then
        data_line += "     '#{@dat_file}' using #{i + 3} w histogram lw 1 lc rgb \"#{palette}\" title \"#{@frag_data[:frag_num][i]}\"\n"
      else
        data_line += "     '#{@dat_file}' using #{i + 3} w histogram lw 1 lc rgb \"#{palette}\" title \"#{@frag_data[:frag_num][i]}\", \\\n"
      end
    end
    data_line += "unset output\n"
    data_line += "exit\n"
    Write_data.new.write_data(data_line, @opts, 1, @log, @plt_files[1])
  end
  
  
  #*** Write plt file for 1D stacked histogram ***#
  def write_one_d_histogram_plt(program)
    negative_val_sum = []
    positive_val_sum = []
    data_line = "reset\nunset key\n"
    data_line += "set key font \"Times-Roman\"\n"  ### Set font to "Times new roman"
    
    ########################################################################
    ### This setting operation (set label 1 at screen ...) does not work ###
    ### in the version less than gnuplot4.4!                             ###
    ########################################################################
    if (program == "paics") or (program == "abinit-mp" and @opts[:abinitmp] == 1) then ### IFIE
      fig_title_total = "Fig.  Stacked histogram for total interfragment interaction energies (IFIEs) [kcal/mol]"
#      data_line += "set title \"#{fig_title_total}\" center at screen\n"
      data_line += "set label 1 at screen  0.15, -0.03 \"#{fig_title_total}\" \n"
      legend_name = @ifie_mode[0..(@ifie_mode.size - 2)]
    elsif (program == "gamess-fmo") then ### PIE
      fig_title_total = "Fig.  Stacked histogram for total pair interaction energy (PIE) [kcal/mol]"
#      data_line += "set title \"#{fig_title_total}\" center at screen\n"
#      data_line += "set label 1 at screen  0.30, -0.03 \"#{fig_title_total}\" \n"
      data_line += "set label 1 at screen  0.15, -0.03 \"#{fig_title_total}\" \n"
      legend_name = @gamess_pieda_mode[0..(@gamess_pieda_mode.size - 4)]
    elsif (program == "abinit-mp" and @opts[:abinitmp] == 2) then
      fig_title_total = "Fig.  Stacked histogram for total pair interaction energy (PIE) [kcal/mol]"
#      data_line += "set title \"#{fig_title_total}\" center at screen\n"
#      data_line += "set label 1 at screen  0.30, -0.03 \"#{fig_title_total}\" \n"
      data_line += "set label 1 at screen  0.15, -0.03 \"#{fig_title_total}\" \n"
      legend_name = @abinitmp_pieda_mode[0..(@abinitmp_pieda_mode.size - 3)]
    end
    
    for i in 0..(@plot_data.size - 1)
      n_val = 0
      p_val = 0
      @plot_data[i][:energy_component].each { |val|
        if (val.negative?) then ### negative number
          n_val += val
        else ### positive number
          p_val += val
        end
#        negative_val_sum << val.select{|num| num.negative?}.inject(:+)
#        positive_val_sum << val.select{|num| num.positive?}.inject(:+)
      }
      negative_val_sum << n_val
      positive_val_sum << p_val
    end
    (y_min, y_max, y_label_position) = cal_yrange(negative_val_sum.min, positive_val_sum.max)
    
#    data_line += "set xlabel \"Residue number\"\n"
    data_line += "set ylabel \"Interaction energy [kcal/mol]\"\n"
    data_line += "set xrange [-2.0 : %s]\n"%(@plot_data.size + 8.0)
#    energy_pharm_min = @plot_data.min{|x, y| x[:frag_energy].flat_map {|i| i} <=> y[:frag_energy].flat_map {|i| i}}[:frag_energy].min.to_f
#    energy_pharm_max = @plot_data.min{|x, y| x[:frag_energy].flat_map {|i| i} <=> y[:frag_energy].flat_map {|i| i}}[:frag_energy].max.to_f
#    data_line += "set yrange [ %s : %s ]\n"%[energy_pharm_min - 5.0, energy_pharm_max + 28.0]
    data_line += "set yrange [%s : %s]\n"%[y_min, y_max]
    data_line += "set xtics -10, 999999\n"
    data_line += "set xzeroaxis lt -1\n"
    
    Write_data.new.write_data(data_line, @opts, 0, @log, @plt_files[2])
    for i in 0..(@plot_data.size - 1)
      res_name = "%s%s %s"%[@plot_data[i][:residue_name], @plot_data[i][:residue_num], @plot_data[i][:chain]]
      data_line = "set label \"%s\" at %s, %f rotate by 90\n"%[res_name, i, y_label_position]
      Write_data.new.write_data(data_line, @opts, 1, @log, @plt_files[2])
    end
    
    data_line = "set style histogram rowstacked\n"  ### Plot style: "Stacked histogram"
    data_line += "set style fill solid border lc rgb \"black\"\n"
    data_line += "#"
    for i in (0..legend_name.size - 1)
      if i < @color_palette.size then
        palette = @color_palette[i]
      else 
        palette = @color_palette[i - @color_palette.size]
      end
      if (i == 0) then
        data_line += "plot '#{@dat_file}' using #{i + 3} w histogram lw 1 lc rgb \"#{palette}\" title \"#{legend_name[i]}\", \\\n"
      elsif (i == legend_name.size - 1) then
        data_line += "     '#{@dat_file}' using #{i + 3} w histogram lw 1 lc rgb \"#{palette}\" title \"#{legend_name[i]}\"\n"
      else
        data_line += "     '#{@dat_file}' using #{i + 3} w histogram lw 1 lc rgb \"#{palette}\" title \"#{legend_name[i]}\", \\\n"
      end
    end
    data_line += "set term post c\n"
    data_line += "set output '#{@ps_files[2]}'\n"
#    data_line += "set output '#{@ps_files[0].tr(".ps", ".eps")}'\n"
    data_line += "set boxwidth 0.7\n"
    for i in (0..legend_name.size - 1)
      if i < @color_palette.size then
        palette = @color_palette[i]
      else 
        palette = @color_palette[i - @color_palette.size]
      end
      if (i == 0) then
        data_line += "plot '#{@dat_file}' using #{i + 3} w histogram lw 1 lc rgb \"#{palette}\" title \"#{legend_name[i]}\", \\\n"
      elsif (i == legend_name.size - 1) then
        data_line += "     '#{@dat_file}' using #{i + 3} w histogram lw 1 lc rgb \"#{palette}\" title \"#{legend_name[i]}\"\n"
      else
        data_line += "     '#{@dat_file}' using #{i + 3} w histogram lw 1 lc rgb \"#{palette}\" title \"#{legend_name[i]}\", \\\n"
      end
    end
    data_line += "unset output\n"
    data_line += "exit\n"
    Write_data.new.write_data(data_line, @opts, 1, @log, @plt_files[2])
  end
  
  
  #*** Calculation yrange (the vertical range that will be displayed on the y axis) of Gnuplot for 1-dimensional table ***#
  def cal_yrange(energy_min, energy_max)
    if energy_min.abs > energy_max.abs then ### |Energy min| > |Energy max|
      if energy_max <= 0 then ### (energy min) < (energy max) <= 0
        if (energy_min >= -5.0 and energy_min < 0.0) then  ### 0.0 > energy min >= -5
          y_min = energy_min - 1.0
          y_label_position = 0.5
          if energy_max.abs < (energy_min/2.0).abs then
            y_max = energy_min.abs
          else
            y_max = y_min.abs + 2.0
          end
        elsif  energy_min >= -15.0 then  ### -5.0 > energy min >= -15
          y_min = energy_min - 2.0
          if energy_max.abs < (energy_min/2.0).abs then
            y_label_position = 2.0
            y_max = energy_min.abs + 3.0
          else
            y_label_position = 3.0
            y_max = energy_min.abs + 5.0
          end
        elsif energy_min >= -25.0 then  ### -15 > energy min >= -25
          y_min = energy_min - 2.0
          if energy_max.abs < (energy_min/2.0).abs then
            y_label_position = 3.0
            y_max = energy_min.abs
          else
            y_label_position = 5.0
            y_max = energy_min.abs + 3.0
          end
        elsif energy_min >= -50.0 then ### -25 > energy min >= -50
          y_min = energy_min - 2.0
          y_label_position = 5.0
          if energy_max.abs < (energy_min/2.0).abs then
            y_max = (energy_min/2.0).abs + 15.0
          else
            y_max = energy_min.abs
          end
        elsif energy_min >= -100.0 then ### -50 > energy min >= -100
          y_min = energy_min - 5.0
          y_label_position = 5.0
          if energy_max.abs < (energy_min/4.0).abs then
            y_max = ((energy_min/5.0)*3.0).abs + 5.0
          elsif energy_max.abs < (energy_min/2.0).abs then
            y_max = ((energy_min/4.0)*3.0).abs + 20.0
          else
            y_max = energy_min.abs + 15.0
          end
        elsif energy_min >= -150.0 then ### -100 > energy min >= -150
          y_min = energy_min - 10.0
          y_label_position = 5.0
          if energy_max.abs < (energy_min/4.0).abs then
            y_max = ((energy_min/3.0)*2.0).abs + 10.0
          elsif energy_max.abs < (energy_min/2.0).abs then
            y_max = ((energy_min/4.0)*3.0).abs + 20.0
          else
            y_max = energy_min.abs + 15.0
          end
        else ### -150 > energy min
          y_min = energy_min - 20.0
          if energy_max.abs < (energy_min/4.0).abs then
            y_label_position = 10.0
            y_max = ((energy_min/3.0)*2.0).abs + 20.0
          elsif energy_max.abs < (energy_min/2.0).abs then
            y_label_position = 20.0
            y_max = ((energy_min/4.0)*3.0).abs + 30.0
          else
            y_label_position = 20.0
            y_max = energy_min.abs + 20.0
          end
        end
      else ### max > 0: (energy min) < 0 < (energy max)
        if (energy_min >= -5.0 and energy_min < 0.0) then  ### 0.0 > energy min >= -5
          y_min = energy_min - 1.0
          y_label_position = energy_max + 0.5
          if energy_max.abs < (energy_min/2.0).abs then
            y_max = energy_min.abs
          else
            y_max = y_min.abs + 2.0
          end
        elsif  energy_min >= -15.0 then  ### -5.0 > energy min >= -15
          y_min = energy_min - 2.0
          if energy_max.abs < (energy_min/2.0).abs then
            y_label_position = energy_max + 2.0
            y_max = energy_min.abs + 3.0
          else
            y_label_position = energy_max + 3.0
            y_max = energy_min.abs + 5.0
          end
        elsif energy_min >= -25.0 then  ### -15 > energy min >= -25
          y_min = energy_min - 2.0
          if energy_max.abs < (energy_min/2.0).abs then
            y_label_position = energy_max + 3.0
            y_max = energy_min.abs
          else
            y_label_position = energy_max + 5.0
            y_max = energy_min.abs + 3.0
          end
        elsif energy_min >= -50.0 then ### -25 > energy min >= -50
          y_min = energy_min - 2.0
          y_label_position = energy_max + 5.0
          if energy_max.abs < (energy_min/2.0).abs then
            y_max = (energy_min/2.0).abs + 15.0
          else
            y_max = energy_min.abs
          end
        elsif energy_min >= -100.0 then ### -50 > energy min >= -100
          y_min = energy_min - 5.0
          y_label_position = energy_max + 5.0
          if energy_max.abs < (energy_min/4.0).abs then
            y_max = ((energy_min/5.0)*3.0).abs + 5.0
          elsif energy_max.abs < (energy_min/2.0).abs then
            y_max = ((energy_min/4.0)*3.0).abs + 20.0
          else
            y_max = energy_min.abs + 15.0
          end
        elsif energy_min >= -150.0 then ### -100 > energy min >= -150
          y_min = energy_min - 10.0
          y_label_position = energy_max + 5.0
          if energy_max.abs < (energy_min/4.0).abs then
            y_max = ((energy_min/3.0)*2.0).abs + 10.0
          elsif energy_max.abs < (energy_min/2.0).abs then
            y_max = ((energy_min/4.0)*3.0).abs + 20.0
          else
            y_max = energy_min.abs + 15.0
          end
        else ### -150 > energy min
          y_min = energy_min - 20.0
          if energy_max.abs < (energy_min/4.0).abs then
            y_label_position = energy_max + 10.0
            y_max = ((energy_min/3.0)*2.0).abs + 20.0
          elsif energy_max.abs < (energy_min/2.0).abs then
            y_label_position = energy_max + 20.0
            y_max = ((energy_min/4.0)*3.0).abs + 30.0
          else
            y_label_position = energy_max + 20.0
            y_max = energy_min.abs + 20.0
          end
        end
      end 
    else ### |Energy min| <= |Energy max|
      if (energy_max >= 0.0 and energy_max < 5.0) then ### 0.0 < energy max <= 5
        y_label_position = energy_max + 2.0
        y_max = energy_max + 5
      elsif  energy_max <= 15.0 then  ### 5.0 < energy max <= 15
        y_min = energy_min - 2.0
        if energy_min.abs < (energy_max/2.0).abs then
          y_label_position = energy_max + 2.0
          y_max = energy_max.abs + 8.0
        else
          y_label_position = energy_max + 2.0
          y_max = energy_max.abs + 10.0
        end
      elsif energy_max <= 25.0 then  ### 15 < energy max <= 25
        y_min = energy_min - 2.0
        if energy_min.abs < (energy_max/2.0).abs then
          y_label_position = energy_max + 8.0
          y_max = energy_max.abs + 10.0
        else
          y_label_position = energy_max + 5.0
          y_max = energy_max.abs + 15.0
        end
      elsif energy_max <= 50.0 then ### 25 < energy max <= 50
        y_min = energy_min - 2.0
        y_label_position = energy_max + 15.0
        if energy_min.abs < (energy_max/2.0).abs then
          y_max = (energy_max/2.0).abs + 20.0
        else
          y_max = energy_max.abs + 40.0
        end
      elsif energy_max <= 100.0 then ### 50 < energy max <= -100
        y_min = energy_min - 5.0
        y_label_position = energy_max + 5.0
        if energy_min.abs < (energy_max/4.0).abs then
          y_max = ((energy_max/5.0)*3.0).abs + 30.0
        elsif energy_min.abs < (energy_max/2.0).abs then
          y_max = ((energy_max/4.0)*3.0).abs + 50.0
        else
          y_max = energy_max.abs + 70.0
        end
      elsif energy_max <= 150.0 then ### 100 < energy max <= 150
        y_min = energy_min - 10.0
        y_label_position = energy_max + 5.0
        if energy_min.abs < (energy_max/4.0).abs then
          y_max = ((energy_max/3.0)*2.0).abs + 40.0
        elsif energy_min.abs < (energy_max/2.0).abs then
          y_max = ((energy_max/4.0)*3.0).abs + 60.0
        else
          y_max = energy_max.abs + 80.0
        end
      else ### 150 < energy max
        y_min = energy_min - 20.0
        if energy_min.abs < (energy_max/4.0).abs then
          y_label_position = energy_max + 10.0
          y_max = ((energy_max/3.0)*2.0).abs + 50.0
        elsif energy_min.abs < (energy_max/2.0).abs then
          y_label_position = energy_max + 20.0
          y_max = ((energy_max/4.0)*3.0).abs + 80.0
        else
          y_label_position = energy_max + 20.0
          y_max = energy_max.abs + 100.0
        end
      end
    end
    
    return [y_min, y_max, y_label_position]
  end
  
  
  #*** Make plt file (for pm3d) for 2-dimensional table ***#
  def make_two_d_plt(plot_energy)
    @plt_files = ["setting_2d_map.plt"] ### Map (pm3d in gnuplot) from 2D-table
    @ps_files = ["2d_energy_map.ps"]
    
    data_line = "reset\nunset key\n"
    
=begin
    ### Color: (min) blue < cyan < white (middle) < orange < red (max)
    ### Caution: This color bar is the case that "energy max:energy min is 2:3".
    data_line += "set palette defined ( 0 '#000090',\\\n"
    data_line += "1 '#000fff',\\\n"
    data_line += "2 '#0090ff',\\\n"
    data_line += "3 '#0fffee',\\\n"
    data_line += "4 '#cbfff6',\\\n"
    data_line += "5 '#ffffff',\\\n"
    data_line += "6 '#ff7000',\\\n"
    data_line += "7 '#ee0000',\\\n"
    data_line += "8 '#7f0000')\n\n"
=end
    
#    divid = 10.0
    divid = 20.0
#    divid = 100.0
    color = [
      [0, 0, 255],    ### Blue  (position = min)
      [255, 0, 0],    ### Red   (position = max)
      [255, 255, 255] ### White (position = origin (0.0))
    ]

    min_val = plot_energy.flat_map {|i| i}.min
    max_val = plot_energy.flat_map {|i| i}.max
    if (min_val < 0) and (max_val > 0) then 
      color_gradation = ["0000ff"]
      j = color_gradation.size
      d = max_val.abs + min_val.abs

      a = (divid * (min_val.abs / d)).round(1) - j
      b = (divid * (max_val.abs / d)).round(1)

      if (a <= 0) then
        a = 1
      elsif (a == divid) then
        a -= 1
      end
      if (b <= 0) then
        b = 1
      elsif (b == divid) then
        b -= 1
      end

#      p "data range [%f: %f]"%[min_val, max_val]
#      p "a = %f, b = %f, a.quo(b) = %f"%[a + 1, b, (a + 1)%b] if (a > b)
#      p "a = %f, b = %f, b.quo(a) = %f"%[a + 1, b, b%(a + 1)] if (a < b)

      ### Blue => White
      if (a == 1) then
        color_gradation[j - 1] = "%s"%"ffffff"
      else
        i = min_val
        n = min_val.abs
        Array.new(a, n.to_f/a.to_f).each { |step|
          i =  (BigDecimal(i.to_s)).to_f +  (BigDecimal(step.to_s)).to_f
          color_gradation[j] = "%s"%rgb_gradation(color[2], color[0], i.abs/n)
#          p "[%i] position=%f, color=(0x%s)"%[j, i.round(2), color_gradation[j]]
          j += 1
        }
      end
#      p "-------------------------------------"
      ### White => Red
      if (b == 1) then
        color_gradation[j - 1] = "%s"%"ffffff"
      else
        n = max_val.abs
        Array.new(b, n.to_f/b.to_f).each { |step|
          i =  (BigDecimal(i.to_s)).to_f +  (BigDecimal(step.to_s)).to_f
          color_gradation[j] = "%s"%rgb_gradation(color[2], color[1], i/n)
#          p "[%i] position=%f, color=(0x%s)"%[j, i.round(2), color_gradation[j]]
          j += 1
        }
      end
      for j in 0..(color_gradation.size - 1)
        if (j == 0) then
          data_line += "set palette defined ( %i '#%s',\\\n"%[j, color_gradation[j]]
        elsif (j == (color_gradation.size - 1)) then
          data_line += "%i '#%s')\n\n"%[j, color_gradation[j]]
        else
          data_line += "%i '#%s',\\\n"%[j, color_gradation[j]]
        end
      end
    elsif (min_val >= 0) and (max_val > min_val) then
      if (min_val == 0) then
        color_gradation = ["ffffff"]
      else
        color_gradation = ["ffdddd"]
      end
      j = color_gradation.size
      d = max_val.abs + min_val.abs

      a = (divid * (min_val.abs / d)).round - j
      b = (divid * (max_val.abs / d)).round
      a = 1 if (a == 0)
      b = 1 if (b == 0)

      ### White or Thin red => Red
      i = min_val
      if (min_val == 0) then
        n = 1
      else
        n = min_val.abs
      end
      Array.new(a, n.to_f/a.to_f).each { |step|
        i =  (BigDecimal(i.to_s)).to_f +  (BigDecimal(step.to_s)).to_f
        color_gradation[j] = "%s"%rgb_gradation(color[2], color[1], i.abs/n)
#        p "position=%f, color=(0x%s)"%[i.round(2), color_gradation[j]]
        j += 1
      }
      for j in 0..(color_gradation.size - 1)
        if (j == 0) then
          data_line += "set palette defined ( %i '#%s',\\\n"%[j, color_gradation[j]]
        elsif (j == (color_gradation.size - 1)) then
          data_line += "%i '#%s')\n\n"%[j, color_gradation[j]]
        else
          data_line += "%i '#%s',\\\n"%[j, color_gradation[j]]
        end
      end
    elsif (max_val <= 0) and (max_val > min_val) then
      color_gradation = ["0000ff"]
      j = color_gradation.size
      d = max_val.abs + min_val.abs

      a = (divid * (min_val.abs / d)).round - j
      b = (divid * (max_val.abs / d)).round
      a = 1 if (a == 0)
      b = 1 if (b == 0)

      ### Blue => White or Thin blue
      if (max_val == 0) then
        n = 1
      else
        n = max_val.abs
      end
      Array.new(b, n.to_f/b.to_f).each { |step|
        i =  (BigDecimal(i.to_s) + BigDecimal(step.to_s)).to_f
        color_gradation[j] = "%s"%rgb_gradation(color[2], color[0], i/n)
#        p "position=%f, color=(0x%s)"%[i.round(2), color_gradation[j]]
        j += 1
      }
      if !(max_val == 0) then
        color_gradation << "ddddff"
      else 
        color_gradation << "ffffff"
      end
      for j in 0..(color_gradation.size - 1)
        if (j == 0) then
          data_line += "set palette defined ( %i '#%s',\\\n"%[j, color_gradation[j]]
        elsif (j == (color_gradation.size - 1)) then
          data_line += "%i '#%s')\n\n"%[j, color_gradation[j]]
        else
          data_line += "%i '#%s',\\\n"%[j, color_gradation[j]]
        end
      end
    else
      data_line += "set palette defined ( 0 '#0000ff',\\\n"
      data_line += "1 '#ffffff',\\\n"
      data_line += "2 '#ff0000')\n\n"
    end

    data_line += "set key font \"Times-Roman\"\n" ### Set font to "Times new roman"
#    data_line += "set datafile separator \" \"\n"
    data_line += "set xlabel \"Resdiue number [i]\"\n"
    data_line += "set ylabel \"Resdiue number [j]\"\n"
    if @opts[:fragment][0] == 1 then
      min_range = @opts[:fragment][0] + 1
    else
      min_range = @opts[:fragment][0]
    end
    if @opts[:fragment][1] == @frag_data[:max] then
      max_range = @opts[:fragment][1] - 1
    else
      max_range = @opts[:fragment][1]
    end
    data_line += "set xrange [%i : %i]\n"%[min_range, max_range]
    data_line += "set yrange [%i : %i]\n"%[min_range, max_range]

    ### Range for color bar (cb) of 2D plot 
    if !(min_val == 0) and !(max_val == 0) then
#      times = 0.10
#      times = 0.25
      times = 0.50  ### Scale for range of color bar
#      times = 0.75
#      times = 1.00
      data_line += "set cbrange[#{min_val*times}:#{max_val*times}]\n"
#      data_line += "set format cb \"%2.1f\"\n" 
      data_line += "set label 1 '[cb range * #{times}]' right at graph 0.99,1.05\n"
      if (@opts[:fmo] == 1) then ### PAICS
        if (@opts[:interaction] == 1) then
          data_line += "set cblabel \"[kcal/mol]\"\n"
        else
          if (@opts[:mode] % 2 == 0) then ### even
            data_line += "set cblabel \"[kcal/mol]\"\n"
          else ### odd
            data_line += "set cblabel \"(a.u.)\"\n"
          end
        end
      elsif (@opts[:fmo] == 2) then ### GAMESS-FMO
        data_line += "set cblabel \"[kcal/mol]\"\n"
      else ### ABINIT-MP
        if (@opts[:abinitmp] == 1) then ### IFIE
          if (@opts[:interaction] == 1) then
            data_line += "set cblabel \"[kcal/mol]\"\n"
          else
            if (@opts[:mode] % 2 == 0) then ### even
              data_line += "set cblabel \"[kcal/mol]\"\n"
            else ### odd
              data_line += "set cblabel \"(a.u.)\"\n"
            end
          end
        elsif (@opts[:abinitmp] == 2) then ### PIEDA
          data_line += "set cblabel \"[kcal/mol]\"\n"
        end
      end
    end
    data_line += "set pm3d map\n"
    data_line += "#splot '#{@dat_file}'\n"
    data_line += "set term post c\n"
    data_line += "set output '#{@ps_files[0]}'\n"
#    data_line += "set output '#{ps_files[0].tr(".ps", ".eps")}'\n"
    data_line += "splot '#{@dat_file}' notitle\n\n"
    data_line += "#set pm3d at b\n"
    data_line += "#set ticslevel 0.8\n"
    data_line += "#set isosample 50,50\n"
    data_line += "#splot '#{@dat_file}' notitle\n"
    data_line += "unset output\n"
    data_line += "exit\n"
    Write_data.new.write_data(data_line, @opts, 0, @log, @plt_files[0])
  end


  #*** Plot unsing gnuplot and output ps file ***#
  def plot_gnuplot
##################################################
##################################################
##################################################
##################################################
##################################################
#
#
#
#  Is gnuplot program "full path"?
#
#
#
##################################################
##################################################
##################################################
##################################################
##################################################
    @plt_files.each { |f|
      if !(f == "") then
        if @opts[:text] then
#          puts `gnuplot -persist #{f}` ### Show on gnuplot window
          puts `gnuplot #{f}`
        else
#          system(`gnuplot -persist #{f}`) ### Show on gnuplot window
          system(`gnuplot #{f}`)
        end
        @log.info "", "gnuplot #{f}", "", false
      end
    }
    @log.info "", "Process: Finish to plot using the Gnuplot program", "", @opts[:text]
  end

  #*** Convert ps file into pdf file using GhostScript (gs) program ***#
  def convert_ps2pdf
    cmd = ""
    if check_os == "Windows" then ### Windows
      @ps_files.each { |f|
        if !(f == "") then
          cmd = ps_to_pdf(f, f.gsub(".ps", ".pdf"))
          if @opts[:text] then
            puts `#{cmd}`
          else
            system(`#{cmd}`)
          end
          @log.info "", "#{cmd}", "", false
        end
      }
    else ### Other OS
      ps_files.each { |f|
        if !(f == "") then
          if @opts[:text] then
            puts `ps2pdf #{f}`
          else
            system(`ps2pdf #{f}`)
          end
          @log.info "", "ps2pdf #{f}", "", false
        end
      }
    end
    @log.info "", "Process: Finish to convert ps into pdf file using gs program", "", @opts[:text] 
  end

  #*** ps2pdf command for windows (instelled by gs) ***#
  ######################################################################
  #  (URL):                                                            #
  #  http://ruby.lickert.net/rtex/doc/classes/Config.src/M000047.html  #
  ######################################################################
  def ps_to_pdf(ps_file_name = "", pdf_file_name = "")
    cmd = which('gswin64c')
    if !(cmd == nil) then
      if cmd.include?(" ") then
        cmd = "\"" + cmd + "\""
      end
    else
      cmd = which('gswin32c')
      if cmd.include?(" ") then
        cmd = "\"" + cmd + "\""
      end
    end
    
    if (ps_file_name != "") and (pdf_file_name != "") then
      cmd += " -q -dBATCH -dNOPAUSE -sDEVICE=pdfwrite "
      cmd += "-sOutputFile=#{pdf_file_name} -c save pop -f #{ps_file_name}" 
    end
    
    return cmd
  end
end


##################
#*** Function ***#
##################

#*** Distance between the two atoms ***#
def distance(x1=0.0, y1=0.0, z1=0.0, x2=0.0, y2=0.0, z2=0.0)
  Math::sqrt((x1 - x2)**2 + (y1 - y2)**2 + (z1 - z2)**2)
end


#*** Command exists? ***#
def command_exist?(command)
  ### Be able to use "Open3.capture3" from Ruby ver. 1.9.3
  Open3.capture3(command)[2].exitstatus == 0 rescue nil
end


#*** "Which" for Ruby ("Only" executable in Windows) ***#
### (Ref): http://c4se.hatenablog.com/entry/2013/03/24/061210
def which(cmd)
  cmd_exist = "false"
  path = ENV['path'].split ';'
  pathext = ',' + ENV['pathext'].split(';').join(',').downcase

  path.each do |dir|
    begin
      Dir.chdir dir do
        files = Dir["#{cmd}{#{pathext}}"]
        if files.any?
          cmd_exist = "#{dir}#{dir =~ /\\$/ ? '' : '\\'}#{files.first}"
          break
        end
      end
      if (cmd_exist != "false") then
        return cmd_exist
      end
    rescue 
      next
    end
  end
  
  return nil
end


#*** Check the kind of OS ***#
def check_os
  ### Cygwin
  if ENV['OS'] == "Windows_NT" and ENV['os'] == nil then
    return "Cygwin"
  ### Command prompt
  elsif ENV['OS'] == "Windows_NT" then
    return "Windows"
  ### (ENV['OS'] == nil) is not equal to "Windows", other OS.
  else
    return "Other"
  end
end


#*** Two-Dimensional Array Initialization ***#
def two_array(i, j)
  ### Make Two-Dimensional Array [0..i][0..j]
  (0...i).map { Array.new(j) }
end  


#*** Exit program ***#
def exit_system(text_flag)
  puts "\nbye!\n" if (text_flag)
  exit;  ### This program exits!!
end


#*** Check data iclude nil? ***#
def check_nil(data, function_name, variable_name, text_flag, log)
  ### data array includes "nil"?
  if data.include?(nil) then
    ### First "nil" index number
    log.error "\nError: ", \
              "Array number [#{data.index(nil)}] is \"(nil)\" of \"#{variableName}\" in \"#{functionName}\" function!", \
              "\n", text_flag
    exit;  ### This program exits!!
  end
end


#*** Check command ***#
def check_cmd(cmd)
  if (check_os == "Other" or check_os == "Cygwin") then
    cmd_check = `which #{cmd}`
    if File.exist?(cmd_check.tr("\r\n|\r|\n", "")) then
      return true
    end
  elsif (check_os == "Windows") then
    if which(cmd) then
      return true
    end
  end
end


#*** Convert amino acid letter code from three to one ***#
def convert_amino_acide_letter_code(three_letter_code)
  letter_code = [{residue_name: "XXX", one_letter: "X"}, {residue_name: "ALA", one_letter: "A"},
                 {residue_name: "CYS", one_letter: "C"}, {residue_name: "ASP", one_letter: "D"},
                 {residue_name: "ASU", one_letter: "D"}, {residue_name: "GLU", one_letter: "E"},
                 {residue_name: "GLP", one_letter: "E"}, {residue_name: "PHE", one_letter: "F"},
                 {residue_name: "GLY", one_letter: "G"}, {residue_name: "HIS", one_letter: "H"},
                 {residue_name: "HIP", one_letter: "H"}, {residue_name: "ILE", one_letter: "I"},
                 {residue_name: "LYS", one_letter: "K"}, {residue_name: "LYY", one_letter: "K"},
                 {residue_name: "LEU", one_letter: "L"}, {residue_name: "MET", one_letter: "M"},
                 {residue_name: "ASN", one_letter: "N"}, {residue_name: "PRO", one_letter: "P"},
                 {residue_name: "GLN", one_letter: "Q"}, {residue_name: "ARG", one_letter: "R"},
                 {residue_name: "ARR", one_letter: "R"}, {residue_name: "SER", one_letter: "S"},
                 {residue_name: "THR", one_letter: "T"}, {residue_name: "VAL", one_letter: "V"},
                 {residue_name: "TRP", one_letter: "W"}, {residue_name: "TYR", one_letter: "Y"},
                 {residue_name: "HOH", one_letter: "o"}, {residue_name: "Na", one_letter: "n"},
                 {residue_name: "Ca", one_letter: "c"}, {residue_name: "Mg", one_letter: "m"},
                 {residue_name: "Cl", one_letter: "l"}, {residue_name: "CYX", one_letter: "C"}]

  lc = letter_code.select{|i| i[:residue_name] == three_letter_code}[0]
  if lc == nil then
    return "X"
  else
    return lc[:one_letter]
  end
end


#*** Color gradation between start point and end point by distance***#
### (Ref):
###   http://talavax.com/gradation.html
###   https://qiita.com/krsak/items/94fad1d3fffa997cb651
def rgb_gradation(color1, color2, d)
  ### [Gradation]:
  ###   color1(blue) (min: start point) -> White (0: origin) -> color2(red) (max: end point)
  ### 
  ### (r1, g1, b1)-------------(?)----------------------(r2, g2, b2) : Color
  ###      |---------d----------|                             |
  ###      --------------------------------------------------->
  ###     0.0                                                1.0     : Distance
  r = ((BigDecimal(color2[0].to_s) - BigDecimal(color1[0].to_s)) * BigDecimal(d.to_s) + BigDecimal(color1[0].to_s)).to_f.round
  g = ((BigDecimal(color2[1].to_s) - BigDecimal(color1[1].to_s)) * BigDecimal(d.to_s) + BigDecimal(color1[1].to_s)).to_f.round
  b = ((BigDecimal(color2[2].to_s) - BigDecimal(color1[2].to_s)) * BigDecimal(d.to_s) + BigDecimal(color1[2].to_s)).to_f.round

  r = 0.0 if (r < 0)
  g = 0.0 if (g < 0)
  b = 0.0 if (b < 0)

  r = 255.0 if (r > 255)
  g = 255.0 if (g > 255)
  b = 255.0 if (b > 255)

#  return [r, g, b]
  return "%02x"%r + "%02x"%g + "%02x"%b
end


#*** Main run ***#
def run_fmo_analysis(xml_flag)
  opts = {
    text: true,        ### Don't show text on terminal with "-t" (No option: show text)
    out: "",           ### Calculated FMO Out file name
    pdb: "",           ### PDB file name
    output: "",        ### Output file name (type: text)
    add_chain: 1,      ### Flag to add chain identifier
    gnuplot: true,     ### Plot the bar graph using Gnuplot
    distance: [0, 5],  ### Distance in plot
    aaletter: 2,       ### Amino acid letter code in plot
    paics: 2,          ### PAICS program version
#    inp: 2,           ### Select a software (or script, plugin) for creating PAICS input file (*.inp)
    abinitmp: 1,       ### Select the type of energy data of ABINIT-MP (MP2 or PIEDA), default MP2 
    fragment: [1,0],   ### Extract data range between i and j fragment
    ligand_num: 0,
    xml: false,        ### Output xml data, when analyzed with this xml option (-x or --xml)
  }
  flags = {
    fmo: false,
    out: false,
    pdb: false,
    output: false,
    add_chain: false,
    distance: false,
    aaletter: false,
    paics: false,
#    inp: false,
    interaction: false,
    abinitmp: false,
    mode: false,
    fragment: false,
    ligand_num: false,
  }
  cmd_exist = {
    gnuplot: false, ### Flag for installed gnuplot on your system
    gs: false,      ### Flag for installed ghostscript (gs) on your system (Windows only)
    ps2pdf: false,  ### Flag for installed ps2pdf on your system
  }
  
  ### Avoid the "invalid byte sequence in UTF-8"
  STDIN.set_encoding "Windows-31J"  if (check_os == "Windows")
  
  cmd_exist[:gnuplot] = check_cmd("gnuplot") ### Check "gnuplot" on your system
  cmd_exist[:gs] = check_cmd("gswin64c")     ### Check "ghostscript (gs)" on your system (Windows only)
  cmd_exist[:gs] = check_cmd("gswin32c") if !(cmd_exist[:gs])
  cmd_exist[:ps2pdf] = check_cmd("ps2pdf")   ### Check "ps2pdf" on your system

  wt = Work_Time.new(); ### Start to measure execution time

  ### Option for analysis
  Opt::CLI.new(opts, flags).parse_options()
  opts, flags, log_data = Terminal_input.new.check_main_opt_flag()

  work_dir = File.dirname(opts[:out])            ### Get the path of work dir
  log_file = File.join(work_dir, "analysis.log") ### Log file name
  FileUtils.rm_rf(log_file)                      ### Remove old log file
  log ||= PLogger.new log_file                   ### Create new log file

  for i in 0..(log_data.size - 1)  ### Write for log file
    log.info "", "#{log_data[i]}", "", false
  end

  ### Option for Gnuplot
  if cmd_exist[:gnuplot] and opts[:gnuplot] then
    if opts[:interaction] == 1 then
      Terminal_input.new.check_gp_opt_flag(cmd_exist, log)
    end
  end

  log.info "\n", "********************", "", opts[:text]
  log.info "", "* Analysis Process *"  , "", opts[:text]
  log.info "", "********************", "", opts[:text]

  log.info "\n", "  <Input File name>", "", opts[:text]
  log.info "", "   - Calculated FMO out file: #{opts[:out]}", "", opts[:text]
  log.info "", "   - PDB file:                #{opts[:pdb]}", "", opts[:text]
  log.info "", "  <Output File name>", "", opts[:text]
  log.info "", "   - Analyzed output file:    #{opts[:output]}", "", opts[:text]

  ### Analysis from PDB
  Analysis::PDB.new(opts, flags, log, [], [], [], [], [], xml_flag).run

  ### Analysis from Out
  if (opts[:fmo] == 1) then ### PAICS
    PAICS.new().run(cmd_exist)
  elsif (opts[:fmo] == 2) then ### GAMESS
    GAMESS.new().run(cmd_exist)
  elsif (opts[:fmo] == 3) then ### ABINIT-MP
    ABINIT_MP.new().run(cmd_exist)
  end

  wt.done(opts[:text], log) ### Finish to measure execution time
  log.close ### Close log file
end


##############
#*** Main ***#
##############

run_fmo_analysis(xml_flag)

